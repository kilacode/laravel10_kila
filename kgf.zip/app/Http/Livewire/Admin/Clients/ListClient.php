<?php

namespace App\Http\Livewire\Admin\Clients;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Client;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class ListClient extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $clientIdBeingRemoved = null;
    public $client;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Client-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }


    public function createClient()
    {

        $validateData = Validator::make($this->state, [
            'nom' => 'required',
            'prenom' => 'required',
            'nom_entreprise' => 'nullable',
            'email' => 'required|email', 
            'telephone' => 'required',
        ], [
            'nom.required' => "Le nom est obligatoire",
            'prenom.required' => "Le prénom est obligatoire",
            'email.required' => "L'email est obligatoire",
            'email.email' => "L'email n'est pas valide",
            'email.unique' => "Cet email est déjà utilisé",
            'telephone.required' => "Le téléphone est obligatoire",
        ])->validate();
 
        if (Gate::allows('access', 'Client-Ajouter')) {
            Client::create($validateData);
            $this->dispatchBrowserEvent('hide-form', ['message' => "Client ajouté avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(Client $client)
    {
        if (Gate::allows('access', 'Client-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->client = $client;

            $this->state = $client->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateClient()
    {
        $validateData = Validator::make($this->state, [
            'nom' => 'required',
            'prenom' => 'required',
            'nom_entreprise' => 'nullable',
            'email' => 'required|email', 
            'telephone' => 'required',
        ], [
            'nom.required' => "Le nom est obligatoire",
            'prenom.required' => "Le prénom est obligatoire",
            'email.required' => "L'email est obligatoire",
            'email.email' => "L'email n'est pas valide",
            'email.unique' => "Cet email est déjà utilisé",
            'telephone.required' => "Le téléphone est obligatoire",
        ])->validate();

        if (Gate::allows('access', 'Client-Modifier')) {

            $this->client->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Client modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Client-Supprimer-Groupe')) {
            Client::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Client ont étés supprimés?']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmClientRemoval($clientId)
    {
        $this->clientIdBeingRemoved = $clientId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteClient()
    {
        if (Gate::allows('access', 'Client-Supprimer')) {
            $client = Client::findOrFail($this->clientIdBeingRemoved);
            $client->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Client suprimé avec succès !"]);
        }
    }
    public function render()
    {
        $searchTerm = '%' . $this->searchTerm . '%';

        $clients = Client::query()
            ->where(function ($query) use ($searchTerm) {
                $query->whereRaw("CONCAT(nom, ' ', prenom) LIKE ?", [$searchTerm]) 
                    ->orWhereRaw("CONCAT(prenom, ' ', nom) LIKE ?", [$searchTerm])
                    ->orWhereRaw("CONCAT(email, ' ', telephone, ' ', nom) LIKE ?", [$searchTerm]);
            })
            ->latest()
            ->paginate(12);

        return view('livewire.admin.clients.list-client', compact('clients'));
    }
}