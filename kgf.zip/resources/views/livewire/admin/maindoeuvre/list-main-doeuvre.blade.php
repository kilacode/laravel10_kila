<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Main d'oeuvres</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Main d'oeuvres</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">

                        <button class="btn btn-primary " wire:click.prevent="addNew">
                            <i class="fa fa-plus-circle mr-1"></i> Ajouter Main d'oeuvre
                        </button>

                        @if ($selectedRows)
                            <div class="btn-group ml-2">
                                <button type="button" class="btn btn-default">Options</button>
                                <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                    data-toggle="dropdown" aria-expanded="false">
                                    <span class="sr-only"></span>
                                </button>
                                <div class="dropdown-menu" role="menu" style="">
                                    <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                        href="#">Supprimer les Main d'oeuvres sélectionnées</a>
                                </div>
                            </div>
                            <span class="ml-2">{{ count($selectedRows) }}
                                {{ Str::plural(' Main d\'oeuvre', count($selectedRows)) }} {{ Str::plural(' sélectionnée', count($selectedRows)) }} </span>
                        @endif

                        <x-search-input wire:model='searchTerm' />
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th></th>
                                            <th>Nom du personel</th>
                                            <th>Taux horaire </th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($maindoeuvres as $maindoeuvre)
                                            <tr>
                                                <th scope="row">{{ $loop->iteration }}</th>
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="{{ $maindoeuvre->id }}"
                                                            value="{{ $maindoeuvre->id }}">
                                                        <label for="{{ $maindoeuvre->id }}"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>
                                                <td>{{ $maindoeuvre->nom_personnel }}</td>
                                                <td>{{ $maindoeuvre->taux_horaire  }} $ </td>
                                                <td>
                                                    @can('access', 'Maindoeuvre-Modifier')
                                                        <a href="" wire:click.prevent="edit({{ $maindoeuvre }})">
                                                            <i class="fa fa-edit mr-2"></i>
                                                        </a>
                                                    @endcan 
                                                    @can('access', 'Maindoeuvre-Supprimer')
                                                        <a href=""
                                                            wire:click.prevent="confirmMaindoeuvreRemoval({{ $maindoeuvre->id }})">
                                                            <i class="fa fa-trash text-danger"></i>
                                                        </a>
                                                    @endcan
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="10">
                                                    <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            {{ $maindoeuvres->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        @if ($showEditModal == true)
                            <span>Modifier La Main d'oeuvre</span>
                        @else
                            <span>Ajout d'une nouvelle Maindoeuvre</span>
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="{{ $showEditModal ? 'updateMaindoeuvre' : 'createMaindoeuvre' }}">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="nom_personnel">Nom du personnel</label>
                                    <input type="text" class="form-control @error('nom_personnel') is-invalid @enderror"
                                        wire:model.defer="state.nom_personnel" id="nom_personnel" placeholder="Nom de La Main d'oeuvre">

                                    @error('nom_personnel')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="taux_horaire">Taux par heure</label>
                                    <input type="number" min="0" class="form-control @error('taux_horaire') is-invalid @enderror"
                                        wire:model.defer="state.taux_horaire" id="taux_horaire" placeholder="Cout par heure">

                                    @error('taux_horaire')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>
                    @if ($showEditModal)
                        <button type="submit" class="btn btn-info"><i class="fa fa-save mr-1"></i> Enregistrer les
                            modifications</button>
                    @else
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-1"></i>
                            Enregistrer</button>
                    @endif
                </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Supprimer La Main d'oeuvre</h5>
                </div>
                <div class="modal-body">
                    <h4>Etes-vous sûr de vouloir supprimer Cette Main d'oeuvre?</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>

                    <button type="button" wire:click.prevent='deleteMaindoeuvre' class="btn btn-danger"><i
                            class="fa fa-trash mr-1"></i>
                        Supprimer</button>

                </div>
            </div>
        </div>
    </div>
</div>
