<?php

namespace App\Http\Livewire\Admin\Devis;

use App\Http\Livewire\Admin\AdminComponent;
use App\Http\Livewire\Admin\Approvisionnement\Approvisionnement;
use App\Models\ApprovisionnementEnEau;
use App\Models\DevisForage;
use App\Models\DevisItem;
use App\Models\EquipementForage;
use App\Models\EtapesForage;
use App\Models\Facture;
use App\Models\FactureItem;
use App\Models\MainDoeuvre;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class DevisShow extends AdminComponent
{
    public $showEditModal = false;
    public $state = [];
    public $devis;
    public $devisItem;
    public $stateTitre;
    public $item;
    public $itemIdBeingRemoved;
    public $stateItem = [
        'titreitem' => '',
        'unite' => '',
        'prix_u' => 0,
        'prix_t' => 0,
        'qte' => 0,
        'pu' => 0,
        'tva' => 0,
        'rabais' => 0,
    ];

    public function mount(DevisForage $devis)
    {
        $this->state = $devis->toArray();
        $this->devis = $devis;
    }

    public function addNew()
    {
        $this->showEditModal = false;
        $this->reset('stateItem');
        $this->dispatchBrowserEvent('show-form');
    }

    public function edit(DevisItem $item)
    {
        $this->reset('stateItem');
        $this->showEditModal = true;

        $this->item = $item;

        $this->stateItem = $item->toArray();
        $this->stateItem['titreitem'] = 'Autre';
        $this->dispatchBrowserEvent('show-form');
    }
    public function updateSelectedEquipement()
    {
        if (!empty($this->stateItem['equipement_id'])) {
            $equipement = EquipementForage::find($this->stateItem['equipement_id']);
            $this->stateItem['titre'] = $equipement->nom_equipement;
            $this->stateItem['prix_u'] = $equipement->cout_par_heure;
            $this->stateItem['unite'] = 'Heure';
        } else {
            $this->stateItem['titre'] = '';
            $this->stateItem['prix_u'] = 0;
            $this->stateItem['unite'] = '';
        }
    }


    public function updateSelectedMoeuvre()
    {
        if (!empty($this->stateItem['moeuvre_id'])) {
            $moeuvre = MainDoeuvre::find($this->stateItem['moeuvre_id']);
            $this->stateItem['titre'] = $moeuvre->nom_personnel;
            $this->stateItem['prix_u'] = $moeuvre->taux_horaire;
            $this->stateItem['unite'] = 'Heure';
        } else {
            $this->stateItem['titre'] = '';
            $this->stateItem['prix_u'] = 0;
            $this->stateItem['unite'] = '';
        }
    }

    public function updateSelectedApprov()
    {
        if (!empty($this->stateItem['approvisionnement_id'])) {
            $approvisionnement = ApprovisionnementEnEau::find($this->stateItem['approvisionnement_id']);
            $this->stateItem['titre'] = $approvisionnement->nom_approvisionnement;
            $this->stateItem['prix_u'] = $approvisionnement->cout_supplementaire;
            $this->stateItem['unite'] = '-';
        } else {
            $this->stateItem['titre'] = '';
            $this->stateItem['prix_u'] = 0;
            $this->stateItem['unite'] = '';
        }
    }

    public function createItem()
    {
        $validatedData = Validator::make($this->stateItem, [
            'etape_forage_id' => 'required',
            'description' => 'nullable',
            'tva' => 'nullable',
            'rabais' => 'nullable',
            'prix_tva' => 'nullable',
            'prix_rabais' => 'nullable',
            'unite' => 'required',
            'qte' => 'required',
            'prix_u' => 'required',
        ], [
            'etape_forage_id.required' => "Veuillez choisir l'étape du forage",
            'unite.required' => "Choisissez une unité",
            'qte.required' => "La quantité est obligatoire",
            'prix_u.required' => "Le prix unitaire est obligatoire",
        ])->validate();

        if (empty($this->stateItem['titreitem'])) {
            dd("Choisissez un équipement, un personnel, un système d'approvisionnement en eau ou autre");
        } else {
            $validatedData['titre'] = $this->stateItem['titre'];
            $validatedData['numero'] = $this->generateDevisNumber();
            $validatedData['devis_forage_id'] = $this->devis->id;

            $total = $this->stateItem['prix_u'] * $this->stateItem['qte'];
            $prix_tva = (float) $total * (float) $this->stateItem['tva'] / 100;
            $prix_rabais = (float) $total * (float) $this->stateItem['rabais'] / 100;

            $validatedData['prix_tva'] = $prix_tva;
            $validatedData['prix_rabais'] = $prix_rabais;

            $validatedData['prix_ht'] = $this->stateItem['prix_ht'];

            $validatedData['prix_t'] = $this->stateItem['prix_t'];

            if (Gate::allows('access', 'DevisItem-Ajouter')) {

                DevisItem::create($validatedData);
                $this->dispatchBrowserEvent('alert', ['message' => "Article creé avec succès !"]);
                $this->reset('stateItem');
            }
        }
    }

    public function updateItem()
    {
        $validatedData = Validator::make($this->stateItem, [
            'unite' => 'required',
            'qte' => 'required',
            'prix_u' => 'required',
            'tva' => 'nullable',
            'rabais' => 'nullable',
            'prix_tva' => 'nullable',
            'prix_rabais' => 'nullable',
            'etape_forage_id' => 'required',
            'description' => 'nullable',
        ], [
            'unite.required' => "Veuillez renseigner l'unité utilisée",
            'qte.required' => "La quantité est obligatoire",
            'prix_u.required' => "Le prix unitaire est obligatoire",
            'etape_forage.required' => "L'étape du forage est obligatoire",
        ])->validate();


        if (empty($this->stateItem['titreitem'])) {
            dd("Choisissez un titre");
        } else {
            if (Gate::allows('access', 'DevisItem-Modifier')) {
                $validatedData['numero'] = $this->generateDevisNumber();
                $validatedData['titre'] = $this->stateItem['titre'];
                $validatedData['devis_forage_id'] = $this->devis->id;

                $total = $this->stateItem['prix_u'] * $this->stateItem['qte'];
                $prix_tva = (float) $total * (float) $this->stateItem['tva'] / 100;
                $prix_rabais = (float) $total * (float) $this->stateItem['rabais'] / 100;

                $validatedData['prix_tva'] = $prix_tva;
                $validatedData['prix_rabais'] = $prix_rabais;

                $validatedData['prix_ht'] = $this->stateItem['prix_ht'];
                $validatedData['prix_t'] = $this->stateItem['prix_t'];

                $this->item->update($validatedData);
                $this->dispatchBrowserEvent('hide-form', ['message' => "Article Mofifié !"]);
                $this->reset('stateItem');
            }
        }

    }

    public function confirmItemRemoval($itemId)
    {
        $this->itemIdBeingRemoved = $itemId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }
    public function generateDevisNumber()
    {
        // Obtenez le dernier numéro de facture enregistré dans la base de données
        $lastFacture = DevisItem::orderBy('id', 'desc')->first();

        // Si aucune facture n'existe encore, commencez par 1
        $nextNumber = $lastFacture ? intval(substr($lastFacture->numero, -4)) + 1 : 1;

        // Formatez le numéro avec des zéros à gauche pour obtenir FACT-XXXX
        $formattedNumber = 'DEV-ITEM-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        return $formattedNumber;
    }
    public function generateFactureItemNumber()
    {
        // Obtenez le dernier numéro de facture enregistré dans la base de données
        $lastFacture = FactureItem::orderBy('id', 'desc')->first();

        // Si aucune facture n'existe encore, commencez par 1
        $nextNumber = $lastFacture ? intval(substr($lastFacture->numero, -4)) + 1 : 1;

        // Formatez le numéro avec des zéros à gauche pour obtenir FACT-XXXX
        $formattedNumber = 'FACT-ITEM-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        return $formattedNumber;
    }

    public function generateFactureNumber()
    {
        // Générez un numéro de facture unique en utilisant la date et un numéro séquentiel
        $prefix = 'FACT-'; // Préfixe de la facture
        $datePart = now()->format('Ymd'); // Partie de la date au format année-mois-jour
        $lastFacture = Facture::latest()->first(); // Récupérez la dernière facture

        if ($lastFacture) {
            // Si une dernière facture existe, extrayez le numéro séquentiel de la dernière facture
            $lastNumber = intval(substr($lastFacture->numero, strlen($prefix) + strlen($datePart)));
            $nextNumber = $lastNumber + 1;
        } else {
            // Si aucune facture n'existe, commencez avec le numéro 1
            $nextNumber = 1;
        }

        // Construisez le numéro de facture complet avec le préfixe, la partie de la date et le numéro séquentiel
        $factureNumber = $prefix . $datePart . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        return $factureNumber;
    }

    public function createFactureItemsFromDevis($factureId)
    {
        if (!$this->devis->numero) {
            return; // Ne pas enregistrer si le numéro de devis est manquant
        }

        foreach ($this->devis->devis_item as $item) {
            $factureItem = new FactureItem();
            $factureItem->titre = $item->titre;
            $factureItem->numero = $this->generateFactureItemNumber();
            $factureItem->description = $item->description;
            $factureItem->qte = $item->qte;
            $factureItem->unite = $item->unite;
            $factureItem->prix_u = $item->prix_u;
            $factureItem->prix_t = $item->prix_t;
            $factureItem->prix_ht = $item->prix_ht;
            $factureItem->prix_tva = $item->prix_tva;
            $factureItem->prix_rabais = $item->prix_rabais;
            $factureItem->tva = $item->tva;
            $factureItem->rabais = $item->rabais;
            $factureItem->facture_id = $factureId; // Remplacez $this->facture par l'instance de Facture
            $factureItem->etape_forage_id = $item->etape_forage_id;
            $factureItem->save();
        }
    }

    public function devisToFacture()
    {
        $existingFacture = Facture::where('projet_forage_id', $this->devis->projet_forage_id)->first();
        if ($this->devis->etat == 'Validé' || $this->devis->etat == 'Terminé' && !$existingFacture) {

            $nouvelleFacture = new Facture();
            $nouvelleFacture->projet_forage_id = $this->devis->projet_forage_id;
            $nouvelleFacture->devis_projet_id = $this->devis->id;
            $nouvelleFacture->titre = $this->devis->titre;
            $nouvelleFacture->numero = $this->generateFactureNumber(); // Générez le numéro de facture
            $nouvelleFacture->note = $this->devis->note;
            $nouvelleFacture->tva = $this->devis->tva;
            $nouvelleFacture->total_ht = $this->devis->total_ht;
            $nouvelleFacture->total_ttc = $this->devis->total_ttc;
            $nouvelleFacture->etat = 'Créée'; // Mettez l'état initial de la facture
            $nouvelleFacture->marge_ben = $this->devis->marge_ben;
            $nouvelleFacture->date = now(); // Date actuelle
            $nouvelleFacture->validite = $this->devis->validite;
            $nouvelleFacture->modalite = $this->devis->modalite;
            $nouvelleFacture->echeance = $this->devis->echeance;
            $nouvelleFacture->coordonee_banc = $this->devis->coordonee_banc;
            $nouvelleFacture->delai_livraison = $this->devis->delai_livraison;
            $nouvelleFacture->conditions_general = $this->devis->conditions_general;
            $nouvelleFacture->garantie_rembourse = $this->devis->garantie_rembourse;
            $nouvelleFacture->contact = $this->devis->contact;
            $nouvelleFacture->user_id = $this->devis->user_id;

            $nouvelleFacture->save();
            $factureId = $nouvelleFacture->id;
            $this->createFactureItemsFromDevis($factureId);

            $this->devis->etat = 'Terminé';
            $this->devis->save();

            $this->dispatchBrowserEvent('hide-form', ['message' => "Facture Ajoutée !"]);

        } else {
            $this->dispatchBrowserEvent('show-alert', [
                'title' => "Erreur d'etat ou de doublon",
                'message' => "La conversion n'a pas été effectuée en raison de l'état du devis ou du fait que ce devis a déjà une facture générée",
                'icon' => 'info',
                'iconColor' => '#ff6600'
            ]);
        }

    }


    public function updateDevisTotals()
    {
        $totalTva = $this->devis->devis_item->sum('prix_tva');
        $totalHt = $this->devis->devis_item->sum('prix_ht');
        $totalTtc = $this->devis->devis_item->sum('prix_t');

        $validatedData = [
            'tva' => $totalTva,
            'total_ht' => $totalHt,
            'total_ttc' => $totalTtc,
        ];

        $validatedData2 = [
            'cout_total' => $totalTtc,
        ];
        $this->devis->update($validatedData);
        $this->devis->projetForage->update($validatedData2);

        $this->dispatchBrowserEvent('updated', ['message' => "Totaux du devis mis à jour !"]);
    }


    public function deleteItem()
    {
        $item = DevisItem::findOrFail($this->itemIdBeingRemoved);
        $item->delete();
        $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Article suprimé avec succès !"]);
    }
    public function render()
    {
        if (isset($this->stateItem['prix_u']) && isset($this->stateItem['qte'])) {
            $total = (float) $this->stateItem['prix_u'] * (float) $this->stateItem['qte'];
            $prix_tva = (float) $total * (float) $this->stateItem['tva'] / 100;
            $prix_rabais = (float) $total * (float) $this->stateItem['rabais'] / 100;
            $this->stateItem['prix_ht'] = (float) $total;
            $this->stateItem['prix_t'] = (float) $total + $prix_tva - $prix_rabais;
        }

        $etapes = EtapesForage::orderBy('created_at', 'asc')->get();
        $equipements = EquipementForage::orderBy('nom_equipement', 'asc')->get();
        $moeuvres = MainDoeuvre::orderBy('nom_personnel', 'asc')->get();
        $approvisionnements = ApprovisionnementEnEau::orderBy('nom_approvisionnement', 'asc')->get();
        return view('livewire.admin.devis.devis-show', compact('etapes', 'equipements', 'moeuvres', 'approvisionnements'));
    }
}