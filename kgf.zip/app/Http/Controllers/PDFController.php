<?php

namespace App\Http\Controllers;

use App\Models\DevisForage;
use App\Models\DevisItem;
use App\Models\EtapesForage;
use App\Models\Facture;
use App\Models\PayementFacture;
use App\Models\Setting;
use PDF; 
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class PDFController extends Controller
{
    public function generatePDF()
    {  
        $qrcode = QrCode::size(50)->generate("josephmbula");
        $qrcodeData = base64_encode($qrcode);
        
        $code = '<img src="data:image/png;base64,' . $qrcodeData . '">';
        $data = [
            'title' => 'Welcome to ItSolutionStuff.com',
            'code' => $code,
        ]; 
        $pdf = PDF::loadView('documents.test', $data); 
        return $pdf->stream('test.pdf');
    }

    public function generateDevisPDF($numero)
    {    
        $devis = DevisForage::where('numero', $numero)->first();
        $qrcode = QrCode::size(50)->generate(route('printdevis', ['numero' => $devis->numero]));
        $qrcodeData = base64_encode($qrcode);
        $etapes = EtapesForage::orderBy('created_at','asc')->get();
        $code = '<img src="data:image/png;base64,' . $qrcodeData . '">';
        $infos = Setting::first();
        $data = [
            'date' => date('m/d/Y'),
            'devis' => $devis,
            'code' => $code,
            'infos' => $infos,
            'etapes'=>$etapes,
        ]; 
        $pdf = PDF::loadView('documents.devis', $data); 
        return $pdf->stream('test.pdf');
    }

    public function generateDevisClientPDF($numero)
    {    
        $devis = DevisForage::where('numero', $numero)->first();
        $qrcode = QrCode::size(50)->generate(route('printdevisclient', ['numero' => $devis->numero]));
        $qrcodeData = base64_encode($qrcode);
        $etapes = EtapesForage::orderBy('created_at','asc')->get();
        $code = '<img src="data:image/png;base64,' . $qrcodeData . '">';
        $infos = Setting::first();
        $data = [
            'date' => date('m/d/Y'),
            'devis' => $devis,
            'code' => $code,
            'infos' => $infos,
            'etapes'=>$etapes,
        ]; 
        $pdf = PDF::loadView('documents.devisclient', $data); 
        return $pdf->stream('test.pdf');
    }

    public function generateFacturePDF($numero)
    {    
        $facture = Facture::where('numero', $numero)->first();
        $qrcode = QrCode::size(50)->generate(route('printfacture', ['numero' => $facture->numero]));
        $qrcodeData = base64_encode($qrcode);
        $etapes = EtapesForage::orderBy('created_at','asc')->get();
        $code = '<img src="data:image/png;base64,' . $qrcodeData . '">';
        $infos = Setting::first();
        $data = [
            'date' => date('m/d/Y'),
            'facture' => $facture,
            'code' => $code,
            'infos' => $infos,
            'etapes'=>$etapes,
        ]; 
        $pdf = PDF::loadView('documents.facture', $data); 
        return $pdf->stream('test.pdf');
    }
    public function generateFactureClientPDF($numero)
    {    
        $facture = Facture::where('numero', $numero)->first();
        $qrcode = QrCode::size(50)->generate(route('printfactureclient', ['numero' => $facture->numero]));
        $qrcodeData = base64_encode($qrcode);
        $etapes = EtapesForage::orderBy('created_at','asc')->get();
        $code = '<img src="data:image/png;base64,' . $qrcodeData . '">';
        $infos = Setting::first();
        $data = [
            'date' => date('m/d/Y'),
            'facture' => $facture,
            'code' => $code,
            'infos' => $infos,
            'etapes'=>$etapes,
        ]; 
        $pdf = PDF::loadView('documents.factureclient', $data); 
        return $pdf->stream('test.pdf');
    }
    public function generateRecuePDF($numero)
    {   
        $facture = Facture::where('numero', $numero)->first(); 
        $qrcode = QrCode::size(50)->generate(route('printrecue', ['numero' => $numero]));
        $qrcodeData = base64_encode($qrcode); 
        $code = '<img src="data:image/png;base64,' . $qrcodeData . '">';
        $infos = Setting::first();
        $data = [
            'date' => date('m/d/Y'), 
            'code' => $code,
            'infos' => $infos, 
            'facture'=>$facture,
        ]; 
        $pdf = PDF::loadView('documents.recues', $data); 
        return $pdf->stream('test.pdf');
    }
}

