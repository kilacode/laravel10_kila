<?php

namespace App\Http\Livewire\Admin\Fonctions;
use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Fonction;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListFonctions extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $fonctionIdBeingRemoved = null;
    public $fonction;
    public $searchTerm = null;
    public $selectedIds = [];
 

    
    public function addNew()
    {
        if (Gate::allows('access','Fonction-Ajouter')) {
            $this->showEditModal = false; 
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function createFonction()
    { 
        $validateData = Validator::make($this->state, [ 
            'name' => 'required', 
        ], [ 
            'name.required' => "Le nom est obligatoire", 
        ])->validate();
            
            if (Gate::allows('access','Fonction-Ajouter')) {
                Fonction::create($validateData); 
                $this->dispatchBrowserEvent('hide-form', ['message' => "Fonction ajouté avec succès !"]); 
            }

            $this->state = [];
         
 
    }
    public function edit(Fonction $fonction)
    {
        if (Gate::allows('access','Fonction-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->fonction = $fonction;

            $this->state = $fonction->toArray();   
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateFonction()
    {
        $validateData = Validator::make($this->state, [ 
            'name' => 'required',
            'description' => 'nullable',
        ], [ 
            'name.required' => "Le nom est obligatoire", 
        ])->validate();
        
        if (Gate::allows('access','Fonction-Modifier')) {

            $this->fonction->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Fonction modifié avec succès !"]);
        }

        $this->state = [];  
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Fonction-Supprimer-Groupe')) {
            Fonction::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Fonction ont étés supprimés?']);

            $this->reset(['selectedRows','selectedPageRows']);
        }
    }
    public function confirmFonctionRemoval($fonctionId)
    {
        $this->fonctionIdBeingRemoved = $fonctionId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteFonction()
    {
        if (Gate::allows('access','Fonction-Supprimer')) {
            $fonction = Fonction::findOrFail($this->fonctionIdBeingRemoved);
            $fonction->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Fonction suprimé avec succès !"]); 
        }  
    }
    public function render()
    {
        $fonctions = Fonction::query()
                ->where('name','like', '%'.$this->searchTerm.'%') 
                ->latest()->paginate(12); 
        return view('livewire.admin.fonctions.list-fonctions', compact('fonctions'));
    }
}
