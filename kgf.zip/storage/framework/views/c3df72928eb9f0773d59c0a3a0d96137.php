<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Facture</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Tableau de bord</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.factures')); ?>">Liste de Facture</a></li>
                        <li class="breadcrumb-item active">Visualiser le Facture</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($facture->titre); ?>

                                <a href="<?php echo e(route('admin.facture.edit', $facture)); ?>"> <i
                                        class="fa fa-pen-alt ml-3"></i></a>
                            </h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <ul class="nav nav-pills flex-column">
                                <li class="nav-item active">
                                    <div class="nav-link">
                                        <i class="fas fa-tag mr-3"></i> <?php echo e($facture->numero); ?>

                                        <span class="ml-5"><?php echo QrCode::size(50)->generate($facture->numero); ?></span>
                                        </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-file-invoice-dollar mr-3"></i>Titre : <?php echo e($facture->titre); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-project-diagram mr-3"></i>Projet :
                                        <?php echo e($facture->projet->nom_projet); ?>

                                    </a>

                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-file-invoice-dollar mr-3"></i>Devis :
                                        <?php echo e($facture->devis->numero); ?>

                                    </a>

                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fa fa-user mr-3"></i> Client :
                                        <?php echo e($facture->projet->client->prenom); ?>

                                        <?php echo e($facture->projet->client->nom); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fa fa-pen mr-3"></i> Note :
                                        <?php echo e($facture->note); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-money-bill-alt mr-3"></i> Total HT: <?php echo e($facture->total_ht); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-money-bill-alt mr-3"></i> Total TTC :
                                        <?php echo e($facture->total_ttc); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-money-bill-alt text-success mr-3"></i> Payé :
                                        <?php echo e($facture->montant_paye); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-money-bill-alt text-danger mr-3"></i> Reste :
                                        <?php echo e($facture->reste); ?>

                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fa fa-calendar mr-3"></i> Etat :
                                        <?php echo $facture->getEtatIconAttribute(); ?>

                                    </a>
                                </li>
                                <div wire:loading>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.animations.ballbeatdark','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('animations.ballbeatdark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                            </ul>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">

                            <div class="d-flex justify-content-between mb-2">
                                <h3 class="card-title">Paiements</h3>
                                <?php if($facture->is_valid == 1): ?>
                                    <a class="btn btn-sm btn-success ml-5"
                                        href="<?php echo e(route('printrecue', ['numero' => $facture->numero])); ?>"
                                        target="_blank">Imprimer tout mes maiements
                                        <i class="fa fa-print"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="scrollable-table" style="max-height: 300px; overflow-y: auto;">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Numero</th>
                                            <th>Date</th>
                                            <th>Payé</th>
                                            <th>Reste</th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $payements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->numero); ?></td>
                                                <td><?php echo e(date('d/m/Y à h:i', strtotime($item->created_at))); ?></td>
                                                <td><?php echo e($item->montant_paye); ?> $</td>
                                                <td class="text-danger"><?php echo e($item->reste); ?> $</td>
                                                <td>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'FactureItem-Supprimer')): ?>
                                                        <a href=""
                                                            wire:click.prevent="confirmItemRemoval(<?php echo e($item->id); ?>)">
                                                            <i class="fa fa-trash text-danger"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title mr-5">Articles de la facture</h3>

                            <div class="container">
                                <div class="d-flex justify-content-between mb-2">
                                    <?php if($facture->is_valid == 1): ?>
                                        <div class="btn-group ml-2">
                                            <button type="button" class="btn btn-default">Options</button>
                                            <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                                data-toggle="dropdown" aria-expanded="false">
                                                <span class="sr-only"></span>
                                            </button>
                                            <div class="dropdown-menu" role="menu" style="">
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('printfacture', ['numero' => $facture->numero])); ?>"
                                                    target="_blank">Imprimer Facture</a>


                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('printfactureclient', ['numero' => $facture->numero])); ?>"
                                                    target="_blank">Imprimer Facture pour client</a>
                                                    
                                                <a class="dropdown-item" href="#" wire:click.prevent="sendMail('<?php echo e($facture->numero); ?>')">Envoyer par mail</a> 
                                            </div>
                                        </div>

                                        <button class="btn btn-primary btn-sm" wire:click.prevent="addNew">
                                            <i class="fa fa-plus-circle mr-1"></i> Ajouter un paiement
                                        </button>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('admin.facture.edit', $facture)); ?>"> <i
                                            class="fa fa-pen-alt ml-3"></i></a>
                                </div>
                            </div>

                            <div class="card-tools">

                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-1">
                            <?php if($facture->is_valid == 1): ?>
                                <?php $__currentLoopData = $etapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($etape->facture_item->where('facture_id', $facture->id)->count() > 0): ?>
                                        <div class="alert alert-light m-1 d-flex justify-content-between align-items-center"
                                            role="alert">
                                            <strong><?php echo e(Str::upper($etape->nom_etape)); ?></strong>
                                        </div>
                                        <table class="table table-striped table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Numero</th>
                                                    <th scope="col">Titre</th>
                                                    <th scope="col">Unité</th>
                                                    <th scope="col">Qte</th>
                                                    <th scope="col">P.U</th>
                                                    <th scope="col">TVA</th>
                                                    <th scope="col">Rabais</th>
                                                    <th scope="col">Total HT</th>
                                                    <th scope="col">Total TTC</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $etape->facture_item->where('facture_id', $facture->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td><?php echo e(Str::ucfirst($item->numero)); ?></td>
                                                        <td><?php echo e(Str::ucfirst($item->titre)); ?></td>
                                                        <td><?php echo e(Str::upper($item->unite)); ?></td>
                                                        <td><?php echo e(Str::upper($item->qte)); ?></td>
                                                        <td><?php echo e(Str::upper($item->prix_u)); ?></td>
                                                        <td><?php echo e(Str::upper($item->prix_tva)); ?> $</td>
                                                        <td><?php echo e(Str::upper($item->prix_rabais)); ?> $</td>
                                                        <td><?php echo e(Str::upper($item->prix_ht)); ?> $
                                                        <td><?php echo e(Str::upper($item->prix_t)); ?> $
                                                        </td>
                                                        
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td colspan="10" class="text-right text-success">TVA
                                                        : <strong><?php echo e($etape->facture_item->sum('prix_tva')); ?>

                                                            $</strong> </th>
                                                    <td> </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="10" class="text-right text-danger">Rabais
                                                        : <strong><?php echo e($etape->facture_item->sum('rabais')); ?> $</strong>
                                                        </th>
                                                    <td> </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="10" class="text-right text-dark">
                                                        <strong>Sous Total : <?php echo e($etape->facture_item->sum('prix_t')); ?>

                                                            $</strong> </th>
                                                    <td> </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="container mt-2">
                                    <div class="d-flex justify-content-between mb-2">
                                        <strong>Total HT : <span
                                                class="text-success"><?php echo e(optional($facture->facture_item)->sum('prix_ht') ?? 0); ?></span>
                                            $</strong>
                                        <strong>TVA : <span
                                                class="text-success"><?php echo e(optional($facture->facture_item)->sum('prix_tva') ?? 0); ?></span>
                                            $</strong>
                                        <strong>Total TTC : <span
                                                class="text-success"><?php echo e(optional($facture->facture_item)->sum('prix_t') ?? 0); ?></span>
                                            $</strong>
                                        <strong>Total Payé : <span
                                                class="text-success"><?php echo e($facture->montant_paye ?? 0); ?></span>
                                            $</strong>
                                        <strong>Reste : <span class="text-danger"><?php echo e($facture->reste ?? 0); ?></span>
                                            $</strong>

                                    </div>
                                </div>
                            <?php else: ?>
                                <h1>Vous n'avez pas le droit de Visualiser ce contenu</h1>
                            <?php endif; ?>



                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        <span>Payement</span>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="<?php echo e($showEditModal ? 'updateItem' : 'createItem'); ?>"
                        wire:loading.attr="disabled">
                        <!-- Le contenu de votre formulaire -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Montant payé </label>
                                    <input type="number" min="0"
                                        class="form-control <?php $__errorArgs = ['montant_paye'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        wire:model="stateItem.montant_paye">
                                    <?php $__errorArgs = ['montant_paye'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Reste</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['reste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        min="0" wire:model="stateItem.reste">
                                    <?php $__errorArgs = ['reste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <h4 class="text-danger">Payé : <?php echo e($stateItem['montant_paye']); ?> USD</h4>
                        <h4 class="text-danger">Reste : <?php echo e($stateItem['reste']); ?> USD</h4>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>
                    <?php if($showEditModal): ?>
                        <button type="submit" class="btn btn-info" wire:loading.attr="disabled">
                            <i class="fa fa-save mr-1"></i> Enregistrer les modifications
                        </button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                            <i class="fa fa-save mr-1"></i> Enregistrer
                        </button>
                    <?php endif; ?>

                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Supprimer le Payement</h5>
                </div>
                <div class="modal-body">
                    <h4>Etes-vous sûr de vouloir supprimer ce Payement?</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>

                    <button type="button" wire:click.prevent='deleteItem' class="btn btn-danger"><i
                            class="fa fa-trash mr-1"></i>
                        Supprimer</button>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Dev\kgf1\kgf\resources\views/livewire/admin/facture/facture-show.blade.php ENDPATH**/ ?>