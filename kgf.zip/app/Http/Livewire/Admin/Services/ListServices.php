<?php

namespace App\Http\Livewire\Admin\Services;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Service;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListServices extends  AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $serviceIdBeingRemoved = null;
    public $service;
    public $searchTerm = null;
    public $selectedIds = [];
 

    
    public function addNew()
    {
        if (Gate::allows('access','Service-Ajouter')) {
            $this->showEditModal = false; 
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function createService()
    { 
        $validateData = Validator::make($this->state, [ 
            'name' => 'required',
            'description' => 'nullable',
        ], [ 
            'name.required' => "Le nom est obligatoire", 
        ])->validate();
            
            if (Gate::allows('access','Service-Ajouter')) {
                Service::create($validateData); 
                $this->dispatchBrowserEvent('hide-form', ['message' => "Service ajouté avec succès !"]); 
            }

            $this->state = [];
         
 
    }
    public function edit(Service $service)
    {
        if (Gate::allows('access','Service-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->service = $service;

            $this->state = $service->toArray();   
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateService()
    {
        $validateData = Validator::make($this->state, [ 
            'name' => 'required',
            'description' => 'nullable',
        ], [ 
            'name.required' => "Le nom est obligatoire", 
        ])->validate();
        
        if (Gate::allows('access','Service-Modifier')) {

            $this->service->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Service modifié avec succès !"]);
        }

        $this->state = [];  
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Service-Supprimer-Groupe')) {
            Service::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Service ont étés supprimés?']);

            $this->reset(['selectedRows','selectedPageRows']);
        }
    }
    public function confirmServiceRemoval($serviceId)
    {
        $this->serviceIdBeingRemoved = $serviceId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteService()
    {
        if (Gate::allows('access','Service-Supprimer')) {
            $service = Service::findOrFail($this->serviceIdBeingRemoved);
            $service->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Service suprimé avec succès !"]); 
        }  
    }
    public function render()
    {
        $services = Service::query()
                ->where('name','like', '%'.$this->searchTerm.'%') 
                ->latest()->paginate(12); 
        return view('livewire.admin.services.list-services', compact('services'));
    }
}
