<?php

namespace App\Http\Livewire\Admin\Devis;

use App\Models\DevisForage;
use App\Models\ProjetForage;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;
use Illuminate\Support\Str;

class DevisCreate extends Component
{
    public $state = [
        'etat' => 'En attente',
        'marge_ben' => 0,
        'validite' => 30,
        'tva' => 16, 
    ];

    public $conditions_general;
    public $garantie_rembourse;
    public $searchTerm = null;
    public $selectedProjet = null;

    public function getProjetsProperty()
    {
        return ProjetForage::orderBy('created_at', 'desc')->get();
    }
    public function generateDevisNumber()
    {
        $prefix = 'DEV'; // Préfixe du numéro de devis
        $randomPart = Str::random(6); // Partie alphanumérique aléatoire

        $latestDevis = DevisForage::latest('id')->first(); // Récupère le dernier devis créé

        if ($latestDevis) {
            $latestNumber = substr($latestDevis->numero, strlen($prefix)); // Extrait la partie numérique du dernier numéro de devis
            $nextNumber = intval($latestNumber) + 1; // Incrémente le numéro
        } else {
            $nextNumber = 1; // Si c'est le premier devis
        }

        $nextNumber = str_pad($nextNumber, 4, '0', STR_PAD_LEFT); // Remplit avec des zéros pour obtenir 4 chiffres

        return $prefix . $nextNumber . $randomPart;
    }
    
    public function updatedselectedProjet()
    {
        $this->emitUp('projetSelected', $this->selectedProjet);
    }
    public function createDevisForage($conditions_general,$garantie_rembourse)
    {
        $this->conditions_general = $conditions_general;
        $this->garantie_rembourse = $garantie_rembourse;

        $validatedData =  Validator::make($this->state, [
            'titre' => 'required',
            'note' => 'nullable',
            'etat' => 'nullable',
            'date' => 'required',
            'tva' => 'nullable',
            'modalite' => 'nullable',
            'echeance' => 'required',
            'coordonee_banc' => 'nullable',
            'delai_livraison' => 'nullable', 
            'contact' => 'nullable',
            'validite' => 'required',
            'marge_ben' => 'required',
            'projet_forage_id' => 'required'
        ], [
            'titre.required' => "Le champ Titre est obligatoire.",
            'date.required' => "Le champ date est obligatoire.",
            'validite.required' => "Le champ validité est obligatoire.",
            'marge_ben.required' => "Le champ Marge bénéficiaire est obligatoire.",
            'projet_forage_id.required' => "Le champ projet de forage est obligatoire.",
        ])->validate();

        $validatedData['numero'] = $this->generateDevisNumber();
        $validatedData['user_id'] = auth()->user()->id;

        $validatedData['conditions_general'] = $this->conditions_general ;
        $validatedData['garantie_rembourse'] = $this->garantie_rembourse;
            
        //dd($validatedData);
        
        if (Gate::allows('access', 'Devis-Forage-Ajouter')) {
            DevisForage::create($validatedData);
            $this->dispatchBrowserEvent('alert', ['message' => "Devis Forage creé avec succès !"]);
            $this->reset('state');
            return redirect()->route('admin.devis');
        }
    }
    public function render()
    {
        $projets = $this->projets;
        return view('livewire.admin.devis.devis-create', compact('projets'));
    }
}