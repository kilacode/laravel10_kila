<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('projet_forages', function (Blueprint $table) {
            $table->id();
            $table->string('nom_projet');
            $table->string('lieu');
            $table->integer('profondeur_souhaitee');
            $table->integer('diametre_souhaite');
            $table->string('etat_projet');
            $table->unsignedBigInteger('type_forage_id');
            $table->unsignedBigInteger('condition_geologique_id');
            $table->float('cout_total');
            $table->unsignedBigInteger('client_id')->nullable();
            $table->timestamps();

            $table->foreign('type_forage_id')->references('id')->on('type_forages')->onDelete('cascade');
            $table->foreign('condition_geologique_id')->references('id')->on('conditions_geologiques')->onDelete('cascade');
            $table->foreign('client_id')->references('id')->on('clients')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('projet_forages');
    }
};
