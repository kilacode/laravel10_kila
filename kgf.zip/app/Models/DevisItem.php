<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DevisItem extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function devis()
    {
        return $this->belongsTo(DevisForage::class,'devis_forage_id');
    }
    public function etape_forage()
    {
        return $this->belongsTo(EtapesForage::class,'etape_forage_id');
    }
}
