@push('js')
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    window.addEventListener('show-delete-confirmation', event => {
        Swal.fire({
            title: 'Etes-vous sur?',
            text: "Vous ne pourez plus le recupérer !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Annuler',
            confirmButtonText: 'Oui, Supprimer!'
        }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('deleteConfirmed')
            }
        })
    })

    window.addEventListener('deleted', event => {
        Swal.fire(
            'Supprimé!',
            event.detail.message,
            'success'
        )
    })
</script>
@endpush