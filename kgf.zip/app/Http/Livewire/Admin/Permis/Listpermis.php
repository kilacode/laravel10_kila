<?php

namespace App\Http\Livewire\Admin\Permis;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Permis;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class Listpermis extends AdminComponent
{
    public $state = ['cout_supplementaire'=>0];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $permisIdBeingRemoved = null;
    public $permis;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Permis-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    } 
    public function createPermis()
    { 

        $validateData = Validator::make($this->state, [ 
            'nom_permis' => 'required', 
            'cout_permis' => 'required', 
        ], [
            'nom_permis.required' => "Le nom est obligatoire", 
            'cout_permis.required' => "Le coût est obligatoire", 
        ])->validate(); 
        if (Gate::allows('access', 'permis-Ajouter')) {
            Permis::create($validateData);
            //$this->dispatchBrowserEvent('hide-form', ['message' => "permis géologique ajoutée avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(permis $permis)
    {
        if (Gate::allows('access', 'permis-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->permis = $permis;

            $this->state = $permis->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updatePermis()
    {
        $validateData = Validator::make($this->state, [ 
            'nom_permis' => 'required', 
            'cout_permis' => 'required', 
        ], [
            'nom_permis.required' => "Le nom est obligatoire", 
            'cout_permis.required' => "Le coût est obligatoire", 
        ])->validate();

        if (Gate::allows('access', 'permis-Modifier')) {

            $this->permis->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Permis modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Permis-Supprimer-Groupe')) {
            Permis::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos permis ont étés supprimés']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmPermisRemoval($permisId)
    {
        $this->permisIdBeingRemoved = $permisId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deletePermis()
    {
        if (Gate::allows('access', 'Permis-Supprimer')) {
            $permis = Permis::findOrFail($this->permisIdBeingRemoved);
            $permis->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Permis suprimé avec succès !"]);
        }
    }
    public function render()
    { 
        $permiss = Permis::query()
        ->where('nom_permis','like', '%'.$this->searchTerm.'%') 
        ->latest()->paginate(12); 
        return view('livewire.admin.permis.listpermis', compact('permiss'));
    }
}
