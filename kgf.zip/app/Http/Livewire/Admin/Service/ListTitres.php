<?php

namespace App\Http\Livewire\Admin\Service;

use Livewire\Component;

class ListTitres extends Component
{
    public function render()
    {
        return view('livewire.admin.service.list-titres');
    }
}
