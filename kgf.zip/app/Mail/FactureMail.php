<?php
namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage; // Importez la classe Storage
use Illuminate\Support\Facades\URL; // Importez la classe URL

class FactureMail extends Mailable
{
    use Queueable, SerializesModels;

    protected $numero;

    /**
     * Create a new message instance.
     */
    public function __construct($numero)
    {
        $this->numero = $numero;
    }

    // ...

    /**
     * Build the message.
     */
    public function build()
    {
        // Générer le PDF en utilisant la route printfactureclient
        $pdfFilePath = public_path('temp_facture.pdf'); // Emplacement temporaire du PDF
        $pdfUrl = URL::signedRoute('printfactureclient', ['numero' => $this->numero]);
        file_put_contents($pdfFilePath, file_get_contents($pdfUrl));

        // Ajouter le PDF en tant que pièce jointe
        $pdfFileName = 'facture.pdf';
        $pdfMimeType = 'application/pdf';

        return $this->view('mails.facture')
            ->attach($pdfFilePath, [
                'as' => $pdfFileName,
                'mime' => $pdfMimeType,
            ]);
    }
}
