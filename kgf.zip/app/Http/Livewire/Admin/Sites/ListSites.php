<?php

namespace App\Http\Livewire\Admin\Sites;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Site;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListSites extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $siteIdBeingRemoved = null;
    public $site;
    public $searchTerm = null;
    public $selectedIds = [];
 

    
    public function addNew()
    {
        if (Gate::allows('access','Site-Ajouter')) {
            $this->showEditModal = false; 
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function createSite()
    { 
        $validateData = Validator::make($this->state, [ 
            'name' => 'required',
            'email' => 'required|email',
            'phone_number' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'zip_code' => 'required|numeric',
            'country' => 'required',
        ], [ 
            'name.required' => "Le nom est obligatoire",
            'email.required' => "L'adresse e-mail est obligatoire",
            'email.email' => "L'adresse e-mail n'est pas valide",
            'phone_number.required' => "Le numéro de téléphone est obligatoire",
            'phone_number.numeric' => "Le numéro de téléphone doit être un nombre",
            'address.required' => "L'adresse est obligatoire",
            'city.required' => "La ville est obligatoire",
            'state.required' => "L'état est obligatoire",
            'zip_code.required' => "Le code postal est obligatoire",
            'zip_code.numeric' => "Le code postal doit être un nombre",
            'country.required' => "Le pays est obligatoire",
        ])->validate();
            
            if (Gate::allows('access','Site-Ajouter')) {
                Site::create($validateData); 
                $this->dispatchBrowserEvent('hide-form', ['message' => "Site ajouté avec succès !"]); 
            }

            $this->state = [];
         
 
    }
    public function edit(Site $site)
    {
        if (Gate::allows('access','Site-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->site = $site;

            $this->state = $site->toArray();   
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateSite()
    {
        $validateData = Validator::make($this->state, [ 
            'name' => 'required',
            'email' => 'required|email',
            'phone_number' => 'required|numeric',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'zip_code' => 'required',
            'country' => 'required',
        ], [ 
            'name.required' => "Le nom est obligatoire",
            'email.required' => "L'adresse e-mail est obligatoire",
            'email.email' => "L'adresse e-mail n'est pas valide",
            'phone_number.required' => "Le numéro de téléphone est obligatoire",
            'phone_number.numeric' => "Le numéro de téléphone doit être un nombre",
            'address.required' => "L'adresse est obligatoire",
            'city.required' => "La ville est obligatoire",
            'state.required' => "L'état est obligatoire",
            'zip_code.required' => "Le code postal est obligatoire",
            'zip_code.numeric' => "Le code postal doit être un nombre",
            'country.required' => "Le pays est obligatoire",
        ])->validate();
        
        if (Gate::allows('access','Site-Modifier')) {

            $this->site->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Site modifié avec succès !"]);
        }

        $this->state = [];  
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Site-Supprimer-Groupe')) {
            Site::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Site ont étés supprimés?']);

            $this->reset(['selectedRows','selectedPageRows']);
        }
    }
    public function confirmSiteRemoval($siteId)
    {
        $this->siteIdBeingRemoved = $siteId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteSite()
    {
        if (Gate::allows('access','Site-Supprimer')) {
            $site = Site::findOrFail($this->siteIdBeingRemoved);
            $site->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Site suprimé avec succès !"]); 
        }  
        
    }
    public function render()
    {
        $sites = Site::query()
                ->where('name','like', '%'.$this->searchTerm.'%') 
                ->latest()->paginate(12); 
        return view('livewire.admin.sites.list-sites', compact('sites'));
    }
}
