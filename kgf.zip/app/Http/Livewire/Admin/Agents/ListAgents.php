<?php

namespace App\Http\Livewire\Admin\Agents;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Agent;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListAgents extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $agentIdBeingRemoved = null;
    public $agent;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Agent-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }


    public function generateAgentNumber()
    {
        $lastAgent = Agent::orderBy('id', 'desc')->first();

        if (!$lastAgent) {
            // Si aucun agent n'existe, commencer avec le numéro 1
            return 'AGENT001' . $this->generateRandomChars(10);
        }

        // Extraire le numéro de l'agent à partir du matricule (en supposant que le format est "AGENTxxx")
        $lastNumber = (int) substr($lastAgent->matricule, 5, 3);

        // Incrémenter le numéro de l'agent pour le prochain agent
        $nextNumber = $lastNumber + 1;

        // Formater le numéro avec un zéro rempli à gauche pour avoir une longueur de 3 chiffres (ex : "002")
        $nextNumberPadded = str_pad($nextNumber, 3, '0', STR_PAD_LEFT);

        // Construire le matricule complet avec le préfixe "AGENT", le numéro incrémenté et les caractères alphanumériques aléatoires
        $newAgentNumber = 'AGENT' . $nextNumberPadded . $this->generateRandomChars(10);

        return $newAgentNumber;
    }

    public function generateRandomChars($length)
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomChars = '';

        for ($i = 0; $i < $length; $i++) {
            $randomChars .= $characters[rand(0, strlen($characters) - 1)];
        }

        return $randomChars;
    }

    public function createAgent()
    { 

        $validateData = Validator::make($this->state, [
            'matricule' => 'nullable', 
            'nom' => 'required',
            'postnom' => 'nullable',
            'prenom' => 'required',
            'nationalite' => 'required',
            'date_naissance' => 'required',
            'lieu_naissance' => 'required',
            'sexe' => 'required',
            'profession' => 'required',
            'province_origine' => 'required',
            'email' => 'required|email',
            'telephone' => 'required',
            'adresse' => 'required',
            'numero_carte_identite' => 'required',
            'date_expiration_carte_identite' => 'nullable',
        ], [
            'nom.required' => "Le nom est obligatoire",
            'postnom.required' => "Le postnom est obligatoire",
            'province_origine.required' => "La provincce d\'origine est obligatoire",
            'prenom.required' => "Le prénom est obligatoire",
            'nationalite.required' => "La nationalité est obligatoire",
            'date_naissance.required' => "La date de naissance est obligatoire",
            'lieu_naissance.required' => "Le lieu de naissance est obligatoire",
            'sexe.required' => "Le sexe est obligatoire",
            'profession.required' => "La profession est obligatoire",
            'email.required' => "L'email est obligatoire",
            'email.email' => "L'email n'est pas valide",
            'telephone.required' => "Le téléphone est obligatoire",
            'adresse.required' => "L'adresse est obligatoire",
            'numero_carte_identite.required' => "Le numéro de carte d'identité est obligatoire",
            'date_expiration_carte_identite.required' => "La date d'expiration de la carte d'identité est obligatoire",
        ])->validate();

        $validateData['numero'] = $this->generateAgentNumber();
        if (Gate::allows('access', 'Agent-Ajouter')) {
            Agent::create($validateData);
            $this->dispatchBrowserEvent('hide-form', ['message' => "Agent ajouté avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(Agent $agent)
    {
        if (Gate::allows('access', 'Agent-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->agent = $agent;

            $this->state = $agent->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateAgent()
    {
        $validateData = Validator::make($this->state, [
            'matricule' => 'nullable',
            'numero' => 'nullable',
            'nom' => 'required',
            'postnom' => 'nullable',
            'prenom' => 'required',
            'nationalite' => 'required',
            'date_naissance' => 'required',
            'lieu_naissance' => 'required',
            'province_origine' => 'required',
            'sexe' => 'required',
            'profession' => 'required',
            'email' => 'required|email',
            'telephone' => 'required',
            'adresse' => 'required',
            'numero_carte_identite' => 'required',
            'date_expiration_carte_identite' => 'nullable',
        ], [
            'nom.required' => "Le nom est obligatoire",
            'postnom.required' => "Le postnom est obligatoire",
            'province_origine.required' => "La provincce d\'origine est obligatoire",
            'prenom.required' => "Le prénom est obligatoire",
            'nationalite.required' => "La nationalité est obligatoire",
            'date_naissance.required' => "La date de naissance est obligatoire",
            'lieu_naissance.required' => "Le lieu de naissance est obligatoire",
            'sexe.required' => "Le sexe est obligatoire",
            'profession.required' => "La profession est obligatoire",
            'email.required' => "L'email est obligatoire",
            'email.email' => "L'email n'est pas valide",
            'telephone.required' => "Le téléphone est obligatoire",
            'adresse.required' => "L'adresse est obligatoire",
            'numero_carte_identite.required' => "Le numéro de carte d'identité est obligatoire",
            'date_expiration_carte_identite.required' => "La date d'expiration de la carte d'identité est obligatoire",
        ])->validate();

        if (Gate::allows('access', 'Agent-Modifier')) {

            $this->Agent->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Agent modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Agent-Supprimer-Groupe')) {
            Agent::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Agent ont étés supprimés?']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmAgentRemoval($agentId)
    {
        $this->agentIdBeingRemoved = $agentId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteAgent()
    {
        if (Gate::allows('access', 'Agent-Supprimer')) {
            $agent = Agent::findOrFail($this->AgentIdBeingRemoved);
            $agent->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Agent suprimé avec succès !"]);
        }
    }
    public function render()
    {
        $searchTerm = '%' . $this->searchTerm . '%';

        $agents = Agent::query()
            ->where(function ($query) use ($searchTerm) {
                $query->whereRaw("CONCAT(nom, ' ', postnom, ' ', prenom) LIKE ?", [$searchTerm])
                    ->orWhereRaw("CONCAT(nom, ' ', prenom, ' ', postnom) LIKE ?", [$searchTerm])
                    ->orWhereRaw("CONCAT(postnom, ' ', nom, ' ', prenom) LIKE ?", [$searchTerm])
                    ->orWhereRaw("CONCAT(postnom, ' ', prenom, ' ', nom) LIKE ?", [$searchTerm])
                    ->orWhereRaw("CONCAT(prenom, ' ', nom, ' ', postnom) LIKE ?", [$searchTerm])
                    ->orWhereRaw("CONCAT(prenom, ' ', postnom, ' ', nom) LIKE ?", [$searchTerm]);
            })
            ->latest()
            ->paginate(12);

        return view('livewire.admin.agents.list-agents', compact('agents'));
    }
}