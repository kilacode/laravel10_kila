<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Agents</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Agents</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">

                        <button class="btn btn-primary " wire:click.prevent="addNew">
                            <i class="fa fa-plus-circle mr-1"></i> Ajouter Agent
                        </button>

                        @if ($selectedRows)
                            <div class="btn-group ml-2">
                                <button type="button" class="btn btn-default">Options</button>
                                <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                    data-toggle="dropdown" aria-expanded="false">
                                    <span class="sr-only"></span>
                                </button>
                                <div class="dropdown-menu" role="menu" style="">
                                    <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                        href="#">Supprimer les Agents sélectionnés</a>
                                </div>
                            </div>
                            <span class="ml-2">{{ count($selectedRows) }}
                                {{ Str::plural(' Agent', count($selectedRows)) }}
                                {{ Str::plural(' sélectionné', count($selectedRows)) }} </span>
                        @endif

                        <x-search-input wire:model='searchTerm' />
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th></th>
                                            <th>Nom</th>
                                            <th>Postnom</th>
                                            <th>Prénom</th>
                                            <th>Nationalité</th>
                                            <th>Sexe</th>
                                            <th>Email</th>
                                            <th>Téléphone</th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($agents as $agent)
                                            <tr>
                                                <th style="width: 10px;">
                                                    {{ $loop->iteration }}

                                                </th>
                                                <td>
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="{{ $agent->id }}"
                                                            value="{{ $agent->id }}">
                                                        <label for="{{ $agent->id }}"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </td>
                                                <td>{{ $agent->nom }}</td>
                                                <td>{{ $agent->postnom }}</td>
                                                <td>{{ $agent->prenom }}</td>
                                                <td>{{ $agent->nationalite }}</td>
                                                <td>{{ $agent->sexe }}</td>
                                                <td>{{ $agent->email }}</td>
                                                <td>{{ $agent->telephone }}</td>
                                                <td>
                                                    @can('access', 'Agent-Modifier')
                                                        <a href="" wire:click.prevent="edit({{ $agent }})">
                                                            <i class="fa fa-edit mr-2"></i>
                                                        </a>
                                                    @endcan
                                                    @can('access', 'Agent-Supprimer')
                                                        <a href=""
                                                            wire:click.prevent="confirmAgentRemoval({{ $agent->id }})">
                                                            <i class="fa fa-trash text-danger"></i>
                                                        </a>
                                                    @endcan
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="9">
                                                    <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>


                            </div>

                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            {{ $agents->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        @if ($showEditModal == true)
                            <span>Modifier l'Agent</span>
                        @else
                            <span>Ajout d'une nouvelle Agent</span>
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="{{ $showEditModal ? 'updateAgent' : 'createAgent' }}">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="matricule">Matricule</label>
                                    <input type="text" class="form-control @error('matricule') is-invalid @enderror"
                                        wire:model.defer="state.matricule" id="matricule"
                                        placeholder="Matricule de l'Agent">

                                    @error('matricule')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nom">Nom</label>
                                    <input type="text" class="form-control @error('nom') is-invalid @enderror"
                                        wire:model.defer="state.nom" id="nom" placeholder="Nom de l'Agent">

                                    @error('nom')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="postnom">PostNom</label>
                                    <input type="text" class="form-control @error('postnom') is-invalid @enderror"
                                        wire:model.defer="state.postnom" id="postnom"
                                        placeholder="postNom de l'Agent">

                                    @error('postnom')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="prenom">PreNom</label>
                                    <input type="text" class="form-control @error('prenom') is-invalid @enderror"
                                        wire:model.defer="state.prenom" id="prenom"
                                        placeholder="PreNom de l'Agent">

                                    @error('prenom')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nationalite">Nationalité</label>
                                    <select class="form-control" wire:model.defer="state.nationalite">
                                        <option value="">Choisissez une nationalité</option>
                                        <option value="Algérie">Algérie</option>
                                        <option value="Angola">Angola</option>
                                        <option value="Bénin">Bénin</option>
                                        <option value="Botswana">Botswana</option>
                                        <option value="Burkina Faso">Burkina Faso</option>
                                        <option value="Burundi">Burundi</option>
                                        <option value="Cameroun">Cameroun</option>
                                        <option value="Cap-Vert">Cap-Vert</option>
                                        <option value="Comores">Comores</option>
                                        <option value="congo rdc">Congo RDC</option>
                                    </select>

                                    @error('nationalite')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="lieu_naissance">Lieu de naissance</label>
                                    <input type="text"
                                        class="form-control @error('lieu_naissance') is-invalid @enderror"
                                        wire:model.defer="state.lieu_naissance" id="lieu_naissance"
                                        placeholder="Lieu de naissance">

                                    @error('lieu_naissance')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="appointmentDate">Date de naissance :</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fa fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                        <x-datepicker wire:model.defer="state.date_naissance" id="appointmentDate"
                                            :error="'date_naissance'" />
                                        @error('date_naissance')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="">Sexe :</label>
                                <select class="form-control" wire:model.defer="state.sexe">
                                    <option value="">Sexe</option>
                                    <option value="homme">Homme</option>
                                    <option value="femme">Femme</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="profession">Profession</label>
                                    <input type="text" class="form-control" wire:model.defer="state.profession"
                                        id="profession" placeholder="Votre profession">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" wire:model.defer="state.email"
                                        id="email" placeholder="Votre email">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="telephone">Téléphone</label>
                                    <input type="tel" class="form-control" wire:model.defer="state.telephone"
                                        id="telephone" placeholder="Votre numéro de téléphone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="adresse">Adresse</label>
                                    <input type="text" class="form-control" wire:model.defer="state.adresse"
                                        id="adresse" placeholder="Votre adresse">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="numero_carte_identite">Numéro de carte d'identité</label>
                                    <input type="text" class="form-control"
                                        wire:model.defer="state.numero_carte_identite" id="numero_carte_identite"
                                        placeholder="Votre numéro de carte d'identité">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="province">Province</label>
                                    <select class="form-control" wire:model.defer="state.province_origine">
                                        <option value="">Choisissez une province</option>
                                        <option value="Kinshasa">Kinshasa</option>
                                        <option value="Bandundu">Bandundu</option>
                                        <option value="Bas-Congo">Bas-Congo</option>
                                        <option value="Équateur">Équateur</option>
                                        <option value="Kasaï">Kasaï</option>
                                        <option value="Kasaï-Central">Kasaï-Central</option>
                                        <option value="Kasaï-Oriental">Kasaï-Oriental</option>
                                        <option value="Kongo-Central">Kongo-Central</option>
                                        <option value="Kongo-Kinshasa">Kongo-Kinshasa</option>
                                        <option value="Kwilu">Kwilu</option>
                                        <option value="Lomami">Lomami</option>
                                        <option value="Lualaba">Lualaba</option>
                                        <option value="Lupopo">Lupopo</option>
                                        <option value="Maniema">Maniema</option>
                                        <option value="Mongala">Mongala</option>
                                        <option value="Nord-Kivu">Nord-Kivu</option>
                                        <option value="Sud-Kivu">Sud-Kivu</option>
                                        <option value="Tanganyika">Tanganyika</option>
                                        <option value="Tshopo">Tshopo</option>
                                        <option value="Ubangi-Central">Ubangi-Central</option>
                                        <option value="Ubangi-Sud">Ubangi-Sud</option>
                                        <option value="Haut-Lomami">Haut-Lomami</option>
                                        <option value="Haut-Uele">Haut-Uele</option>
                                        <option value="Tshopo">Tshopo</option>
                                    </select>

                                    @error('province')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="appointmentDate1">Date d'expiration de la carte</label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="fa fa-calendar-alt"></i>
                                                </span>
                                            </div>
                                            <x-datepicker wire:model.defer="state.date_expiration_carte_identite"
                                                id="appointmentDate1" :error="'date_expiration_carte_identite'" />
                                            @error('date_expiration_carte_identite')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>
                    @if ($showEditModal)
                        <button type="submit" class="btn btn-info"><i class="fa fa-save mr-1"></i> Enregistrer les
                            modifications</button>
                    @else
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-1"></i>
                            Enregistrer</button>
                    @endif
                </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Supprimer l'Agent</h5>
                </div>
                <div class="modal-body">
                    <h4>Etes-vous sûr de vouloir supprimer cet Agent?</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>

                    <button type="button" wire:click.prevent='deleteAgent' class="btn btn-danger"><i
                            class="fa fa-trash mr-1"></i>
                        Supprimer</button>

                </div>
            </div>
        </div>
    </div>
</div>
