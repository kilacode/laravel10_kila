<div>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Devis</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Devis</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            <a href="{{ route('admin.devis.create') }}">
                                <button class="btn btn-primary ">
                                    <i class="fa fa-plus-circle mr-1"></i> Ajouter
                                </button>
                            </a>
                            @if ($selectedRows)
                                <div class="btn-group ml-2">
                                    <button type="button" class="btn btn-default">Action</button>
                                    <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                        data-toggle="dropdown" aria-expanded="false">
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>

                                    <div class="dropdown-menu" role="menu" style="">
                                        <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                            href="#">Supprimer Devis sélectionnés</a>
                                        <a wire:click.prevent="markAsEnAttente" class="dropdown-item"
                                            href="#">Marquer comme En attente</a>
                                        <a wire:click.prevent="markAsValide" class="dropdown-item"
                                            href="#">Marquer comme Validé</a>
                                        <a wire:click.prevent="markAsTermine" class="dropdown-item"
                                            href="#">Marquer comme Terminé</a>
                                        <a wire:click.prevent="markAsEnCours" class="dropdown-item"
                                            href="#">Marquer comme En cours</a>
                                        <a wire:click.prevent="markAsEnAnnule" class="dropdown-item"
                                            href="#">Marquer comme Annulé</a>


                                        <a wire:click.prevent="export" class="dropdown-item" href="#">Exporter</a>
                                    </div>
                                </div>

                                <span class="ml-2">{{ count($selectedRows) }}
                                    {{ Str::plural(' Devis', count($selectedRows)) }} <i class="fa fa-check"></i></span>
                            @endif
                        </div>

                        <div class="btn-group">
                            <button wire:click="filterDevisByStatus" type="button"
                                class="btn {{ is_null($status) ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Tout</span>
                                <span class="badge badge-pull badge-info">{{ $devisCount }}</span>
                            </button>
                            <button wire:click="filterDevisByStatus('En attente')" type="button"
                                class="btn {{ $status == 'En attente' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En attente</span>
                                <span class="badge badge-pull badge-warning">{{ $devisEnAttenteCount }}</span>
                            </button>
                            <button wire:click="filterDevisByStatus('Validé')" type="button"
                                class="btn {{ $status == 'Validé' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Validé</span>
                                <span class="badge badge-pull badge-info">{{ $devisValideCount }}</span>
                            </button>
                            <button wire:click="filterDevisByStatus('Terminé')" type="button"
                                class="btn {{ $status == 'Terminé' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Terminé</span>
                                <span class="badge badge-pull badge-success">{{ $devisTermineCount }}</span>
                            </button>
                            <button wire:click="filterDevisByStatus('En cours')" type="button"
                                class="btn {{ $status == 'En cours' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En cours</span>
                                <span class="badge badge-pull badge-dark">{{ $devisEnCoursCount }}</span>
                            </button>
                            <button wire:click="filterDevisByStatus(Annulé')" type="button"
                                class="btn {{ $status == 'Annulé' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Annulé</span>
                                <span class="badge badge-pull badge-warning">{{ $devisAnnuleCount }}</span>
                            </button>

                        </div>


                        <x-search-input wire:model='searchTerm' />
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="custom-control custom-checkbox">
                                                    <input wire:model="selectedPageRows" class="custom-control-input"
                                                        type="checkbox" id="customCheckbox1" value="">
                                                    <label for="customCheckbox1" class="custom-control-label"></label>
                                                </div>
                                            </th>
                                            <th>#</th>
                                            <th>Titre</th>
                                            <th>Numéro</th>
                                            <th>Projet</th>
                                            <th>État du devis</th>
                                            <th>Diamètre Souhaité</th>
                                            <th>Profondeur Souhaité</th>
                                            <th>TVA</th>
                                            <th>Coût Total</th>
                                            <th>Client</th>
                                            <th>Utilisateur</th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody wire:loading.class='text-muted'>
                                        @forelse ($deviss as $devis)
                                            <tr>
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="{{ $devis->id }}"
                                                            value="{{ $devis->id }}">
                                                        <label for="{{ $devis->id }}"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>

                                                <th scope="row">{{ $loop->iteration }}</td>
                                                <td><a href="{{ route('admin.devis.show', $devis) }}"><i
                                                            class="fa fa-eye mr-2"></i>{{ Str::upper($devis->titre) }}</a>
                                                </td>
                                                <td>{{ $devis->numero }} </td>
                                                <td>{{ $devis->projetForage->nom_projet }}</td>
                                                <td> {!! $devis->getEtatIconAttribute() !!} </td>
                                                <td>{{ $devis->projetForage->diametre_souhaite }} m</td>
                                                <td>{{ $devis->projetForage->profondeur_souhaitee }} m</td>
                                                <td>{{ number_format($devis->prix_tva, 2, ',', ' ') }} $</td>
                                                <td>{{ number_format($devis->total_ttc, 2, ',', ' ') }} $</td>
                                                <td>{{ Str::upper($devis->projetForage->client->nom) }}</td>
                                                <td>{{ Str::upper($devis->user->name) }}</td>
                                                <td>
                                                    @can('access', 'Devis-Forage-Modifier')
                                                        <a href="{{ route('admin.devis.edit', $devis) }}"><i
                                                                class="fa fa-edit mr-2"></i></a>
                                                    @endcan

                                                    @can('access', 'Devis-Forage-Supprimer')
                                                        <a href=""
                                                            wire:click.prevent="confirmDevisRemoval({{ $devis->id }})"><i
                                                                class="fa fa-trash text-danger"></i></a>
                                                    @endcan
                                                    @can('access', 'Devis-Forage-Modifier')
                                                        <a href=""
                                                            wire:click.prevent="toggleDevisValidity({{ $devis }})">
                                                            @if ($devis->is_valid == 1)
                                                                <i class="fa fa-unlock text-success ml-2"></i>
                                                                <!-- Afficher le cadenas ouvert -->
                                                            @else
                                                                <i class="fa fa-lock text-danger ml-2"></i>
                                                                <!-- Afficher le cadenas fermé -->
                                                            @endif
                                                        </a>
                                                    @endcan
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="11">
                                                    <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        @endforelse

                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            {!! $deviss->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <x-confirmation-alert />
</div>

@push('styles')
    <style>
        .draggable-mirror {
            background-color: white;
            width: 950px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
@endpush
