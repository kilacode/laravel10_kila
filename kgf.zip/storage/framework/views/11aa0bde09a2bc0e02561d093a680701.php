<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="brand-link">
        <img src="<?php echo e(asset('backend/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo"
            class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">KGF</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('backend/img/users/' . auth()->user()->avatar)); ?>" id="profileImag"
                    class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(Str::ucfirst(auth()->user()->name)); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">

            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

                <li class="nav-item">
                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Tableau de bord
                        </p>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Client-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.clients')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/clients') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-user"></i>
                            <p>
                                Clients
                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Agent-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.agents')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/agents') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-user-tie"></i>
                            <p>
                                Agents
                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="nav-item menu-open">

                    <a href="#"
                        class="nav-link <?php echo e(request()->is('admin/types_de_forages') ||
                        request()->is('admin/conditions_geologiques') ||
                        request()->is('admin/equipements') ||
                        request()->is('admin/main_d_oeuvre') ||
                        request()->is('admin/approvisionnement_en_eau') ||
                        request()->is('admin/permis_et_reglementations') ||
                        request()->is('admin/projets') ||
                        request()->is('admin/ajouter_projet') ||
                        request()->is('admin/devis_create') ||
                        request()->is('admin/devis_edit/*') ||
                        request()->is('admin/devis_show/*') ||
                        request()->is('admin/etapes_forage') ||
                        request()->is('admin/devis') || request()->is('admin/factures') 
                            ? 'active'
                            : ''); ?>">
                        <i class="nav-icon fas fa-project-diagram"></i>
                        <p>
                            Projet de forages
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Projet-Forage-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.projects')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/projets') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Projets de forages</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Devis-Forage-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.devis')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/devis') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Devis de forages</p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Facture-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.factures')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/factures') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Factures</p>
                                </a>
                            </li>
                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Type-forage-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.types_forage')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/types_de_forages') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Types de forages</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Etape-forage-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.etapes_forage')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/etapes_forage') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Etapes de forages</p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Condition-geologique-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.conditions_geologiques')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/conditions_geologiques') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Conditions géologiques</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Equipement-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.equipements')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/equipements') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Equipements</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Maindoeuvre-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.main_d_oeuvre')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/main_d_oeuvre') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Main d'oeuvre</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Approvisionnement-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.approvisionnement_en_eau')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/approvisionnement_en_eau') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Approvisionnement Eau</p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Permis-Ajouter')): ?>
                            <li class="nav-item ">
                                <a href="<?php echo e(route('admin.permis')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/permis_et_reglementations') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Permis et Regl.</p>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Site-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.sites')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/sites') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-map-marker"></i>
                            <p>
                                Sites
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Service-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.services')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/services') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-building"></i>
                            <p>
                                Services
                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Fonction-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.fonctions')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/fonctions') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-check"></i>
                            <p>
                                Fonctions
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Titre-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.titres')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/titres') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-chart-line"></i>
                            <p>
                                Titres
                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'User-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.users')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/users') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-users"></i>
                            <p>
                                Utilisateurs
                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Modele-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.modeles')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/modeles') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-code"></i>
                            <p>
                                Gestion des Modèles
                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Acces-Ajouter')): ?>
                    <li class="nav-item menu-open">
                        <a href="<?php echo e(route('admin.acces')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/acces') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-user-cog"></i>
                            <p>
                                Gestion des Accès
                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Acces-Ajouter')): ?>
                    <li class="nav-item  ">
                        <a href="<?php echo e(route('admin.settings')); ?>"
                            class="nav-link <?php echo e(request()->is('admin/settings') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-cog"></i>
                            <p>
                                Reglages
                            </p>
                        </a>
                    </li>
                <?php endif; ?>


                <li class="nav-item menu-open">
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); this.closest('form').submit();" class="nav-link">
                            <i class="nav-icon fas fa-sign-out-alt"></i>
                            <p>
                                Deconnexion
                            </p>
                        </a>
                    </form>
                </li>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>



            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH D:\Dev\kgf\resources\views/layouts/partials/aside.blade.php ENDPATH**/ ?>