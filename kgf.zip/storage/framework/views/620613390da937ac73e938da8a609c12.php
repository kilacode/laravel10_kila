<div>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Devis</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Devis</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            <a href="<?php echo e(route('admin.devis.create')); ?>">
                                <button class="btn btn-primary ">
                                    <i class="fa fa-plus-circle mr-1"></i> Ajouter
                                </button>
                            </a>
                            <?php if($selectedRows): ?>
                                <div class="btn-group ml-2">
                                    <button type="button" class="btn btn-default">Action</button>
                                    <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                        data-toggle="dropdown" aria-expanded="false">
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>

                                    <div class="dropdown-menu" role="menu" style="">
                                        <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                            href="#">Supprimer Devis sélectionnés</a>
                                        <a wire:click.prevent="markAsEnAttente" class="dropdown-item"
                                            href="#">Marquer comme En attente</a>
                                        <a wire:click.prevent="markAsValide" class="dropdown-item"
                                            href="#">Marquer comme Validé</a>
                                        <a wire:click.prevent="markAsTermine" class="dropdown-item"
                                            href="#">Marquer comme Terminé</a>
                                        <a wire:click.prevent="markAsEnCours" class="dropdown-item"
                                            href="#">Marquer comme En cours</a>
                                        <a wire:click.prevent="markAsEnAnnule" class="dropdown-item"
                                            href="#">Marquer comme Annulé</a>


                                        <a wire:click.prevent="export" class="dropdown-item" href="#">Exporter</a>
                                    </div>
                                </div>

                                <span class="ml-2"><?php echo e(count($selectedRows)); ?>

                                    <?php echo e(Str::plural(' Devis', count($selectedRows))); ?> <i class="fa fa-check"></i></span>
                            <?php endif; ?>
                        </div>

                        <div class="btn-group">
                            <button wire:click="filterDevisByStatus" type="button"
                                class="btn <?php echo e(is_null($status) ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Tout</span>
                                <span class="badge badge-pull badge-info"><?php echo e($devisCount); ?></span>
                            </button>
                            <button wire:click="filterDevisByStatus('En attente')" type="button"
                                class="btn <?php echo e($status == 'En attente' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En attente</span>
                                <span class="badge badge-pull badge-warning"><?php echo e($devisEnAttenteCount); ?></span>
                            </button>
                            <button wire:click="filterDevisByStatus('Validé')" type="button"
                                class="btn <?php echo e($status == 'Validé' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Validé</span>
                                <span class="badge badge-pull badge-info"><?php echo e($devisValideCount); ?></span>
                            </button>
                            <button wire:click="filterDevisByStatus('Terminé')" type="button"
                                class="btn <?php echo e($status == 'Terminé' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Terminé</span>
                                <span class="badge badge-pull badge-success"><?php echo e($devisTermineCount); ?></span>
                            </button>
                            <button wire:click="filterDevisByStatus('En cours')" type="button"
                                class="btn <?php echo e($status == 'En cours' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En cours</span>
                                <span class="badge badge-pull badge-dark"><?php echo e($devisEnCoursCount); ?></span>
                            </button>
                            <button wire:click="filterDevisByStatus(Annulé')" type="button"
                                class="btn <?php echo e($status == 'Annulé' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Annulé</span>
                                <span class="badge badge-pull badge-warning"><?php echo e($devisAnnuleCount); ?></span>
                            </button>

                        </div>


                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-input','data' => ['wire:model' => 'searchTerm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'searchTerm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="custom-control custom-checkbox">
                                                    <input wire:model="selectedPageRows" class="custom-control-input"
                                                        type="checkbox" id="customCheckbox1" value="">
                                                    <label for="customCheckbox1" class="custom-control-label"></label>
                                                </div>
                                            </th>
                                            <th>#</th>
                                            <th>Titre</th>
                                            <th>Numéro</th>
                                            <th>Projet</th>
                                            <th>État du devis</th>
                                            <th>Diamètre Souhaité</th>
                                            <th>Profondeur Souhaité</th>
                                            <th>TVA</th>
                                            <th>Coût Total</th>
                                            <th>Client</th>
                                            <th>Utilisateur</th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody wire:loading.class='text-muted'>
                                        <?php $__empty_1 = true; $__currentLoopData = $deviss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="<?php echo e($devis->id); ?>"
                                                            value="<?php echo e($devis->id); ?>">
                                                        <label for="<?php echo e($devis->id); ?>"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>

                                                <th scope="row"><?php echo e($loop->iteration); ?></td>
                                                <td><a href="<?php echo e(route('admin.devis.show', $devis)); ?>"><i
                                                            class="fa fa-eye mr-2"></i><?php echo e(Str::upper($devis->titre)); ?></a>
                                                </td>
                                                <td><?php echo e($devis->numero); ?> </td>
                                                <td><?php echo e($devis->projetForage->nom_projet); ?></td>
                                                <td> <?php echo $devis->getEtatIconAttribute(); ?> </td>
                                                <td><?php echo e($devis->projetForage->diametre_souhaite); ?> m</td>
                                                <td><?php echo e($devis->projetForage->profondeur_souhaitee); ?> m</td>
                                                <td><?php echo e(number_format($devis->prix_tva, 2, ',', ' ')); ?> $</td>
                                                <td><?php echo e(number_format($devis->total_ttc, 2, ',', ' ')); ?> $</td>
                                                <td><?php echo e(Str::upper($devis->projetForage->client->nom)); ?></td>
                                                <td><?php echo e(Str::upper($devis->user->name)); ?></td>
                                                <td>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Devis-Forage-Modifier')): ?>
                                                        <a href="<?php echo e(route('admin.devis.edit', $devis)); ?>"><i
                                                                class="fa fa-edit mr-2"></i></a>
                                                    <?php endif; ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Devis-Forage-Supprimer')): ?>
                                                        <a href=""
                                                            wire:click.prevent="confirmDevisRemoval(<?php echo e($devis->id); ?>)"><i
                                                                class="fa fa-trash text-danger"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Devis-Forage-Modifier')): ?>
                                                        <a href=""
                                                            wire:click.prevent="toggleDevisValidity(<?php echo e($devis); ?>)">
                                                            <?php if($devis->is_valid == 1): ?>
                                                                <i class="fa fa-unlock text-success ml-2"></i>
                                                                <!-- Afficher le cadenas ouvert -->
                                                            <?php else: ?>
                                                                <i class="fa fa-lock text-danger ml-2"></i>
                                                                <!-- Afficher le cadenas fermé -->
                                                            <?php endif; ?>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr class="text-center">
                                                <td colspan="11">
                                                    <img src="<?php echo e(asset('img/page-not-found.png')); ?>" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            <?php echo $deviss->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirmation-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
    <style>
        .draggable-mirror {
            background-color: white;
            width: 950px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Dev\kgf\resources\views/livewire/admin/devis/devis-list.blade.php ENDPATH**/ ?>