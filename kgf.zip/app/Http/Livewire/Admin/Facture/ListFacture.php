<?php

namespace App\Http\Livewire\Admin\Facture;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Facture;
use Illuminate\Support\Facades\Gate;
use Livewire\Component;

class ListFacture extends AdminComponent
{
    protected $listeners = ['deleteConfirmed' => 'deleteFacture'];
    public $status = null;
    public $type = null;
    public $selectedRows = [];
    public $selectedPageRows = false;
    protected $queryString = ['status'];
    public $showEditModal = false;
    public $factureIdBeingRemoved = null;
    public $user;
    public $searchTerm = null;

    public function updatedSelectedPageRows($value)
    {
        if ($value) {
            $this->selectedRows = $this->facture->pluck('id')->map(function ($id) {
                return (string) $id;
            });
        } else {
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }


    public function markAsCreee()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'Créée']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme créées']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsEnvoyee()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'Envoyée']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme envoyées']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsEnAttentePaiement()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'En attente de paiement']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme en attente de paiement']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsPartiellementPayee()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'Partiellement payée']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme partiellement payées']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsPayee()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'Payée']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme payées']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsEnRetard()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'En retard']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme en retard']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsAnnulee()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'Annulée']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme annulées']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsReglee()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'Réglée']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme réglées']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsEnLitige()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'En litige']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme en litige']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsArchivee()
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            Facture::whereIn('id', $this->selectedRows)->update(['etat' => 'Archivée']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Toutes les factures sont marquées comme archivées']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function export()
    {
        dd('ok');
        //return (new ProjetExport($this->selectedRows))->download('Projet.xls');

    }
    public function confirmFactureRemoval($factureId)
    {
        $this->factureIdBeingRemoved = $factureId;

        $this->dispatchBrowserEvent('show-delete-confirmation');
    }

    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Facture-Supprimer-Groupe')) {
            Facture::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('deleted', ['message' => 'Ces Factures ont étés supprimées']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function deleteFacture()
    {
        if (Gate::allows('access', 'Facture-Supprimer')) {
            $facture = Facture::findOrFail($this->factureIdBeingRemoved);
            $facture->delete();
            $this->dispatchBrowserEvent('deleted', ['message' => "Facture supprimée avec succès !"]);
        }
    }

    public function filterFactureByStatus($status = null)
    {
        $this->resetPage();
        $this->reset('status');
        $this->status = $status;
    }
 

    public function getFactureProperty()
    {
        $query = Facture::with(['user', 'projet','devis'])
            ->where('titre', 'like', '%' . $this->searchTerm . '%');

        if ($this->status) {
            $query->where('etat', $this->status);
        }

        $query->orderBy('created_at', 'desc');

        return $query->paginate(10);
    }

    public function toggleFactureValidity(Facture $facture)
    {
        if (Gate::allows('access', 'Facture-Modifier')) {
            $facture->toggleValidity();
            $this->dispatchBrowserEvent('updated', ['message' => 'Facture modifié']);
        }
    }
    
    public function render()
    {
        $factures = $this->facture;
        $factureCount = Facture::count();
        $factureCreeeCount = Facture::where('etat', 'Créée')->count();
        $factureEnvoyeeCount = Facture::where('etat', 'Envoyée')->count();
        $factureEnAttentePaiementCount = Facture::where('etat', 'En attente de paiement')->count();
        $facturePartiellementPayeeCount = Facture::where('etat', 'Partiellement payée')->count();
        $facturePayeeCount = Facture::where('etat', 'Payée')->count();
        $factureEnRetardCount = Facture::where('etat', 'En retard')->count();
        $factureAnnuleeCount = Facture::where('etat', 'Annulée')->count();
        $factureRegleeCount = Facture::where('etat', 'Réglée')->count();
        $factureEnLitigeCount = Facture::where('etat', 'En litige')->count();
        $factureArchiveeCount = Facture::where('etat', 'Archivée')->count();
        
        return view('livewire.admin.facture.list-facture', compact(
            'factureCount',
            'factureCreeeCount',
            'factureEnvoyeeCount',
            'factureEnAttentePaiementCount',
            'facturePartiellementPayeeCount',
            'facturePayeeCount',
            'factureEnRetardCount',
            'factureAnnuleeCount',
            'factureRegleeCount',
            'factureEnLitigeCount',
            'factureArchiveeCount',
            'factures',
        ));
    }
}