<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\PDFController;
use App\Http\Livewire\Admin\Users\ListUsers;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Route::middleware(['auth'])->group(function () {
    
// Route::get('/print', [PDFController::class, 'generatePDF'])->name('printdevis');
Route::get('/print/devis/{numero}', [PDFController::class, 'generateDevisPDF'])->name('printdevis');
Route::get('/print/facture/{numero}', [PDFController::class, 'generateFacturePDF'])->name('printfacture');

});
Route::get('/print/recue/{numero}', [PDFController::class, 'generateRecuePDF'])->name('printrecue');
Route::get('/print/devis_client/{numero}', [PDFController::class, 'generateDevisClientPDF'])->name('printdevisclient');
Route::get('/print/facture_client/{numero}', [PDFController::class, 'generateFactureClientPDF'])->name('printfactureclient');