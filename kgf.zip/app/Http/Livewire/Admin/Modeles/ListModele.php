<?php

namespace App\Http\Livewire\Admin\Modeles;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Modele;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListModele extends AdminComponent
{
    public $state = [];

    public $showEditModal = false;
    public $modeleIdBeingRemoved = null;
    public $modele;
    public $searchTerm = null;



    public function addNew()
    {
        $this->showEditModal = false;
        $this->reset();
        $this->dispatchBrowserEvent('show-form');
    }


    public function createModele()
    {
        $validateData = Validator::make($this->state, [
            'name' => 'required',
        ], [
            'name.required' => "Le nom est obligatoire",
        ])->validate();

        if (Gate::allows('access', 'Modele-Ajouter')) {
            Modele::create($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Modèle ajouté avec succès !"]);

            $this->state = [];
        } else {
            $this->dispatchBrowserEvent('show-alert', [
                'title' => "Attention",
                'message' => "Vous n'avez pas le droit d'effecture cette action",
                'icon' => 'info',
                'iconColor' => '#ff6600'
            ]);
        }

    }
    public function edit(Modele $modele)
    {
        $this->reset();

        $this->showEditModal = true;

        $this->modele = $modele;

        $this->state = $modele->toArray();
        $this->dispatchBrowserEvent('show-form');
    }

    public function updateModele()
    {
        $validateData = Validator::make($this->state, [
            'name' => 'required',
        ], [
            'name.required' => "Le nom est obligatoire",
        ])->validate();


        if (Gate::allows('access', 'Modele-Modifier')) {

            $this->modele->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Modèle modifié avec succès !"]);

            $this->state = [];
        } else {
            $this->dispatchBrowserEvent('show-alert', [
                'title' => "Attention",
                'message' => "Vous n'avez pas le droit d'effecture cette action",
                'icon' => 'info',
                'iconColor' => '#ff6600'
            ]);
        }
    }

    public function confirmModeleRemoval($modeleId)
    {
        $this->modeleIdBeingRemoved = $modeleId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteModele()
    {
        if (Gate::allows('access', 'Modele-Supprimer')) {
            $modele = Modele::findOrFail($this->modeleIdBeingRemoved);
            $modele->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Modèle suprimé avec succès !"]);
        } else {
                    $this->dispatchBrowserEvent('show-alert', [
                        'title' => "Attention",
                        'message' => "Vous n'avez pas le droit d'effecture cette action",
                        'icon' => 'info',
                        'iconColor' => '#ff6600'
                    ]);
                }
    }
    public function render()
    {
        $modeles = Modele::query()
            ->where('name', 'like', '%' . $this->searchTerm . '%')
            ->latest()->paginate(12);


        return view('livewire.admin.modeles.list-modele', ['modeles' => $modeles]);
    }
}