<?php

namespace App\Http\Livewire\Admin\Facture;

use App\Models\Facture;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class FactureUpdate extends Component
{ 
    public $state = [];
    public $facture;
    public $searchTerm = null;
    public $selectedClient = null;
    public $conditions_general;
    public $garantie_rembourse;
 
    public function mount(Facture $facture)
    {
        $this->state = $facture->toArray();
        $this->facture = $facture;
        $this->conditions_general = $this->facture->conditions_general;
        $this->garantie_rembourse = $this->facture->garantie_rembourse;
    }

    public function updateFacture( $conditions_general,$garantie_rembourse)
    {
        $this->conditions_general = $conditions_general;
        $this->garantie_rembourse = $garantie_rembourse;

        $validatedData = Validator::make($this->state, [
            'titre' => 'required',
            'note' => 'nullable',
            'etat' => 'nullable',
            'date'=>'required',
            'modalite' => 'nullable',
            'echeance' => 'nullable',
            'coordonee_banc' => 'nullable',
            'delai_livraison' => 'nullable',
            'conditions_general' => 'nullable',
            'garantie_rembourse' => 'nullable',
            'contact' => 'nullable', 
            'validite'=>'required',  
        ],[
            'titre.required' => "Le champ Titre est obligatoire.",
            'date.required' => "Le champ date est obligatoire.",
            'validite.required' => "Le champ validité est obligatoire.",
            'marge_ben.required' => "Le champ Marge bénéficiaire est obligatoire.",
            'projet_forage_id.required' => "Le champ projet de forage est obligatoire.",
        ])->validate();
          
        $validatedData['date'] = date('Y-m-d', strtotime($validatedData['date']));
        $validatedData['user_id'] = auth()->user()->id; 

        $validatedData['conditions_general'] = $this->conditions_general ;
        $validatedData['garantie_rembourse'] = $this->garantie_rembourse;
         
        if (Gate::allows('access', 'Facture-ajouter')) {
            $this->facture->update($validatedData);
            $this->dispatchBrowserEvent('alert', ['message' => "Facture modifié avec succès !"]);
            return redirect()->route('admin.factures');
        }

    }
    public function render()
    {
        return view('livewire.admin.facture.facture-update');
    }
}
