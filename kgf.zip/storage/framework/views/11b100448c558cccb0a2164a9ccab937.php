<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(setting('site_title')); ?> | <?php echo e(setting('site_name')); ?></title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/dist/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('backend/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.css" rel="stylesheet">
    
    <link rel="shortcut icon" href="<?php echo e(asset('img/fi.jpg')); ?>" type="image/x-icon">    
    <?php echo \Livewire\Livewire::styles(); ?>


    <?php echo $__env->yieldPushContent('styles'); ?>
    
</head>

<body class="hold-transition sidebar-mini <?php echo e(setting('sidebar_collapse') ? 'sidebar-collapse' : ''); ?>">

    <div class="wrapper">

        <!-- Navbar -->
        <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php echo $__env->make('layouts.partials.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <?php echo e($slot); ?>

        </div>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.control-sidebar -->

        <!-- Main Footer -->
        <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('backend/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('backend/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('backend/dist/js/adminlte.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/plugins/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>

    <script>
        $(document).ready(function() {
            toastr.options = {
                "positionClass": "toast-bottom-right",
                "progressBar": true,
            }
            window.addEventListener('hide-form', event => {
                $('#form').modal('hide');
                toastr.success(event.detail.message, 'Super !');
            })
            window.addEventListener('hide-form2', event => {
                $('#form2').modal('hide');
                toastr.success(event.detail.message, 'Super !');
            })
            window.addEventListener('hide-form3', event => {
                $('#form3').modal('hide');
                toastr.danger(event.detail.message, 'Erreur !');
            })
            window.addEventListener('hide-delete-modal', event => {
                $('#confirmationModal').modal('hide');
                toastr.success(event.detail.message, 'Super !');
            })
            window.addEventListener('hide-delete-modal2', event => {
                $('#confirmationModal2').modal('hide');
                toastr.success(event.detail.message, 'Super !');
            })
            window.addEventListener('hide-delete-modal3', event => {
                $('#confirmationModal3').modal('hide');
                toastr.success(event.detail.message, 'Super !');
            })
            window.addEventListener('hide-delete-modal4', event => {
                $('#confirmationModal4').modal('hide');
                toastr.success(event.detail.message, 'Super !');
            })

        });
    </script>

    <script>
        window.addEventListener('show-form', event => {
            
            $('#form').modal('show');
        })
        window.addEventListener('show-form2', event => {
            $('#form2').modal('show');
        })

        window.addEventListener('show-delete-modal', event => {
            $('#confirmationModal').modal('show');
        })

        window.addEventListener('show-delete-modal2', event => {
            $('#confirmationModal2').modal('show');
        })
        window.addEventListener('show-delete-modal3', event => {
            $('#confirmationModal3').modal('show');
        })
        window.addEventListener('show-delete-modal4', event => {
            $('#confirmationModal4').modal('show');
        })
        window.addEventListener('alert', event => {
            toastr.success(event.detail.message, 'Super !');
        })
        window.addEventListener('updated', event => {
            toastr.success(event.detail.message, 'Modifié !');
        })
    </script>

    <?php echo $__env->yieldPushContent('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="https://cdn.jsdelivr.net/gh/livewire/sortable@v0.x.x/dist/livewire-sortable.js"></script>
</body>

</html>
<?php /**PATH D:\Dev\kgf1\kgf\resources\views/layouts/app.blade.php ENDPATH**/ ?>