<div>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Devis</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.devis') }}">Liste de devis</a></li>
                        <li class="breadcrumb-item active">Visualiser le Devis</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">{{ $devis->titre }}
                                <a href="{{ route('admin.devis.edit', $devis) }}"> <i
                                        class="fa fa-pen-alt ml-3"></i></a>
                            </h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <ul class="nav nav-pills flex-column">
                                <li class="nav-item active">
                                    <div class="nav-link">
                                        <i class="fas fa-tag mr-3"></i> {{ $devis->numero }}
                                        <span class="ml-5">{!! QrCode::size(50)->generate($devis->numero) !!}</span>
                                        </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-file-invoice-dollar mr-3"></i>Titre : {{ $devis->titre }}
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-project-diagram mr-3"></i>Projet :
                                        {{ $devis->projetForage->nom_projet }}
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fa fa-user mr-3"></i> Client :
                                        {{ $devis->projetForage->client->prenom }}
                                        {{ $devis->projetForage->client->nom }}
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fa fa-pen mr-3"></i> Note :
                                        {{ $devis->note }}
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-money-bill-alt mr-3"></i> Total HT: {{ $devis->total_ht }}
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-money-bill-alt mr-3"></i> Total TTC : {{ $devis->total_ttc }}
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="fa fa-calendar mr-3"></i> Etat :
                                        {!! $devis->getEtatIconAttribute() !!}
                                    </a>
                                </li>
                                <div wire:loading>
                                    <x-animations.ballbeatdark />
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="col-lg-9">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title mr-5">Articles du devis</h3>
                            
                            <div class="container">
                                <div class="d-flex justify-content-between mb-2">
                                    @if ($devis->is_valid == 1)
                                        <button class="btn btn-primary btn-sm" wire:click.prevent="addNew">
                                            <i class="fa fa-plus-circle mr-1"></i> Ajouter Article
                                        </button>
                                        <div class="btn-group ml-2">
                                            <button type="button" class="btn btn-default">Options</button>
                                            <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                                data-toggle="dropdown" aria-expanded="false">
                                                <span class="sr-only"></span>
                                            </button>
                                            <div class="dropdown-menu" role="menu" style="">
                                                <a class="dropdown-item"
                                                    href="{{ route('printdevis', ['numero' => $devis->numero]) }}"
                                                    target="_blank">Imprimer DEVIS</a>
                                                
                                                <a class="dropdown-item"
                                                    href="{{ route('printdevisclient', ['numero' => $devis->numero]) }}"
                                                    target="_blank">Imprimer Devis pour Client</a>
                                                
                                                <a class="dropdown-item" href="#"
                                                    wire:click.prevent='devisToFacture'>Progresser
                                                    vers une FACTURE
                                                </a>

                                            </div>
                                        </div>
                                    @endif
                                    
                                    <a href="{{ route('admin.devis.edit', $devis) }}"> <i
                                        class="fa fa-pen-alt ml-3"></i></a>
                                </div>
                            </div>

                            <div class="card-tools">

                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-1">
                            @if ($devis->is_valid == 1)
                                @foreach ($etapes as $etape)
                                    @if ($etape->devis_item->where('devis_forage_id', $devis->id)->count() > 0)
                                        <div class="alert alert-light m-1 d-flex justify-content-between align-items-center"
                                            role="alert">
                                            <strong>{{ Str::upper($etape->nom_etape) }}</strong>
                                        </div>
                                        <table class="table table-striped table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Numero</th>
                                                    <th scope="col">Titre</th>
                                                    <th scope="col">Unité</th>
                                                    <th scope="col">Qte</th>
                                                    <th scope="col">P.U</th>
                                                    <th scope="col">TVA</th>
                                                    <th scope="col">Rabais</th>
                                                    <th scope="col">Total HT</th>
                                                    <th scope="col">Total TTC</th>
                                                    <th colspan="2">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($etape->devis_item->where('devis_forage_id', $devis->id) as $item)
                                                    <tr>
                                                        <th scope="row">{{ $loop->iteration }}</th>
                                                        <td>{{ Str::ucfirst($item->numero) }}</td>
                                                        <td>{{ Str::ucfirst($item->titre) }}</td>
                                                        <td>{{ Str::upper($item->unite) }}</td>
                                                        <td>{{ Str::upper($item->qte) }}</td>
                                                        <td>{{ Str::upper($item->prix_u) }}</td>
                                                        <td>{{ Str::upper($item->prix_tva) }} $</td>
                                                        <td>{{ Str::upper($item->prix_rabais) }} $</td>
                                                        <td>{{ Str::upper($item->prix_ht) }} $
                                                        <td>{{ Str::upper($item->prix_t) }} $
                                                        </td>
                                                        <td>
                                                            <a href=""
                                                                wire:click.prevent="edit({{ $item }})">
                                                                <i class="fa fa-edit mr-2"></i>
                                                            </a>
                                                            <a href=""
                                                                wire:click.prevent="confirmItemRemoval({{ $item->id }})">
                                                                <i class="fa fa-trash text-danger"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                <tr>
                                                    <td colspan="10" class="text-right text-success">TVA
                                                        : <strong>{{ $etape->devis_item->sum('prix_tva') }} $</strong> </th>
                                                    <td> </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="10" class="text-right text-danger">Rabais
                                                        : <strong>{{ $etape->devis_item->sum('rabais') }} $</strong>
                                                        </th>
                                                    <td> </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="10" class="text-right text-dark">
                                                        <strong>Sous Total : {{ $etape->devis_item->sum('prix_t') }}
                                                            $</strong> </th>
                                                    <td> </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    @endif
                                @endforeach

                                <div class="container mt-2">
                                    <div class="d-flex justify-content-between mb-2"> 
                                        <button class="btn btn-success btn-sm" wire:click.prevent="updateDevisTotals" wire:loading.attr="disabled">
                                            <i class="fa fa-save mr-1"></i> Enregistrer
                                        </button>
                                        

                                        <strong>TVA : <span class="text-success">{{ $devis->devis_item->sum('prix_tva') }}</span> $</strong>
                                        <strong>Total HT : <span class="text-success">{{ $devis->devis_item->sum('prix_ht') }}</span> $</strong>
                                        <strong>Total TTC : <span class="text-success">{{ $devis->devis_item->sum('prix_t') }}</span> $</strong>
                                    </div>
                                </div>
                            @else
                                <h1>Vous n'avez pas le droit de Visualiser ce contenu</h1>
                            @endif



                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <x-alert />
    <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        @if ($showEditModal == true)
                            <span>Modifier l'Article</span>
                        @else
                            <span>Ajout d'un nouvel Article</span>
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="{{ $showEditModal ? 'updateItem' : 'createItem' }}" wire:loading.attr="disabled">
                        <!-- Le contenu de votre formulaire -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="etape_forage_id">Etape <span class="text-danger">*</span> :</label>
                                    <select class="form-control @error('etape_forage_id') is-invalid @enderror"
                                        id="etape_forage_id" wire:model.defer="stateItem.etape_forage_id">
                                        <option value="">Choisir une étape</option>
                                        @foreach ($etapes as $item)
                                            <option value="{{ $item->id }}">{{ Str::upper($item->nom_etape) }}
                                            </option>
                                        @endforeach

                                    </select>
                                    @error('etape_forage_id')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="titreitem">Titre <span class="text-danger">*</span> :</label>
                                    <select class="form-control @error('titreitem') is-invalid @enderror"
                                        id="titreitem" wire:model="stateItem.titreitem">
                                        <option value="">Choisir une étape</option>
                                        <option value="Equipements">Equipements</option>
                                        <option value="Main d'oeuvre">Main d'oeuvre</option>
                                        <option value="Approvisionnement en eau">Approvisionnement en eau</option>
                                        <option value="Autre">Autre</option>
                                    </select>
                                    @error('titreitem')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                @if ($stateItem['titreitem'] == 'Equipements')

                                    <div class="form-group">
                                        <label for="equipement_id">Équipement <span class="text-danger">*</span>
                                            :</label>
                                        <select class="form-control @error('equipement_id') is-invalid @enderror"
                                            id="equipement_id" wire:model.defer="stateItem.equipement_id"
                                            wire:change="updateSelectedEquipement">
                                            <option value="">Choisir un équipement</option>
                                            @foreach ($equipements as $equipement)
                                                <option value="{{ $equipement->id }}">
                                                    {{ $equipement->nom_equipement }}</option>
                                            @endforeach
                                        </select>
                                        @error('equipement_id')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                @elseif ($stateItem['titreitem'] == "Main d'oeuvre")
                                    <div class="form-group">
                                        <label for="moeuvre_id">Main d'oeuvre <span class="text-danger">*</span>
                                            :</label>
                                        <select class="form-control @error('moeuvre_id') is-invalid @enderror"
                                            id="moeuvre_id" wire:model.defer="stateItem.moeuvre_id"
                                            wire:change="updateSelectedMoeuvre">
                                            <option value="">Choisir une main d'oeuvre</option>
                                            @foreach ($moeuvres as $moeuvre)
                                                <option value="{{ $moeuvre->id }}">{{ $moeuvre->nom_personnel }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('moeuvre_id')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                @elseif ($stateItem['titreitem'] == 'Approvisionnement en eau')
                                    <div class="form-group">
                                        <label for="approvisionnement_id">Approvisionnement en eau <span
                                                class="text-danger">*</span> :</label>
                                        <select
                                            class="form-control @error('approvisionnement_id') is-invalid @enderror"
                                            id="approvisionnement_id"
                                            wire:model.defer="stateItem.approvisionnement_id"
                                            wire:change="updateSelectedApprov">
                                            <option value="">Choisir un approvisionnement en eau</option>
                                            @foreach ($approvisionnements as $approvisionnement)
                                                <option value="{{ $approvisionnement->id }}">
                                                    {{ $approvisionnement->nom_approvisionnement }}</option>
                                            @endforeach
                                        </select>
                                        @error('approvisionnement_id')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                @elseif ($stateItem['titreitem'] == 'Autre')
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="titre">Titre <span class="text-danger">*</span> :</label>
                                            <input type="text"
                                                class="form-control @error('titre') is-invalid @enderror"
                                                wire:model="stateItem.titre" id="titre" aria-describedby="titre"
                                                placeholder="Titre">
                                            @error('titre')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                @endif
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control @error('description') is-invalid @enderror" wire:model.defer="stateItem.description">
                                    </textarea>
                                    @error('description')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>TVA (%)</label>
                                    <input type="number" min="0"
                                        class="form-control @error('tva') is-invalid @enderror"
                                        wire:model="stateItem.tva">
                                    @error('tva')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Rabais (%)</label>
                                    <input type="number" class="form-control @error('rabais') is-invalid @enderror"
                                        min="0" wire:model="stateItem.rabais">
                                    @error('rabais')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Unité</label>
                                    <input type="text" class="form-control @error('unite') is-invalid @enderror"
                                        wire:model.defer="stateItem.unite">
                                    @error('unite')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Quantité</label>
                                    <input type="number" class="form-control @error('qte') is-invalid @enderror"
                                        min="0" wire:model="stateItem.qte">
                                    @error('qte')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Prix U.</label>
                                    <input type="number" class="form-control @error('prix_u') is-invalid @enderror"
                                        min="0" step="0.01" wire:model="stateItem.prix_u">
                                    @error('prix_u')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>


                        </div>
                        <h4 class="text-danger">TOTAL HT : {{ $stateItem['prix_ht'] }} USD</h4>
                        <h4 class="text-danger">TOTAL TTC : {{ $stateItem['prix_t'] }} USD</h4>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>
                    @if ($showEditModal)
                        <button type="submit" class="btn btn-info" wire:loading.attr="disabled">
                            <i class="fa fa-save mr-1"></i> Enregistrer les modifications
                        </button>
                    @else
                        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                            <i class="fa fa-save mr-1"></i> Enregistrer
                        </button>
                    @endif

                </div>
                </form>
            </div>
        </div>
    </div>



    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Supprimer l'Article</h5>
                </div>
                <div class="modal-body">
                    <h4>Etes-vous sûr de vouloir supprimer cet Article?</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>

                    <button type="button" wire:click.prevent='deleteItem' class="btn btn-danger"><i
                            class="fa fa-trash mr-1"></i>
                        Supprimer</button>

                </div>
            </div>
        </div>
    </div>

</div>
