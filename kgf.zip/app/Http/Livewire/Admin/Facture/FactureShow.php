<?php

namespace App\Http\Livewire\Admin\Facture;

use App\Models\EtapesForage;
use App\Models\Facture;
use App\Models\FactureItem;
use App\Models\PayementFacture;
use FactureMail;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

use Illuminate\Support\Facades\Mail;

class FactureShow extends Component
{
    public $showEditModal = false;
    public $state = [];
    public $facture;
    public $devisItem;
    public $stateTitre;
    public $item;
    public $itemIdBeingRemoved;
    public $stateItem = ['montant_paye' => 0, 'reste' => 0];

    public $payements;

    public function mount(Facture $facture)
    {
        $this->state = $facture->toArray();
        $this->facture = $facture;
        $this->payements = $this->facture->payement()->orderBy('created_at', 'desc')->get();
    }

    public function addNew()
    {
        $this->showEditModal = false;
        $this->reset('stateItem');
        $this->dispatchBrowserEvent('show-form');
        $this->payements = $this->facture->payement()->orderBy('created_at', 'desc')->get();
    }

    public function edit(FactureItem $item)
    {
        $this->reset('stateItem');
        $this->showEditModal = true;

        $this->item = $item;

        $this->stateItem = $item->toArray();
        $this->stateItem['titreitem'] = 'Autre';
        $this->dispatchBrowserEvent('show-form');
    }


    public function sendMail($numeroFacture)
    { 
        try {
            $mail = new \App\Mail\FactureMail($numeroFacture);
            Mail::to('josephmbula2@gmail.com')->send($mail);

            // Si le mail est envoyé avec succès
            $this->dispatchBrowserEvent('alert', ['message' => "E-mail envoyé avec succès !"]);
        } catch (\Exception $e) {
            // En cas d'erreur lors de l'envoi du mail
            $this->dispatchBrowserEvent('alert', ['message' => "Erreur lors de l'envoi de l'e-mail : " . $e->getMessage()]);
        }
    }


    public function createItem()
    {
        $validatedData = Validator::make($this->stateItem, [
            'montant_paye' => 'required|numeric|min:0',
            // Remplacez 0.01 par la valeur minimale souhaitée
            'reste' => 'required|numeric|min:0', // Remplacez 0.01 par la valeur minimale souhaitée
        ], [
            'montant_paye.required' => "Veuillez renseigner le montant payé",
            'montant_paye.min' => "Le montant payé doit être supérieur à zéro",
            'reste.required' => "Le reste est obligatoire",
            'reste.min' => "Le reste doit être supérieur à zéro",
        ])->validate();

        if (Gate::allows('access', 'FactureItem-Ajouter')) {

            $validatedData['numero'] = $this->generatePayNumber();
            $validatedData['facture_id'] = $this->facture->id;
            PayementFacture::create($validatedData);

            $this->payements = $this->facture->payement()->orderBy('created_at', 'desc')->get();
            $this->dispatchBrowserEvent('alert', ['message' => "Paiement Ajouté avec succès !"]);
            $this->reset('stateItem');
        }

        if (Gate::allows('access', 'FactureItem-Modifier')) {

            $data['montant_paye'] = $this->facture->payement->sum('montant_paye');
            $data['reste'] = $this->facture->payement()->latest('created_at')->value('reste');

            $this->facture->update($data);
            $this->dispatchBrowserEvent('hide-form', ['message' => "Facture Mis à jour !"]);
            $this->reset('stateItem');
        }

    }

    public function confirmItemRemoval($itemId)
    {
        $this->itemIdBeingRemoved = $itemId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }
    public function deleteItem()
    {
        if (Gate::allows('access', 'FactureItem-Supprimer')) {
            $item = PayementFacture::findOrFail($this->itemIdBeingRemoved);
            $item->delete();

            $validatedData = [];
            $count = $this->facture->payement->count(); // compter le nombre d'éléments
            if ($count == 0) { // s'il n'y a pas d'enregistrements
                $validatedData['montant_paye'] = 0; // affecter 0
                $validatedData['reste'] = 0; // affecter 0
            } else { // sinon
                $validatedData['montant_paye'] = $this->facture->payement->sum('montant_paye'); // exécuter le code existant
                $validatedData['reste'] = $this->facture->payement()->latest('created_at')->value('reste'); // exécuter le code existant
            }

            $this->facture->update($validatedData);

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Paement suprimé avec succès !"]);
        }
    }
    public function generatePayNumber()
    {
        $lastFacture = PayementFacture::orderBy('id', 'desc')->first();

        $nextNumber = $lastFacture ? intval(substr($lastFacture->numero, -4)) + 1 : 1;

        $formattedNumber = 'PAY-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        return $formattedNumber;
    }

    public function updateItem()
    {


    }
    public function render()
    {
        $this->payements = $this->facture->payement()->orderBy('created_at', 'desc')->get();

        if (isset($this->stateItem['montant_paye']) && !empty($this->stateItem['montant_paye'])) {
            if ($this->facture->montant_paye == 0) {
                $this->stateItem['reste'] = (float) $this->facture->total_ttc - (float) $this->stateItem['montant_paye'];
            } else {
                $this->stateItem['reste'] = (float) $this->facture->reste - (float) $this->stateItem['montant_paye'];
            }

        }

        $etapes = EtapesForage::orderBy('created_at', 'asc')->get();

        return view('livewire.admin.facture.facture-show', compact('etapes'));
    }
}