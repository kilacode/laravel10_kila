<?php

namespace App\Http\Livewire\Admin\Approvisionnement;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\ApprovisionnementEnEau;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class Approvisionnement extends AdminComponent
{
    public $state = ['cout_supplementaire'=>0];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $approvisionnementIdBeingRemoved = null;
    public $approvisionnement;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Approvisionnement-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    } 
    public function createApprovisionnement()
    { 

        $validateData = Validator::make($this->state, [ 
            'nom_approvisionnement' => 'required', 
            'cout_supplementaire' => 'required', 
        ], [
            'nom_approvisionnement.required' => "Le nom est obligatoire", 
            'cout_supplementaire.required' => "Le coût sup est obligatoire", 
        ])->validate(); 
        if (Gate::allows('access', 'Approvisionnement-Ajouter')) {
            ApprovisionnementEnEau::create($validateData);
            //$this->dispatchBrowserEvent('hide-form', ['message' => "approvisionnement géologique ajoutée avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(Approvisionnement $approvisionnement)
    {
        if (Gate::allows('access', 'Approvisionnement-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->approvisionnement = $approvisionnement;

            $this->state = $approvisionnement->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateApprovisionnement()
    {
        $validateData = Validator::make($this->state, [ 
            'nom_approvisionnement' => 'required', 
            'cout_supplementaire' => 'required', 
        ], [
            'nom_approvisionnement.required' => "Le nom est obligatoire", 
            'cout_supplementaire.required' => "Le coût sup est obligatoire", 
        ])->validate();

        if (Gate::allows('access', 'Approvisionnement-Modifier')) {

            $this->approvisionnement->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "approvisionnement modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Approvisionnement-Supprimer-Groupe')) {
            ApprovisionnementEnEau::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Approvisionnements ont étés supprimés']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmapprovisionnementRemoval($approvisionnementId)
    {
        $this->approvisionnementIdBeingRemoved = $approvisionnementId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteApprovisionnement()
    {
        if (Gate::allows('access', 'Approvisionnement-Supprimer')) {
            $approvisionnement = ApprovisionnementEnEau::findOrFail($this->approvisionnementIdBeingRemoved);
            $approvisionnement->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Approvisionnement suprimé avec succès !"]);
        }
    }
    public function render()
    {
        $searchTerm = '%' . $this->searchTerm . '%';

        $approvisionnements = ApprovisionnementEnEau::query()
        ->where('nom_approvisionnement','like', '%'.$this->searchTerm.'%') 
        ->latest()->paginate(12); 
        return view('livewire.admin.approvisionnement.approvisionnement', compact('approvisionnements'));
    }
}
