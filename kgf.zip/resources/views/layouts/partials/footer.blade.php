  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Kgf Admin
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2023 <a href="#">Joseph Mbula</a>.</strong> Tout droit réservé!
  </footer>