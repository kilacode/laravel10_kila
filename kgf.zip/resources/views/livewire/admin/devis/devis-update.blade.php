<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Modifier Devis</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.devis') }}">Devis</a></li>
                        <li class="breadcrumb-item active">Modifier Devis</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title mr-5">Modifier Devis</h3>
                            <a href="{{ route('admin.devis.create') }}">
                                <button class="btn btn-primary ">
                                    <i class="fa fa-plus-circle mr-1"></i> Ajouter un nouveau devis
                                </button>
                            </a>
                        </div>
                        <div class="card-body">
                            <form wire:submit.prevent='updateDevis($("#summernote").val(),$("#summernote2").val())' autocomplete="off">
                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="titre">Titre :</label>
                                            <input type="text"
                                                class="form-control @error('titre') is-invalid @enderror" id="titre"
                                                wire:model.defer="state.titre" placeholder="Nom du Devis">
                                            @error('titre')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="projet_forage_id">Projet :</label>
                                        <div class="form-group">
                                            <select wire:model="selectedProjet"
                                                class="form-control select2 @error('projet_forage_id') is-invalid @enderror"
                                                wire:model.lazy="state.projet_forage_id">
                                                <option value="">-- Sélectionner un projet --</option>
                                                @foreach ($projets as $projet)
                                                    <option value="{{ $projet->id }}">{{ $projet->nom_projet }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('projet_forage_id')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="">Etat :</label>
                                        <div class="form-group">
                                            <select class="form-control @error('etat') is-invalid @enderror"
                                                id="etat" wire:model.lazy="state.etat">
                                                <option value="">-- Sélectionner un état --</option>
                                                <option value="En attente">En attente</option>
                                                <option value="En cours">En cours</option>
                                                <option value="Terminé">Terminé</option>
                                                <option value="Validé">Validé</option>
                                                <option value="Annulé">Annulé</option>
                                            </select>
                                            @error('etat')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror

                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="note">Note :</label>
                                            <textarea class="form-control @error('note') is-invalid @enderror" id="note" wire:model.lazy='state.note'>
                                            </textarea>
                                            @error('note')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="appointmentDate">Date :</label>
                                            <div class="input-group mb-2">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="fa fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <x-datepicker wire:model.defer="state.date" id="appointmentDate"
                                                    :error="'date'" />
                                                @error('date')
                                                    <div class="invalid-feedback">
                                                        {{ $message }}
                                                    </div>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="validite">Validité (jours):</label>
                                            <input type="number" min="0"
                                                class="form-control @error('validite') is-invalid @enderror"
                                                id="validite" wire:model.lazy='state.validite'>
                                            @error('validite')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="marge_ben">Marge Bénéficiaire en (%):</label>
                                            <input type="number" step="0.1" min="0"
                                                class="form-control @error('marge_ben') is-invalid @enderror"
                                                id="marge_ben" wire:model.lazy='state.marge_ben'>
                                            @error('marge_ben')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="tva">TVA (%):</label>
                                            <input type="number" step="0.1" min="0"
                                                class="form-control @error('tva') is-invalid @enderror" id="tva"
                                                wire:model.lazy='state.tva'>
                                            @error('tva')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="modalite">Modalités de paiement :</label>
                                            <select id="modalite"
                                                class="form-control @error('modalite') is-invalid @enderror"
                                                wire:model.lazy='state.modalite'>
                                                <option value="Choisissez une modalité">Choisissez une modalité
                                                </option>
                                                <option value="Cash">Cash</option>
                                                <option value="Virement bancaire">Virement bancaire</option>
                                                <option value="Chèque">Chèque</option>
                                            </select>
                                            @error('modalite')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="echeance">Echéance de Paiement :</label>
                                            <input type="text"
                                                class="form-control @error('echeance') is-invalid @enderror"
                                                id="echeance" wire:model.lazy='state.echeance'>
                                            @error('echeance')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="coordonee_banc">Coordonnées Bancaires :</label>
                                            <input type="text"
                                                class="form-control @error('coordonee_banc') is-invalid @enderror"
                                                id="coordonee_banc" wire:model.lazy='state.coordonee_banc'>
                                            @error('coordonee_banc')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="delai_livraison">Delaie de livraison (Jours) :</label>
                                            <input type="number" min="0"
                                                class="form-control @error('delai_livraison') is-invalid @enderror"
                                                id="delai_livraison" wire:model='state.delai_livraison'>
                                            @error('delai_livraison')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row">

                                    <div wire:ignore class="form-group col-md-6">
                                        <label for="summernote">Condition générales de service :</label>
                                        <textarea id="summernote" rows="3" class="form-control">
                                            @if (isset($conditions_general))
{!! $conditions_general !!}
@endif
                                        </textarea>
                                    </div>

                                    <div wire:ignore class="form-group col-md-6">
                                        <label for="summernote2">Garantie de rembours.</label>
                                        <textarea id="summernote2" rows="3" class="form-control">
                                            @if (isset($garantie_rembourse))
{!! $garantie_rembourse !!}
@endif
                                        </textarea>
                                    </div>

                                    {{-- <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="conditions_general">Condition générales de service :</label>
                                            <textarea
                                                class="form-control @error('conditions_general') is-invalid @enderror" id="conditions_general"
                                                wire:model.lazy='state.conditions_general'>
                                            </textarea>
                                            @error('conditions_general')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="garantie_rembourse">Garantie de rembours.</label> 
                                            <textarea
                                                class="form-control @error('garantie_rembourse') is-invalid @enderror" id="garantie_rembourse"
                                                wire:model.lazy='state.garantie_rembourse'>
                                            </textarea>
                                            @error('garantie_rembourse')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>   --}}
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="contact">Contact :</label>
                                            <input type="text"
                                                class="form-control @error('contact') is-invalid @enderror"
                                                id="contact" wire:model='state.contact'>
                                            @error('contact')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-secondary"> <i class="fa fa-times mr-1"></i>
                                    Annuler</button>

                                <button id="submit" type="submit" class="btn btn-primary"><i
                                        class="fa fa-trash mr-1"></i> Enregistrer</button>
                            </form>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
    {{-- @push('js')
        <script src="https://cdn.ckeditor.com/ckeditor5/36.0.0/classic/ckeditor.js"></script>

        <script>
            ClassicEditor.create(document.querySelector('#description'));
            $('form').submit(function() {
                //@this.set('state.members', $('#members').val());
                @this.set('state.description', $('#description').val());
                //@this.set('state.color', $('[name=color]').val());
            })
        </script>
    @endpush --}}

    @push('js')
        <script src="{{ asset('backend') }}/summernote/summernote-bs4.min.js"></script>
        <script>
            $('#summernote').summernote({
                height: 200,
                codemirror: {
                    theme: 'monokai'
                },
                callbacks: {
                    onImageUpload: function(files) {
                        for (let i = 0; i < files.length; i++) {
                            const file = files[i];
                            if (file.type.includes('image') && file.size <= 100000) {
                                const reader = new FileReader();
                                reader.onload = function(e) {
                                    const base64 = e.target.result;
                                    const imgTag = '<img src="' + base64 + '">';
                                    $('#summernote').summernote('pasteHTML', imgTag);
                                }
                                reader.readAsDataURL(file);
                            } else {
                                alert("La taille de l'image ne doit pas dépasser 100ko.");
                            }
                        }
                    }
                }
            });
        </script>

        <script>
            $('#summernote2').summernote({
                height: 200,
                codemirror: {
                    theme: 'monokai'
                },
                callbacks: {
                    onImageUpload: function(files) {
                        for (let i = 0; i < files.length; i++) {
                            const file = files[i];
                            if (file.type.includes('image') && file.size <= 100000) {
                                const reader = new FileReader();
                                reader.onload = function(e) {
                                    const base64 = e.target.result;
                                    const imgTag = '<img src="' + base64 + '">';
                                    $('#summernote2').summernote('pasteHTML', imgTag);
                                }
                                reader.readAsDataURL(file);
                            } else {
                                alert("La taille de l'image ne doit pas dépasser 100ko.");
                            }
                        }
                    }
                }
            });
        </script>

        <script>
            $('#summernote3').summernote({
                height: 200,
                codemirror: {
                    theme: 'monokai'
                },
                callbacks: {
                    onImageUpload: function(files) {
                        for (let i = 0; i < files.length; i++) {
                            const file = files[i];
                            if (file.type.includes('image') && file.size <= 100000) {
                                const reader = new FileReader();
                                reader.onload = function(e) {
                                    const base64 = e.target.result;
                                    const imgTag = '<img src="' + base64 + '">';
                                    $('#summernote3').summernote('pasteHTML', imgTag);
                                }
                                reader.readAsDataURL(file);
                            } else {
                                alert("La taille de l'image ne doit pas dépasser 100ko.");
                            }
                        }
                    }
                }
            });
        </script>
    @endpush

</div>
