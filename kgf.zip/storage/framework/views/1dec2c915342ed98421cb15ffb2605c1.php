<?php $__env->startPush('js'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    window.addEventListener('show-alert', event => {
        Swal.fire({
            title: event.detail.title,
            text: event.detail.message,
            icon: event.detail.icon,
            confirmButtonText: 'Fermer',
            iconColor: event.detail.iconColor // Nouveau paramètre pour la couleur de l'icône
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Dev\kgf\resources\views/components/alert.blade.php ENDPATH**/ ?>