<div> 
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Acces</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Acces</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12"> 
                    <div class="d-flex justify-content-between mb-2">
                        
                            <button class="btn btn-primary " wire:click.prevent="addNew">
                                <i class="fa fa-plus-circle mr-1"></i> Ajouter Acces
                            </button>

                            @if ($selectedRows)
                            <div class="btn-group ml-2">
                                <button type="button" class="btn btn-default">Options</button>
                                <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                    data-toggle="dropdown" aria-expanded="false">
                                    <span class="sr-only"></span>
                                </button>
                                <div class="dropdown-menu" role="menu" style="">
                                    <a wire:click.prevent="deleteSelectedRows" class="dropdown-item" href="#">Supprimer rendez-vous sélectionnés</a>  
                                </div>
                            </div>
                            <span class="ml-2">{{ count($selectedRows) }} {{ Str::plural(' Accès sélectionné',count($selectedRows)) }}</span>
                            @endif 
                            
                            <x-search-input wire:model='searchTerm' /> 
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <td colspan="2">#</td> 
                                            {{-- <th>
                                                <div class="custom-control custom-checkbox">
                                                    <input wire:model="selectedPageRows" class="custom-control-input" type="checkbox"
                                                        id="customCheckbox1" value="" >
                                                    <label for="customCheckbox1" class="custom-control-label"></label>
                                                </div>
                                            </th> --}}
                                            <th>Nom</th>
                                            <th>Agent</th> 
                                            <th colspan="2">Options</th>
                                        </tr>
                                    </thead>
                                    <tbody wire:loading.class='text-muted'>
                                        @forelse ($access as $acces)
                                            <tr>
                                                <th scope="row">{{ $loop->iteration }}</td>
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input" type="checkbox"
                                                            id="{{ $acces->id }}" value="{{ $acces->id }}">
                                                        <label for="{{ $acces->id }}"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th> 
                                                <td>{{ $acces->name }}</td>
                                                <td>{{ Str::upper($acces->user->name )}}</td> 
                                                <td>
                                                    @can('access', 'Acces-Modifier')
                                                        <a href="" wire:click.prevent="edit({{ $acces }})">
                                                            <i class="fa fa-edit mr-2"></i>
                                                        </a>
                                                    @endcan
                                                </td>
                                                <td>
                                                    @can('access', 'Acces-Supprimer')
                                                        <a href="" wire:click.prevent="confirmAccesRemoval({{ $acces->id }})">
                                                            <i class="fa fa-trash text-danger"></i>
                                                        </a>
                                                    @endcan
                                                </td>
                                         
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="5">
                                                    <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        @endforelse

                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            {{ $access->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        @if ($showEditModal == true)
                            <span>Modifier l' Acces</span>
                        @else
                            <span>Ajout d'un nouvel Acces</span>
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="{{ $showEditModal ? 'updateAcces' : 'createAcces' }}">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="user_id">Utilisateur</label>
                                    <select class="form-control @error('user_id') is-invalid @enderror"
                                    wire:model.defer="state.user_id" id="user_id">
                                        <option value="">Choisissez un utilisateur</option>
                                        @foreach ($users as $user)
                                            <option value="{{ $user->id }}">{{ Str::upper($user->name) }}</option>
                                        @endforeach
                                    </select>
                                    
                                    @error('user_id')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
        
                                </div>    
                            </div>
                            @if(!$showEditModal)
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div wire:ignore.self class="d-flex flex-wrap">
                                        @foreach ($modeles as $item) 
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" id="{{ $item->name.'-Ajouter' }}" type="checkbox" wire:model="selectedIds" value="{{ $item->name.'-Ajouter' }}">
                                                <label class="form-check-label bold text-danger" for="{{ $item->name.'-Ajouter' }}">{{ Str::ucfirst($item->name.'-Ajouter') }}</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" id="{{ $item->name.'-Modifier' }}" type="checkbox" wire:model="selectedIds" value="{{ $item->name.'-Modifier' }}">
                                                <label class="form-check-label" for="{{ $item->name.'-Modifier' }}">{{ Str::ucfirst($item->name.'-Modifier') }}</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" id="{{ $item->name.'-Supprimer' }}" type="checkbox" wire:model="selectedIds" value="{{ $item->name.'-Supprimer' }}">
                                                <label class="form-check-label" for="{{ $item->name.'-Supprimer' }}">{{ Str::ucfirst($item->name.'-Supprimer') }}</label>
                                            </div> 
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" id="{{ $item->name.'-Supprimer-Groupe' }}" type="checkbox" wire:model="selectedIds" value="{{ $item->name.'-Supprimer-Groupe' }}">
                                                <label class="form-check-label" for="{{ $item->name.'-Supprimer-Groupe' }}">{{ Str::ucfirst($item->name.'-Supprimer-Groupe') }}</label>
                                            </div> 
                                        @endforeach
                                    </div>
                                </div>
                            </div> 
                            @endif
                           
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>
                    @if ($showEditModal)
                        <button type="submit" class="btn btn-info"><i class="fa fa-save mr-1"></i> Enregistrer les
                            modifications</button>
                    @else
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-1"></i>
                            Enregistrer</button>
                    @endif
                </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Supprimer l'Acces</h5>
                </div>
                <div class="modal-body">
                    <h4>Etes-vous sûr de vouloir supprimer cet Acces?</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>

                    <button type="button" wire:click.prevent='deleteAcces' class="btn btn-danger"><i
                            class="fa fa-trash mr-1"></i>
                        Supprimer</button>

                </div>
            </div>
        </div>
    </div>
</div>
