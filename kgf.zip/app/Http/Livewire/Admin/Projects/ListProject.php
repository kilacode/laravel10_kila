<?php

namespace App\Http\Livewire\Admin\Projects;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\ProjetForage;
use Illuminate\Support\Facades\Gate;

class ListProject extends AdminComponent
{
    protected $listeners = ['deleteConfirmed' => 'deleteProjet'];
    public $status = null;
    public $type = null;
    public $selectedRows = [];
    public $selectedPageRows = false;
    protected $queryString = ['status'];
    public $showEditModal = false;
    public $projetIdBeingRemoved = null;
    public $user;
    public $searchTerm = null;

    public function updatedSelectedPageRows($value)
    {
        if ($value) {
            $this->selectedRows = $this->projetForage->pluck('id')->map(function ($id) {
                return (string) $id;
            });
        } else {
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }


    public function markAsEnAttente()
    {
        if (Gate::allows('access', 'Projet-Forage-Modifier')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'En attente']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projets sont marqués comme en attente']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsEnCoursDeForage()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'En cours de forage']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme En cours de forage']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }

    }

    public function markAsTermine()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'Terminé']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme Terminés']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function markAsEnAttenteDeConditionsGeologiques()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'En attente de conditions géologiques']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme En attente de conditions géologiques']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsEnAttenteDApprobations()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'En attente d\'approbations']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme En attente d\'approbations']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsAbandonne()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'Abandonné']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme Abandonné']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function markAsEnAttenteDeFinancement()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'En attente de financement']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme En attente de financement']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function markAsEnCoursDeConstructionDInfrastructure()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'En cours de construction d\'infrastructure']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme En cours de construction d\'infrastructure']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function markAsEnCoursDeTest()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'En cours de test']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme En cours de test']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function markAsOperationnel()
    {
        if (Gate::allows('access', 'Projet-Forage-Ajouter')) {
            ProjetForage::whereIn('id', $this->selectedRows)->update(['etat_projet' => 'Opérationnel']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les projet sont marqués comme Opérationnel']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function export()
    {
        dd('ok');
        //return (new ProjetExport($this->selectedRows))->download('Projet.xls');

    }
    public function confirmProjetRemoval($projetId)
    {
        $this->projetIdBeingRemoved = $projetId;

        $this->dispatchBrowserEvent('show-delete-confirmation');
    }

    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Projet-Forage-Supprimer-Groupe')) { 
        ProjetForage::whereIn('id', $this->selectedRows)->delete();

        $this->dispatchBrowserEvent('deleted', ['message' => 'Ces projets ont étés supprimés']);

        $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function deleteProjet()
    {
        if (Gate::allows('access','Projet-Forage-Supprimer')) { 
        $projet = ProjetForage::findOrFail($this->projetIdBeingRemoved);
        $projet->delete();
        $this->dispatchBrowserEvent('deleted', ['message' => "Projet supprimé avec succès !"]);
        }
    }

    public function filterProjetByStatus($status = null)
    {
        $this->resetPage();
        $this->reset('status');
        $this->status = $status;
    }

    public function getProjetForageProperty()
    {
        $query = ProjetForage::with(['user', 'client', 'typeForage', 'conditionGeologique'])
            ->where('nom_projet', 'like', '%' . $this->searchTerm . '%');

        if ($this->status) {
            $query->where('etat_projet', $this->status);
        }

        $query->orderBy('created_at', 'desc');

        return $query->paginate(10);
    }

    public function render()
    {
        $projets = $this->projetForage;
        $projetCount = ProjetForage::count();

        $projetEnAttenteCount = ProjetForage::where('etat_projet', 'En attente')->count();
        $projetEnCoursDeForageCount = ProjetForage::where('etat_projet', 'En cours de forage')->count();
        $projetTermineCount = ProjetForage::where('etat_projet', 'Terminé')->count();
        $projetEnAttenteConditionsCount = ProjetForage::where('etat_projet', "En attente de conditions géologiques")->count();
        $projetEnAttenteApprobationsCount = ProjetForage::where('etat_projet', "En attente d'approbations")->count();
        $projetAbandonneCount = ProjetForage::where('etat_projet', 'Abandonné')->count();
        $projetEnAttenteFinancementCount = ProjetForage::where('etat_projet', 'En attente de financement')->count();
        $projetEnCoursConstructionCount = ProjetForage::where('etat_projet', 'En cours de construction d\'infrastructure')->count();
        $projetEnCoursTestCount = ProjetForage::where('etat_projet', 'En cours de test')->count();
        $projetOperationnelCount = ProjetForage::where('etat_projet', 'Opérationnel')->count();


        return view('livewire.admin.projects.list-project', compact(
            'projets',
            'projetCount',
            'projetEnAttenteCount',
            'projetEnCoursDeForageCount',
            'projetTermineCount',
            'projetEnAttenteConditionsCount',
            'projetEnAttenteApprobationsCount',
            'projetAbandonneCount',
            'projetEnAttenteFinancementCount',
            'projetEnCoursConstructionCount',
            'projetEnCoursTestCount',
            'projetOperationnelCount',
        )
        );
    }
}