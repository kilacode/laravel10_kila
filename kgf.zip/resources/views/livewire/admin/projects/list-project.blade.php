<div>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Projets</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Projets</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            <a href="{{ route('admin.add.project') }}">
                                <button class="btn btn-primary ">
                                    <i class="fa fa-plus-circle mr-1"></i> Ajouter 
                                </button>
                            </a>
                            @if ($selectedRows)
                                <div class="btn-group ml-2">
                                    <button type="button" class="btn btn-default">Action</button>
                                    <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                        data-toggle="dropdown" aria-expanded="false">
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <div class="dropdown-menu" role="menu" style="">
                                        <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                            href="#">Supprimer Projets sélectionnés</a>
                                        <a wire:click.prevent="markAsEnAttente" class="dropdown-item"
                                            href="#">Marquer comme En attente</a>
                                        <a wire:click.prevent="markAsEnCoursDeForage" class="dropdown-item"
                                            href="#">Marquer comme En cours de forage</a>
                                        <a wire:click.prevent="markAsTermine" class="dropdown-item"
                                            href="#">Marquer comme Terminé</a>
                                        <a wire:click.prevent="markAsEnAttenteConditionsGeologiques"
                                            class="dropdown-item" href="#">Marquer comme En attente de conditions
                                            géologiques</a>
                                        <a wire:click.prevent="markAsEnAttenteApprobations" class="dropdown-item"
                                            href="#">Marquer comme En attente d'approbations</a>
                                        <a wire:click.prevent="markAsAbandonne" class="dropdown-item"
                                            href="#">Marquer comme Abandonné</a>
                                        <a wire:click.prevent="markAsEnAttenteFinancement" class="dropdown-item"
                                            href="#">Marquer comme En attente de financement</a>
                                        <a wire:click.prevent="markAsEnCoursDeConstructionInfrastructure"
                                            class="dropdown-item" href="#">Marquer comme En cours de construction
                                            d'infrastructure</a>
                                        <a wire:click.prevent="markAsEnCoursDeTest" class="dropdown-item"
                                            href="#">Marquer comme En cours de test</a>
                                        <a wire:click.prevent="markAsOperationnel" class="dropdown-item"
                                            href="#">Marquer comme Opérationnel</a>
                                        <a wire:click.prevent="export" class="dropdown-item" href="#">Exporter</a>
                                    </div>
                                </div>

                                <span class="ml-2">{{ count($selectedRows) }}
                                    {{ Str::plural(' Projets', count($selectedRows)) }} <i
                                        class="fa fa-check"></i></span>
                            @endif
                        </div>

                        <div class="btn-group">
                            <button wire:click="filterProjetByStatus" type="button"
                                class="btn {{ is_null($status) ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Tout</span>
                                <span class="badge badge-pull badge-info">{{ $projetCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente')" type="button"
                                class="btn {{ $status == 'En attente' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En attente</span>
                                <span class="badge badge-pull badge-warning">{{ $projetEnAttenteCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En cours de forage')" type="button"
                                class="btn {{ $status == 'En cours de forage' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En cours de forage</span>
                                <span class="badge badge-pull badge-info">{{ $projetEnCoursDeForageCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('Terminé')" type="button"
                                class="btn {{ $status == 'Terminé' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Terminé</span>
                                <span class="badge badge-pull badge-success">{{ $projetTermineCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente de conditions géologiques')" type="button"
                                class="btn {{ $status == 'En attente de conditions géologiques' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En attente de CG</span>
                                <span class="badge badge-pull badge-dark">{{ $projetEnAttenteConditionsCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente d\'approbations')" type="button"
                                class="btn {{ $status == 'En attente d\'approbations' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En attente d'approb.</span>
                                <span class="badge badge-pull badge-warning">{{ $projetEnAttenteApprobationsCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('Abandonné')" type="button"
                                class="btn {{ $status == 'Abandonné' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Abandonné</span>
                                <span class="badge badge-pull badge-danger">{{ $projetAbandonneCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente de financement')" type="button"
                                class="btn {{ $status == 'En attente de financement' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En attente de financement</span>
                                <span class="badge badge-pull badge-info">{{ $projetEnAttenteFinancementCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En cours de construction d\'infrastructure')" type="button"
                                class="btn {{ $status == 'En cours de construction d\'infrastructure' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En construction</span>
                                <span class="badge badge-pull badge-primary">{{ $projetEnCoursConstructionCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En cours de test')" type="button"
                                class="btn {{ $status == 'En cours de test' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En cours de test</span>
                                <span class="badge badge-pull badge-info">{{ $projetEnCoursTestCount }}</span>
                            </button> 
                            <button wire:click="filterProjetByStatus('Opérationnel')" type="button"
                                class="btn {{ $status == 'Opérationnel' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Opérationnel</span>
                                <span class="badge badge-pull badge-success">{{ $projetOperationnelCount }}</span>
                            </button> 
                        </div>
                        

                        <x-search-input wire:model='searchTerm' />
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="custom-control custom-checkbox">
                                                    <input wire:model="selectedPageRows" class="custom-control-input"
                                                        type="checkbox" id="customCheckbox1" value="">
                                                    <label for="customCheckbox1" class="custom-control-label"></label>
                                                </div>
                                            </th>
                                            <th>#</th>
                                            <th>Nom du Projet</th>
                                            <th>Lieu</th>
                                            <th>Profondeur Souhaitée</th>
                                            <th>Diamètre Souhaité</th>
                                            <th>État du Projet</th>
                                            <th>Type de Forage</th>
                                            <th>Conditions Géologiques</th>
                                            <th>Coût Total</th>
                                            <th>Client</th>
                                            <th>Utilisateur</th>
                                            <th>Options</th>  
                                        </tr>
                                    </thead>
                                    <tbody wire:loading.class='text-muted' >
                                        @forelse ($projets as $projet)
                                            <tr>  
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="{{ $projet->id }}"
                                                            value="{{ $projet->id }}">
                                                        <label for="{{ $projet->id }}"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>

                                                <th scope="row">{{ $loop->iteration }}</td>  
                                                <td>{{ $projet->nom_projet }}</td>
                                                <td> {{ $projet->lieu}} </td>
                                                <td>{{ $projet->profondeur_souhaitee }} m</td>
                                                <td>{{ $projet->diametre_souhaite }} m</td> 
                                                <td> {!! $projet->getEtatIconAttribute() !!} </td>
                                                <td>{{ $projet->typeForage->nom_type }}</td>
                                                <td>{{ $projet->conditionGeologique->nom_condition }}</td>
                                                <td>{{ number_format($projet->cout_total, 2, ',', ' ') }} $</td>
                                                <td>{{ Str::upper($projet->client->nom) }}</td>
                                                <td>{{ Str::upper($projet->user->name) }}</td>
                                                <td>
                                                    <a href="{{ route('admin.project.edit', $projet) }}"><i class="fa fa-edit mr-2"></i></a>
                                                    <a href="" wire:click.prevent="confirmProjetRemoval({{ $projet->id }})"><i class="fa fa-trash text-danger"></i></a>
                                                </td> 
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="13">
                                                    <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        @endforelse

                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            {!! $projets->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <x-confirmation-alert />
</div>

@push('styles')
    <style>
        .draggable-mirror {
            background-color: white;
            width: 950px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
@endpush
