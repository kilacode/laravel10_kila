<div>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Factures</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Factures</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            
                            <?php if($selectedRows): ?>
                                <div class="btn-group ml-2">
                                    <button type="button" class="btn btn-default">Action</button>
                                    <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                        data-toggle="dropdown" aria-expanded="false">
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>

                                    <div class="dropdown-menu" role="menu" style="">
                                        <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                            href="#">Supprimer factures sélectionnés</a>
                                            <a wire:click.prevent="markAsCreee" class="dropdown-item" href="#">Marquer comme Créée</a>
                                            <a wire:click.prevent="markAsEnvoyee" class="dropdown-item" href="#">Marquer comme Envoyée</a>
                                            <a wire:click.prevent="markAsEnAttentePaiement" class="dropdown-item" href="#">Marquer comme En attente de paiement</a>
                                            <a wire:click.prevent="markAsPartiellementPayee" class="dropdown-item" href="#">Marquer comme Partiellement payée</a>
                                            <a wire:click.prevent="markAsPayee" class="dropdown-item" href="#">Marquer comme Payée</a>
                                            <a wire:click.prevent="markAsEnRetard" class="dropdown-item" href="#">Marquer comme En retard</a>
                                            <a wire:click.prevent="markAsAnnulee" class="dropdown-item" href="#">Marquer comme Annulée</a>
                                            <a wire:click.prevent="markAsReglee" class="dropdown-item" href="#">Marquer comme Réglée</a>
                                            <a wire:click.prevent="markAsEnLitige" class="dropdown-item" href="#">Marquer comme En litige</a>
                                            <a wire:click.prevent="markAsArchivee" class="dropdown-item" href="#">Marquer comme Archivée</a>  
                                        <a wire:click.prevent="export" class="dropdown-item" href="#">Exporter</a>
                                    </div>
                                </div>

                                <span class="ml-2"><?php echo e(count($selectedRows)); ?>

                                    <?php echo e(Str::plural(' Facture', count($selectedRows))); ?> <i
                                        class="fa fa-check"></i></span>
                            <?php endif; ?>
                        </div>

                        <div class="btn-group">
                            <button wire:click="filterfacturesByStatus" type="button"
                                class="btn <?php echo e(is_null($status) ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Tout</span>
                                <span class="badge badge-pull badge-info"><?php echo e($factureCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Créée')" type="button"
                                class="btn <?php echo e($status == 'Créée' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Créée</span>
                                <span class="badge badge-pull badge-primary"><?php echo e($factureCreeeCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Envoyée')" type="button"
                                class="btn <?php echo e($status == 'Envoyée' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Envoyée</span>
                                <span class="badge badge-pull badge-primary"><?php echo e($factureEnvoyeeCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('En attente de paiement')" type="button"
                                class="btn <?php echo e($status == 'En attente de paiement' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En attente de paiement</span>
                                <span
                                    class="badge badge-pull badge-warning"><?php echo e($factureEnAttentePaiementCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Partiellement payée')" type="button"
                                class="btn <?php echo e($status == 'Partiellement payée' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Partiellement payée</span>
                                <span
                                    class="badge badge-pull badge-success"><?php echo e($facturePartiellementPayeeCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Payée')" type="button"
                                class="btn <?php echo e($status == 'Payée' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Payée</span>
                                <span class="badge badge-pull badge-success"><?php echo e($facturePayeeCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('En retard')" type="button"
                                class="btn <?php echo e($status == 'En retard' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En retard</span>
                                <span class="badge badge-pull badge-danger"><?php echo e($factureEnRetardCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Annulée')" type="button"
                                class="btn <?php echo e($status == 'Annulée' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Annulée</span>
                                <span class="badge badge-pull badge-secondary"><?php echo e($factureAnnuleeCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Réglée')" type="button"
                                class="btn <?php echo e($status == 'Réglée' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Réglée</span>
                                <span class="badge badge-pull badge-info"><?php echo e($factureRegleeCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('En litige')" type="button"
                                class="btn <?php echo e($status == 'En litige' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En litige</span>
                                <span class="badge badge-pull badge-danger"><?php echo e($factureEnLitigeCount); ?></span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Archivée')" type="button"
                                class="btn <?php echo e($status == 'Archivée' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Archivée</span>
                                <span class="badge badge-pull badge-secondary"><?php echo e($factureArchiveeCount); ?></span>
                            </button>


                        </div>


                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-input','data' => ['wire:model' => 'searchTerm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'searchTerm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="custom-control custom-checkbox">
                                                    <input wire:model="selectedPageRows" class="custom-control-input"
                                                        type="checkbox" id="customCheckbox1" value="">
                                                    <label for="customCheckbox1" class="custom-control-label"></label>
                                                </div>
                                            </th>
                                            <th>#</th>
                                            <th>Titre</th>
                                            <th>Numéro</th>
                                            <th>Projet</th>
                                            <th>Devis</th>
                                            <th>État du factures</th>
                                            <th>Diamètre Souhaité</th>
                                            <th>Profondeur Souhaité</th>
                                            <th>TVA</th>
                                            <th>Coût Total</th>
                                            <th>Client</th>
                                            <th>Utilisateur</th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody wire:loading.class='text-muted'>
                                        <?php $__empty_1 = true; $__currentLoopData = $factures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="<?php echo e($facture->id); ?>"
                                                            value="<?php echo e($facture->id); ?>">
                                                        <label for="<?php echo e($facture->id); ?>"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>

                                                <th scope="row"><?php echo e($loop->iteration); ?></td>
                                                <td><a href="<?php echo e(route('admin.facture.show', $facture)); ?>"><i
                                                            class="fa fa-eye mr-2"></i><?php echo e(Str::upper($facture->titre)); ?></a>
                                                </td>
                                                <td><?php echo e($facture->numero); ?> </td>
                                                <td><a href="<?php echo e(route('admin.project.show', $facture->projet->id)); ?>"> <?php echo e($facture->projet->nom_projet); ?></a></td>
                                                <td><a href="<?php echo e(route('admin.devis.show',$facture->devis->id)); ?>"><?php echo e($facture->devis->numero); ?></a> </td>
                                                <td> <?php echo $facture->getEtatIconAttribute(); ?> </td>
                                                <td><?php echo e($facture->projet->diametre_souhaite); ?> m</td>
                                                <td><?php echo e($facture->projet->profondeur_souhaitee); ?> m</td>
                                                <td><?php echo e(number_format($facture->prix_tva, 2, ',', ' ')); ?> $</td>
                                                <td><?php echo e(number_format($facture->total_ttc, 2, ',', ' ')); ?> $</td>
                                                <td><?php echo e(Str::upper($facture->projet->client->nom)); ?></td>
                                                <td><?php echo e(Str::upper($facture->user->name)); ?></td>
                                                <td> 

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Facture-Supprimer')): ?>
                                                        <a href=""
                                                            wire:click.prevent="confirmFactureRemoval(<?php echo e($facture->id); ?>)"><i
                                                                class="fa fa-trash text-danger"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', 'Facture-Modifier')): ?>
                                                        <a href=""
                                                            wire:click.prevent="toggleFactureValidity(<?php echo e($facture); ?>)">
                                                            <?php if($facture->is_valid == 1): ?>
                                                                <i class="fa fa-unlock text-success ml-2"></i>
                                                                <!-- Afficher le cadenas ouvert -->
                                                            <?php else: ?>
                                                                <i class="fa fa-lock text-danger ml-2"></i>
                                                                <!-- Afficher le cadenas fermé -->
                                                            <?php endif; ?>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr class="text-center">
                                                <td colspan="14">
                                                    <img src="<?php echo e(asset('img/page-not-found.png')); ?>" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            <?php echo $factures->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirmation-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
    <style>
        .draggable-mirror {
            background-color: white;
            width: 950px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Dev\kgf1\kgf\resources\views/livewire/admin/facture/list-facture.blade.php ENDPATH**/ ?>