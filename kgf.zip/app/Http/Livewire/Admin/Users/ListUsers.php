<?php

namespace App\Http\Livewire\Admin\Users;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\WithFileUploads;

class ListUsers extends AdminComponent
{
    use WithFileUploads;
    public $state = []; 

    public $showEditModal = false;
    public $userIdBeingRemoved = null;
    public $user;
    public $searchTerm = null;

    public $photo;

    public $tmp_avatar;

    public function changeRole(User $user,$role)
    {
        Validator::make(['role' => $role], [
            'role'=> [
                'required',
                Rule::in(User::ROLE_ADMIN, User::ROLE_USER),
            ], 
        ])->validate();

        $user->update(['role' => $role]);
        $this->dispatchBrowserEvent('updated', ['message' => "Role modifié en {$role} avec suucès"]);
    }
    public function addNew()
    {
        $this->showEditModal = false; 
        $this->reset();
        $this->dispatchBrowserEvent('show-form');
    }

    
    public function createUser()
    {
        $validateData = Validator::make($this->state, [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|confirmed'
        ], [
            'name.required' => "Le nom est obligatoire",
            'email.required' => "L'email'est obligatoire",
            'email.email' => "L'email n'est pas valide",
            'email.unique' => "Cet email existe déjà",
            'password.required' => "Le mot de passe est obligatoire",
            'password.confirmed' => "Les deux mots de passe sont différents",
        ])->validate();

        $validateData['password'] = bcrypt($validateData['password']);

        if ($this->photo) {
            $imageName = Carbon::now()->timestamp.'.'.$this->photo->extension();
            $this->photo->storeAs('users',$imageName);
            $validateData['avatar'] = $imageName; 
        }
        User::create($validateData);

        $this->dispatchBrowserEvent('hide-form', ['message' => "Utilisateur ajouté avec succès !"]);

        $this->state = [];
 
    }
    public function edit(User $user)
    {
        $this->reset();

        $this->showEditModal = true;

        $this->user = $user;

        $this->state = $user->toArray();
        $this->tmp_avatar = $this->state['avatar'];
        $this->dispatchBrowserEvent('show-form');
    }

    public function updateUser()
    {
        $validateData = Validator::make($this->state, [
            'name' => 'required',
            'email' => 'required|email|unique:users,email,'.$this->user->id,
            'password' => 'sometimes|confirmed'
        ], [
            'name.required' => "Le nom est obligatoire",
            'email.required' => "L'email'est obligatoire",
            'email.email' => "L'email n'est pas valide",
            'email.unique' => "Cet email existe déjà",
            'password.required' => "Le mot de passe est obligatoire",
            'password.confirmed' => "Les deux mots de passe sont différents",
        ])->validate();
 
        if (!empty($valideData['password'])) {
            $validateData['password'] = bcrypt($validateData['password']);
        }
        if ($this->photo) {
            //
            if ($this->tmp_avatar == 'utilisateur.png' || $this->tmp_avatar == 'no-photo.png' || $this->tmp_avatar == null ) {
                
                $imageName = Carbon::now()->timestamp.'.'.$this->photo->extension();
                $this->photo->storeAs('users',$imageName);
                $validateData['avatar'] = $imageName; 
               
            }else {
                unlink('backend/img/users/'.$this->state['avatar']);
                $imageName = Carbon::now()->timestamp.'.'.$this->photo->extension();
                $this->photo->storeAs('users',$imageName);
                $validateData['avatar'] = $imageName;  
            }
            
        }
        $this->user->update($validateData);

        $this->dispatchBrowserEvent('hide-form', ['message' => "Utilisateur modifié avec succès !"]);

        $this->state = [];  
    }

    public function confirmUserRemoval($userId)
    {
        $this->userIdBeingRemoved = $userId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteUser()
    {
        $user = User::findOrFail($this->userIdBeingRemoved);
        $user->delete();
        $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Utilisateur suprimé avec succès !"]);
    }
    public function render()
    {
         
        $users = User::query()
                ->where('name','like', '%'.$this->searchTerm.'%')
                ->orWhere('email','like', '%'.$this->searchTerm.'%')
                ->latest()->paginate(10);

     
        return view('livewire.admin.users.list-users', [
            'users' => $users
        ]);
    }
}
