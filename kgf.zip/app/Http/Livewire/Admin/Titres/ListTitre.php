<?php

namespace App\Http\Livewire\Admin\Titres;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Titre;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListTitre extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $titreIdBeingRemoved = null;
    public $titre;
    public $searchTerm = null;
    public $selectedIds = [];
 

    
    public function addNew()
    {
        if (Gate::allows('access','Titre-Ajouter')) {
            $this->showEditModal = false; 
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function createTitre()
    { 
        $validateData = Validator::make($this->state, [ 
            'name' => 'required', 
        ], [ 
            'name.required' => "Le nom est obligatoire", 
        ])->validate();
            
            if (Gate::allows('access','Titre-Ajouter')) {
                Titre::create($validateData); 
                $this->dispatchBrowserEvent('hide-form', ['message' => "Titre ajouté avec succès !"]); 
            }

            $this->state = [];
         
 
    }
    public function edit(Titre $titre)
    {
        if (Gate::allows('access','Titre-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->titre = $titre;

            $this->state = $titre->toArray();   
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateTitre()
    {
        $validateData = Validator::make($this->state, [ 
            'name' => 'required',
            'description' => 'nullable',
        ], [ 
            'name.required' => "Le nom est obligatoire", 
        ])->validate();
        
        if (Gate::allows('access','Titre-Modifier')) {

            $this->titre->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Titre modifié avec succès !"]);
        }

        $this->state = [];  
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Titre-Supprimer-Groupe')) {
            Titre::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Titre ont étés supprimés?']);

            $this->reset(['selectedRows','selectedPageRows']);
        }
    }
    public function confirmTitreRemoval($titreId)
    {
        $this->titreIdBeingRemoved = $titreId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteTitre()
    {
        if (Gate::allows('access','Titre-Supprimer')) {
            $titre = Titre::findOrFail($this->titreIdBeingRemoved);
            $titre->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Titre suprimé avec succès !"]); 
        }  
    }
    public function render()
    {
        $titres = Titre::query()
                ->where('name','like', '%'.$this->searchTerm.'%') 
                ->latest()->paginate(12); 
        return view('livewire.admin.titres.list-titre', compact('titres'));
    }
}
