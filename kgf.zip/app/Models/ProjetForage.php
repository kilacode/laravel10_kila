<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProjetForage extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function client()
    {
        return $this->belongsTo(Client::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function conditionGeologique(): BelongsTo
    {
        return $this->belongsTo(ConditionsGeologique::class, 'condition_geologique_id');
    }
    public function typeForage()
    {
        return $this->belongsTo(TypeForage::class, 'type_forage_id');
    }
    public function getEtatIconAttribute()
    {
        $icon = [
            'En attente' => 'fa fa-clock',
            'En cours de forage' => 'fa fa-wrench',
            'Terminé' => 'fa fa-check-circle',
            'En attente de conditions géologiques' => 'fa fa-exclamation-circle',
            "En attente d'approbations" => 'fa fa-check',
            'Abandonné' => 'fa fa-times',
            'En attente de financement' => 'fa fa-money-bill',
            "En cours de construction d'infrastructure" => 'fa fa-building',
            'En cours de test' => 'fa fa-flask',
            'Opérationnel' => 'fa fa-play-circle',
        ];

        $color = [
            'En attente' => 'warning',
            'En cours de forage' => 'primary',
            'Terminé' => 'success',
            'En attente de conditions géologiques' => 'danger',
            "En attente d'approbations" => 'info',
            'Abandonné' => 'secondary',
            'En attente de financement' => 'dark',
            "En cours de construction d'infrastructure" => 'light',
            'En cours de test' => 'secondary',
            'Opérationnel' => 'success',
        ];

        return '<span class="p-2 badge badge-' . $color[$this->etat_projet] . '">
    <i class="' . $icon[$this->etat_projet] . ' mr-2"></i> ' . ucfirst($this->etat_projet) . '</span>';
    }

}