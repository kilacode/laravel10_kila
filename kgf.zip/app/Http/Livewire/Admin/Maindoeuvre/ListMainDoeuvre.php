<?php

namespace App\Http\Livewire\Admin\Maindoeuvre;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\MainDoeuvre;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListMainDoeuvre extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $maindoeuvreIdBeingRemoved = null;
    public $maindoeuvre;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Maindoeuvre-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    } 
    public function createMaindoeuvre()
    {  
        $validateData = Validator::make($this->state, [ 
            'nom_personnel' => 'required', 
            'taux_horaire' => 'required'
        ], [
            'nom_personnel.required' => "Le nom est obligatoire", 
            'taux_horaire.required' => "Le taux horaire est obligatoire"
        ])->validate();  
        if (Gate::allows('access', 'Maindoeuvre-Ajouter')) {
            MainDoeuvre::create($validateData);
            //$this->dispatchBrowserEvent('hide-form', ['message' => "maindoeuvre géologique ajoutée avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(MainDoeuvre $maindoeuvre)
    {
        if (Gate::allows('access', 'Maindoeuvre-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->maindoeuvre = $maindoeuvre;

            $this->state = $maindoeuvre->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateMaindoeuvre()
    {
        $validateData = Validator::make($this->state, [ 
            'nom_personnel' => 'required', 
            'taux_horaire' => 'required'
        ], [
            'nom_personnel.required' => "Le nom est obligatoire", 
            'taux_horaire.required' => "Le Taux horaire est obligatoire"
        ])->validate(); 

        if (Gate::allows('access', 'Maindoeuvre-Modifier')) {

            $this->maindoeuvre->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Main d'oeuvre modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Maindoeuvre-Supprimer-Groupe')) {
            MainDoeuvre::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos équipements ont étés supprimés']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmmaindoeuvreRemoval($maindoeuvreId)
    {
        $this->maindoeuvreIdBeingRemoved = $maindoeuvreId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteMaindoeuvre()
    {
        if (Gate::allows('access', 'Maindoeuvre-Supprimer')) {
            $maindoeuvre = MainDoeuvre::findOrFail($this->maindoeuvreIdBeingRemoved);
            $maindoeuvre->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Main d'oeuvre suprimé avec succès !"]);
        }
    }
    public function render()
    {  
        $maindoeuvres = MainDoeuvre::query()
        ->where('nom_personnel','like', '%'.$this->searchTerm.'%') 
        ->latest()->paginate(12); 
        return view('livewire.admin.maindoeuvre.list-main-doeuvre', compact('maindoeuvres'));
    }
}
