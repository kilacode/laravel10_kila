<div>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Projets</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Projets</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            <a href="<?php echo e(route('admin.add.project')); ?>">
                                <button class="btn btn-primary ">
                                    <i class="fa fa-plus-circle mr-1"></i> Ajouter 
                                </button>
                            </a>
                            <?php if($selectedRows): ?>
                                <div class="btn-group ml-2">
                                    <button type="button" class="btn btn-default">Action</button>
                                    <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                        data-toggle="dropdown" aria-expanded="false">
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <div class="dropdown-menu" role="menu" style="">
                                        <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                            href="#">Supprimer Projets sélectionnés</a>
                                        <a wire:click.prevent="markAsEnAttente" class="dropdown-item"
                                            href="#">Marquer comme En attente</a>
                                        <a wire:click.prevent="markAsEnCoursDeForage" class="dropdown-item"
                                            href="#">Marquer comme En cours de forage</a>
                                        <a wire:click.prevent="markAsTermine" class="dropdown-item"
                                            href="#">Marquer comme Terminé</a>
                                        <a wire:click.prevent="markAsEnAttenteConditionsGeologiques"
                                            class="dropdown-item" href="#">Marquer comme En attente de conditions
                                            géologiques</a>
                                        <a wire:click.prevent="markAsEnAttenteApprobations" class="dropdown-item"
                                            href="#">Marquer comme En attente d'approbations</a>
                                        <a wire:click.prevent="markAsAbandonne" class="dropdown-item"
                                            href="#">Marquer comme Abandonné</a>
                                        <a wire:click.prevent="markAsEnAttenteFinancement" class="dropdown-item"
                                            href="#">Marquer comme En attente de financement</a>
                                        <a wire:click.prevent="markAsEnCoursDeConstructionInfrastructure"
                                            class="dropdown-item" href="#">Marquer comme En cours de construction
                                            d'infrastructure</a>
                                        <a wire:click.prevent="markAsEnCoursDeTest" class="dropdown-item"
                                            href="#">Marquer comme En cours de test</a>
                                        <a wire:click.prevent="markAsOperationnel" class="dropdown-item"
                                            href="#">Marquer comme Opérationnel</a>
                                        <a wire:click.prevent="export" class="dropdown-item" href="#">Exporter</a>
                                    </div>
                                </div>

                                <span class="ml-2"><?php echo e(count($selectedRows)); ?>

                                    <?php echo e(Str::plural(' Projets', count($selectedRows))); ?> <i
                                        class="fa fa-check"></i></span>
                            <?php endif; ?>
                        </div>

                        <div class="btn-group">
                            <button wire:click="filterProjetByStatus" type="button"
                                class="btn <?php echo e(is_null($status) ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Tout</span>
                                <span class="badge badge-pull badge-info"><?php echo e($projetCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente')" type="button"
                                class="btn <?php echo e($status == 'En attente' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En attente</span>
                                <span class="badge badge-pull badge-warning"><?php echo e($projetEnAttenteCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En cours de forage')" type="button"
                                class="btn <?php echo e($status == 'En cours de forage' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En cours de forage</span>
                                <span class="badge badge-pull badge-info"><?php echo e($projetEnCoursDeForageCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('Terminé')" type="button"
                                class="btn <?php echo e($status == 'Terminé' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Terminé</span>
                                <span class="badge badge-pull badge-success"><?php echo e($projetTermineCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente de conditions géologiques')" type="button"
                                class="btn <?php echo e($status == 'En attente de conditions géologiques' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En attente de CG</span>
                                <span class="badge badge-pull badge-dark"><?php echo e($projetEnAttenteConditionsCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente d\'approbations')" type="button"
                                class="btn <?php echo e($status == 'En attente d\'approbations' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En attente d'approb.</span>
                                <span class="badge badge-pull badge-warning"><?php echo e($projetEnAttenteApprobationsCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('Abandonné')" type="button"
                                class="btn <?php echo e($status == 'Abandonné' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Abandonné</span>
                                <span class="badge badge-pull badge-danger"><?php echo e($projetAbandonneCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En attente de financement')" type="button"
                                class="btn <?php echo e($status == 'En attente de financement' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En attente de financement</span>
                                <span class="badge badge-pull badge-info"><?php echo e($projetEnAttenteFinancementCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En cours de construction d\'infrastructure')" type="button"
                                class="btn <?php echo e($status == 'En cours de construction d\'infrastructure' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En construction</span>
                                <span class="badge badge-pull badge-primary"><?php echo e($projetEnCoursConstructionCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('En cours de test')" type="button"
                                class="btn <?php echo e($status == 'En cours de test' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">En cours de test</span>
                                <span class="badge badge-pull badge-info"><?php echo e($projetEnCoursTestCount); ?></span>
                            </button> 
                            <button wire:click="filterProjetByStatus('Opérationnel')" type="button"
                                class="btn <?php echo e($status == 'Opérationnel' ? 'btn-secondary' : 'btn-default'); ?>">
                                <span class="mr-1">Opérationnel</span>
                                <span class="badge badge-pull badge-success"><?php echo e($projetOperationnelCount); ?></span>
                            </button> 
                        </div>
                        

                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-input','data' => ['wire:model' => 'searchTerm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'searchTerm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="custom-control custom-checkbox">
                                                    <input wire:model="selectedPageRows" class="custom-control-input"
                                                        type="checkbox" id="customCheckbox1" value="">
                                                    <label for="customCheckbox1" class="custom-control-label"></label>
                                                </div>
                                            </th>
                                            <th>#</th>
                                            <th>Nom du Projet</th>
                                            <th>Lieu</th>
                                            <th>Profondeur Souhaitée</th>
                                            <th>Diamètre Souhaité</th>
                                            <th>État du Projet</th>
                                            <th>Type de Forage</th>
                                            <th>Conditions Géologiques</th>
                                            <th>Coût Total</th>
                                            <th>Client</th>
                                            <th>Utilisateur</th>
                                            <th>Options</th>  
                                        </tr>
                                    </thead>
                                    <tbody wire:loading.class='text-muted' >
                                        <?php $__empty_1 = true; $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>  
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="<?php echo e($projet->id); ?>"
                                                            value="<?php echo e($projet->id); ?>">
                                                        <label for="<?php echo e($projet->id); ?>"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>

                                                <th scope="row"><?php echo e($loop->iteration); ?></td>  
                                                <td><?php echo e($projet->nom_projet); ?></td>
                                                <td> <?php echo e($projet->lieu); ?> </td>
                                                <td><?php echo e($projet->profondeur_souhaitee); ?> m</td>
                                                <td><?php echo e($projet->diametre_souhaite); ?> m</td> 
                                                <td> <?php echo $projet->getEtatIconAttribute(); ?> </td>
                                                <td><?php echo e($projet->typeForage->nom_type); ?></td>
                                                <td><?php echo e($projet->conditionGeologique->nom_condition); ?></td>
                                                <td><?php echo e(number_format($projet->cout_total, 2, ',', ' ')); ?> $</td>
                                                <td><?php echo e(Str::upper($projet->client->nom)); ?></td>
                                                <td><?php echo e(Str::upper($projet->user->name)); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.project.edit', $projet)); ?>"><i class="fa fa-edit mr-2"></i></a>
                                                    <a href="" wire:click.prevent="confirmProjetRemoval(<?php echo e($projet->id); ?>)"><i class="fa fa-trash text-danger"></i></a>
                                                </td> 
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr class="text-center">
                                                <td colspan="13">
                                                    <img src="<?php echo e(asset('img/page-not-found.png')); ?>" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            <?php echo $projets->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirmation-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
    <style>
        .draggable-mirror {
            background-color: white;
            width: 950px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Dev\kgf\resources\views/livewire/admin/projects/list-project.blade.php ENDPATH**/ ?>