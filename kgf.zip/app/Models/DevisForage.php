<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DevisForage extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $casts = [
        'date' => 'datetime', 
    ];

    public function projetForage(): BelongsTo
    {
        return $this->belongsTo(ProjetForage::class, 'projet_forage_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function getEtatIconAttribute()
    {
        $icon = [
            'En attente' => 'fa fa-clock',
            'En cours' => 'fa fa-wrench',
            'Terminé' => 'fa fa-check-circle',
            'Validé' => 'fa fa-check',
            'Annulé' => 'fa fa-times',
        ];

        $color = [
            'En attente' => 'warning',
            'En cours' => 'primary',
            'Terminé' => 'success',
            'Validé' => 'info',
            'Annulé' => 'secondary',
        ];

        return '<span class="p-2 badge badge-' . $color[$this->etat] . '">
        <i class="' . $icon[$this->etat] . ' mr-2"></i> ' . ucfirst($this->etat) . '</span>';
    }
    public function getDateAttribute($value)
    {
        return Carbon::parse($value)->toFormattedDate();
    }

    public function toggleValidity()
    {
        $this->is_valid = !$this->is_valid;
        $this->save();

        return $this->is_valid;
    }

    public function devis_item()
    {
        return $this->hasMany(DevisItem::class);
    }
    public function int2str($a)
    {
        $convert = explode('.', $a);
        $dollars = $this->convertNumberToWords($convert[0]) . ' Dollars';
        
        if (isset($convert[1]) && $convert[1] != '') {
            $centimes = $this->convertNumberToWords($convert[1]) . ' Centimes';
            return $dollars . ' et ' . $centimes;
        }
    
        return $dollars;
    }
    
    private function convertNumberToWords($number)
    {
        $units = array(
            '00' => 'zero',
            0 => 'zero',
            1 => 'un',
            2 => 'deux',
            3 => 'trois',
            4 => 'quatre',
            5 => 'cinq',
            6 => 'six',
            7 => 'sept',
            8 => 'huit',
            9 => 'neuf',
            10 => 'dix',
            11 => 'onze',
            12 => 'douze',
            13 => 'treize',
            14 => 'quatorze',
            15 => 'quinze',
            16 => 'seize',
            20 => 'vingt',
            30 => 'trente',
            40 => 'quarante',
            50 => 'cinquante',
            60 => 'soixante',
            70 => 'soixante-dix',
            80 => 'quatre-vingt',
            90 => 'quatre-vingt-dix'
        );
    
        if ($number < 0) {
            return 'moins ' . $this->convertNumberToWords(-$number);
        }
    
        if ($number < 17) {
            return $units[$number];
        }
    
        if ($number < 20) {
            return 'dix-' . $this->convertNumberToWords($number - 10);
        }
    
        if ($number < 100) {
            if ($number % 10 == 0) {
                return $units[$number];
            } elseif ($number < 70) {
                $prefix = $this->convertNumberToWords($number - $number % 10);
                $suffix = $this->convertNumberToWords($number % 10);
                return $prefix . '-' . $suffix;
            } elseif ($number < 80) {
                $prefix = $this->convertNumberToWords(60);
                $suffix = $this->convertNumberToWords($number % 20);
                return $prefix . '-' . $suffix;
            } else {
                $prefix = $this->convertNumberToWords(80);
                $suffix = $this->convertNumberToWords($number % 20);
                return $prefix . '-' . $suffix;
            }
        }
    
        if ($number == 100) {
            return 'cent';
        }
    
        if ($number < 200) {
            $prefix = $this->convertNumberToWords(100);
            $suffix = $this->convertNumberToWords($number % 100);
            return $prefix . ' ' . $suffix;
        }
    
        if ($number < 1000) {
            $prefix = $this->convertNumberToWords((int) ($number / 100));
            $suffix = $this->convertNumberToWords(100);
            $remainder = $this->convertNumberToWords($number % 100);
            return $prefix . ' ' . $suffix . ' ' . $remainder;
        }
    
        if ($number == 1000) {
            return 'mille';
        }
    
        if ($number < 2000) {
            $prefix = $this->convertNumberToWords(1000);
            $suffix = $this->convertNumberToWords($number % 1000);
            return $prefix . ' ' . $suffix;
        }
    
        if ($number < 1000000) {
            $prefix = $this->convertNumberToWords((int) ($number / 1000));
            $suffix = $this->convertNumberToWords(1000);
            $remainder = $this->convertNumberToWords($number % 1000);
            return $prefix . ' ' . $suffix . ' ' . $remainder;
        }
    
        if ($number < 2000000) {
            $prefix = 'un million';
            $suffix = $this->convertNumberToWords($number % 1000000);
            return $prefix . ' ' . $suffix;
        }
    
        if ($number < 1000000000) {
            $prefix = $this->convertNumberToWords((int) ($number / 1000000));
            $suffix = 'millions';
            $remainder = $this->convertNumberToWords($number % 1000000);
            return $prefix . ' ' . $suffix . ' ' . $remainder;
        }
    }

}