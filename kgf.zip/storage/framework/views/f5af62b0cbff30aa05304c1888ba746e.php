<style>
    .cell {
        width: 30%;
        /* Vous pouvez ajuster la largeur selon vos besoins */
        padding: 5px;
        text-align: center;
    }

    .clearfix:after {
        content: "";
        display: table;
        clear: both;
    }

    body {
        position: relative;
        width: calc(21cm - 40px);
        /* 21cm - 2*20px */
        height: 29.7cm;
        margin: 0 20px;
        /* Ajout des marges gauche et droite */
        color: #001028;
        background: #FFFFFF;
        font-family: Arial, sans-serif;
        font-size: 12px;
    }

    header {
        padding: 10px 0;
        margin-bottom: 30px;
    }

    #project {
        float: left;
    }

    #project span {
        color: #5D6975;
        text-align: right;
        width: 52px;
        margin-right: 10px;
        display: inline-block;
        font-size: 0.8em;
    }

    #company {
        float: right;
        text-align: right;
    }

    #project div,
    #company div {
        white-space: nowrap;
    }

    .watermark {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0.5;
        z-index: 9999;
        text-align: center;
        vertical-align: middle;
    }

    .watermark-text {
        color: red;
        font-size: 60px;
        transform: rotate(-45deg);
        margin-top: 200px;
    }

    .styled-table {
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 0.8em;
        font-family: sans-serif;
        min-width: 100%;
        text-align: left;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table2 {
        border-collapse: collapse;
        margin: 16px 0;
        font-size: 0.7em;
        font-family: sans-serif;
        min-width: 100%;

    }

    .styled-table3 {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 1em;
        font-family: sans-serif;
        min-width: 50%;
    }

    .styled-table4 {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 1em;
        font-family: sans-serif;
        min-width: 100%;
    }

    .styled-table2 th {
        text-align: center;
    }

    .styled-table4 th {
        text-align: center;
    }

    .styled-table4 p {
        font-size: 25px;

        margin-top: -20px;
        margin-bottom: 13px
    }


    .styled-table thead tr {
        background-color: #02617e;
        color: #ffffff;
        text-align: left;
    }

    .styled-table thead th {
        text-align: left;
    }

    .styled-table tfoot th {
        text-align: left;
    }

    .styled-table tfoot tr {
        background-color: #ffc157;
        color: #000000;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 4px 3px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

    .styled-table tbody tr:last-of-type {}

    .styled-table tbody tr.active-row {
        font-weight: bold;
    }

    h4 {
        font-family: sans-serif;
    }

    footer {
        position: fixed;
        bottom: 40px;
        left: 0px;
        right: 0px;
        height: 3px;
        margin-bottom: -20px;
        /** Extra personal styles **/
        background-color: rgb(13, 52, 135);
        font-family: sans-serif;
        color: #000;
        text-align: center;
        line-height: 6px;
    }

    footer p {
        font-size: 10px;
    }

    footer .pagenum:before {
        content: counter(page);
    }

    .footer {
        margin-top: 20px;
        border-top: 1px solid #ddd;
        padding-top: 10px;
    }
</style>

<table class="styled-table3" style="width: 100%; margin-top:-15px">
    <tr>
        <th style="text-align: left; width: 50%"> <img src="<?php echo e(public_path('img/v.jpg')); ?>" alt="" height="100">
        </th>

        <td style="text-align: right; width: 50%"><span><?php echo $code; ?></span></td>
    </tr>
    <tr>
        <th style="text-align: left; width: 50%"></th>
        <th style="text-align: right; width: 50%"> </th>
    </tr>
    <tr>
        <th style="text-align: left; width: 50%"></th>
        <th style="text-align: right; width: 50%; font-size: 12px">Le <?php echo e(date('d/m/Y', strtotime($date))); ?></th>
    </tr>

</table>

<body>
    <header class="clearfix">
        <div id="company" class="clearfix">
            <div><?php echo e($infos->site_title); ?></div>
            <div><?php echo e($infos->site_name); ?></div>
            <div><a href="mailto:<?php echo e($infos->site_email); ?>"><?php echo e($infos->site_email); ?></a></div>
        </div>
        <div id="project">
            <div><span>PROJET</span> <?php echo e($facture->projet->nom_projet); ?></div>
            <div><span>FACTURE</span> <?php echo e($facture->numero); ?></div>
            <div><span>CLIENT</span> <?php echo e($facture->projet->client->prenom); ?> <?php echo e($facture->projet->client->nom); ?>

            </div> 
            <div><span>EMAIL</span> <a href="mailto:<?php echo e($facture->projet->client->email); ?>"><?php echo e($facture->projet->client->email); ?></a>
            </div> 
        </div>
    </header>
    <?php if($facture->is_valid == 0): ?>
        <div class="watermark">
            <div class="watermark-text">Reçu Invalide <br>Reçu Invalide<br>Reçu Invalide<br>Reçu Invalide </div>
        </div>
    <?php else: ?>  
                <table class="styled-table"> 
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Numero</th>
                            <th scope="col">Montant Payé</th>
                            <th scope="col">Reste</th>  
                            <th scope="col">Date</th>
                        </tr>
                    </thead>
                    <tbody style="background-color: #fff">
                        <?php $__currentLoopData = $facture->payement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->numero); ?></td>
                                <td><?php echo e($item->montant_paye); ?> $</td>
                                <td><?php echo e($item->reste); ?> $</td> 
                                <td> <?php echo e(date('d/m/Y à h:i', strtotime($item->created_at))); ?> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </tbody> 
                </table> 
    <?php endif; ?> 
</body>

<footer>
    <p>1542, avenue province Quartier Golf /
        <a href="mailto:<?php echo e($infos->site_email); ?>"><?php echo e($infos->site_email); ?></a>
    </p>
    <p>
        <a href="telto:+243 817 636 277">+243 817 636 277</a>
        /<a href="telto:+243 973 765 970">+243 973 765 970</a>
    </p>
    <div class="pagenum-container">
        <p>KGF Solution / <a href="www.kgfsolution.cd">www.kgfsolution.cd </a> Page<span class="pagenum"></span></p>
    </div>
</footer>
<?php /**PATH D:\Dev\kgf\resources\views/documents/recues.blade.php ENDPATH**/ ?>