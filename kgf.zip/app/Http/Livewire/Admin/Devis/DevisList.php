<?php

namespace App\Http\Livewire\Admin\Devis;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\DevisForage;
use Illuminate\Support\Facades\Gate;

class DevisList extends AdminComponent
{
    protected $listeners = ['deleteConfirmed' => 'deleteDevis'];
    public $status = null;
    public $type = null;
    public $selectedRows = [];
    public $selectedPageRows = false;
    protected $queryString = ['status'];
    public $showEditModal = false;
    public $devisIdBeingRemoved = null;
    public $user;
    public $searchTerm = null;

    public function updatedSelectedPageRows($value)
    {
        if ($value) {
            $this->selectedRows = $this->devisForage->pluck('id')->map(function ($id) {
                return (string) $id;
            });
        } else {
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }


    public function markAsEnAttente()
    {
        if (Gate::allows('access', 'Devis-Forage-Modifier')) {
            DevisForage::whereIn('id', $this->selectedRows)->update(['etat' => 'En attente']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les devis sont marqués comme en attente']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function markAsValide()
    {
        if (Gate::allows('access', 'Devis-Forage-Ajouter')) {
            DevisForage::whereIn('id', $this->selectedRows)->update(['etat' => 'Validé']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les devis sont marqués comme Validé']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }

    }

    public function markAsTermine()
    {
        if (Gate::allows('access', 'Devis-Forage-Ajouter')) {
            DevisForage::whereIn('id', $this->selectedRows)->update(['etat' => 'Terminé']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les devis sont marqués comme Terminés']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }   
    public function markAsEnCours()
    {
        if (Gate::allows('access', 'Devis-Forage-Ajouter')) {
            DevisForage::whereIn('id', $this->selectedRows)->update(['etat' => 'En cours']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les devis sont marqués comme En cours']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function markAsAnnule()
    {
        if (Gate::allows('access', 'Devis-Forage-Ajouter')) {
            DevisForage::whereIn('id', $this->selectedRows)->update(['etat' => 'Annulé']);
            $this->dispatchBrowserEvent('updated', ['message' => 'Tout les devis sont marqués comme Annulé']);
            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    } 
    public function export()
    {
        dd('ok');
        //return (new ProjetExport($this->selectedRows))->download('Projet.xls');

    }
    public function confirmDevisRemoval($devisId)
    {
        $this->devisIdBeingRemoved = $devisId;

        $this->dispatchBrowserEvent('show-delete-confirmation');
    }

    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Devis-Forage-Supprimer-Groupe')) { 
        DevisForage::whereIn('id', $this->selectedRows)->delete();

        $this->dispatchBrowserEvent('deleted', ['message' => 'Ces Devis ont étés supprimés']);

        $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }

    public function deleteDevis()
    {
        if (Gate::allows('access','Devis-Forage-Supprimer')) { 
        $devis = DevisForage::findOrFail($this->devisIdBeingRemoved);
        $devis->delete();
        $this->dispatchBrowserEvent('deleted', ['message' => "Devis supprimé avec succès !"]);
        }
    }

    public function filterDevisByStatus($status = null)
    {
        $this->resetPage();
        $this->reset('status');
        $this->status = $status;
    }

    public function getDevisForageProperty()
    {
        $query = DevisForage::with(['user', 'projetForage'])
            ->where('titre', 'like', '%' . $this->searchTerm . '%');

        if ($this->status) {
            $query->where('etat', $this->status);
        }

        $query->orderBy('created_at', 'desc');

        return $query->paginate(10);
    }

    public function toggleDevisValidity(DevisForage $devis)
    {
       if (Gate::allows('access','Devis-Forage-Modifier')) {
        $devis->toggleValidity(); 
        $this->dispatchBrowserEvent('updated', ['message' => 'Devis modifié']);
       } 
    }
    public function render()
    {
        $deviss = $this->devisForage;
        $devisCount = DevisForage::count();

        $devisEnAttenteCount = DevisForage::where('etat', 'En attente')->count();
        $devisEnCoursCount = DevisForage::where('etat', 'En cours')->count();
        $devisTermineCount = DevisForage::where('etat', 'Terminé')->count();
        $devisValideCount = DevisForage::where('etat', "Validé")->count(); 
        $devisAnnuleCount = DevisForage::where('etat', 'Annulé')->count(); 
        return view('livewire.admin.devis.devis-list',  
        compact('devisEnAttenteCount',
                'devisEnCoursCount',
                'devisTermineCount',
                'devisValideCount',
                'devisAnnuleCount','devisCount','deviss'));
    }
}
