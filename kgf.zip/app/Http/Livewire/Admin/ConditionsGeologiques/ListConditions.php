<?php

namespace App\Http\Livewire\Admin\ConditionsGeologiques;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\ConditionsGeologique;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator; 

class ListConditions extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $conditionIdBeingRemoved = null;
    public $condition;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Condition-geologique-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    } 
    public function createCondition()
    { 

        $validateData = Validator::make($this->state, [ 
            'nom_condition' => 'required', 
        ], [
            'nom_condition.required' => "Le nom est obligatoire", 
        ])->validate(); 
        if (Gate::allows('access', 'Condition-geologique-Ajouter')) {
            ConditionsGeologique::create($validateData);
            //$this->dispatchBrowserEvent('hide-form', ['message' => "Condition géologique ajoutée avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(ConditionsGeologique $condition)
    {
        if (Gate::allows('access', 'Condition-geologique-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->condition = $condition;

            $this->state = $condition->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateCondition()
    {
        $validateData = Validator::make($this->state, [ 
            'nom_condition' => 'required', 
        ], [
            'nom_condition.required' => "Le nom est obligatoire", 
        ])->validate();

        if (Gate::allows('access', 'Condition-geologique-Modifier')) {

            $this->condition->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Condition modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Condition-geologique-Supprimer-Groupe')) {
            ConditionsGeologique::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Conditions géologiques ont étés supprimés']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmConditionRemoval($conditionId)
    {
        $this->conditionIdBeingRemoved = $conditionId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteCondition()
    {
        if (Gate::allows('access', 'Condition-geologique-Supprimer')) {
            $condition = ConditionsGeologique::findOrFail($this->conditionIdBeingRemoved);
            $condition->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Condition suprimé avec succès !"]);
        }
    }
    public function render()
    {
        $searchTerm = '%' . $this->searchTerm . '%';

        $conditions = ConditionsGeologique::query()
        ->where('nom_condition','like', '%'.$this->searchTerm.'%') 
        ->latest()->paginate(12); 
        return view('livewire.admin.conditions-geologiques.list-conditions', compact('conditions'));
    }
}
