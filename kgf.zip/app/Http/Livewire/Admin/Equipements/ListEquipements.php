<?php

namespace App\Http\Livewire\Admin\Equipements;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\EquipementForage;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListEquipements extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $equipementIdBeingRemoved = null;
    public $equipement;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Equipement-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    } 
    public function createEquipement()
    { 

        $validateData = Validator::make($this->state, [ 
            'nom_equipement' => 'required', 
            'cout_par_heure' => 'required'
        ], [
            'nom_equipement.required' => "Le nom est obligatoire", 
            'cout_par_heure.required' => "Le cout horaire est obligatoire"
        ])->validate(); 
        if (Gate::allows('access', 'Equipement-Ajouter')) {
            EquipementForage::create($validateData);
            //$this->dispatchBrowserEvent('hide-form', ['message' => "equipement géologique ajoutée avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(EquipementForage $equipement)
    {
        if (Gate::allows('access', 'Equipement-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->equipement = $equipement;

            $this->state = $equipement->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateEquipement()
    {
        $validateData = Validator::make($this->state, [ 
            'nom_equipement' => 'required', 
            'cout_par_heure' => 'required'
        ], [
            'nom_equipement.required' => "Le nom est obligatoire", 
            'cout_par_heure.required' => "Le cout horaire est obligatoire"
        ])->validate(); 

        if (Gate::allows('access', 'Equipement-Modifier')) {

            $this->equipement->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Equipement modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Equipement-Supprimer-Groupe')) {
            EquipementForage::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos équipements ont étés supprimés']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmEquipementRemoval($equipementId)
    {
        $this->equipementIdBeingRemoved = $equipementId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteEquipement()
    {
        if (Gate::allows('access', 'Equipement-Supprimer')) {
            $equipement = EquipementForage::findOrFail($this->equipementIdBeingRemoved);
            $equipement->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "equipement suprimé avec succès !"]);
        }
    }
    public function render()
    { 

        $equipements = EquipementForage::query()
        ->where('nom_equipement','like', '%'.$this->searchTerm.'%') 
        ->latest()->paginate(12); 
        return view('livewire.admin.equipements.list-equipements', compact('equipements'));
    }
}
