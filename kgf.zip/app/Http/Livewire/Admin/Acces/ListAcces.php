<?php

namespace App\Http\Livewire\Admin\Acces;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\Acces;
use App\Models\Modele;
use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator; 

class ListAcces extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $accesIdBeingRemoved = null;
    public $acces;
    public $searchTerm = null;
    public $selectedIds = [];
 

    
    public function addNew()
    {
        if (Gate::allows('access','Acces-Ajouter')) {
            $this->showEditModal = false; 
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function createAcces()
    {
        $validateData = Validator::make($this->state, [ 
            'user_id' => 'required', 
        ], [ 
            'user_id.required' => "L'utilisateur est obligatoire", 
        ])->validate();  
            
            if (Gate::allows('access','Acces-Ajouter')) {
                $this->selectedIds = array_filter($this->selectedIds);
            foreach ($this->selectedIds as $name) {
                $access = new Acces;
                $access->name = $name;
                $access->user_id = $validateData['user_id'];
              
                // Vérifier si l'enregistrement existe déjà
                $existingAccess = Acces::where('name', $name)
                  ->where('user_id', $validateData['user_id'])
                  ->first();
              
                if (!$existingAccess) {
                  // L'enregistrement n'existe pas, donc l'enregistrer
                  $access->save();
                }
              }

            $this->dispatchBrowserEvent('hide-form', ['message' => "Accès ajouté avec succès !"]);
            }

            $this->state = [];
         
 
    }
    public function edit(Acces $acces)
    {
        if (Gate::allows('access','Acces-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->acces = $acces;

            $this->state = $acces->toArray(); 
            $existingAccess = Acces::where('user_id', $acces->user_id)
                    ->get();
            $arrayAccess = [];
            foreach ($existingAccess as $access) {
            $arrayAccess[] = $access->name;
            }
            $this->selectedIds = $arrayAccess;
            

            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateAcces()
    {
        $validateData = Validator::make($this->state, [ 
            'user_id' => 'required', 
        ], [ 
            'user_id.required' => "L'utilisateur est obligatoire", 
        ])->validate(); 
        
        if (Gate::allows('access','Acces-Modifier')) {

            $this->acces->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Accès modifié avec succès !"]);
        }

        $this->state = [];  
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Acces-Supprimer-Groupe')) {
            Acces::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Accès ont étés supprimés?']);

            $this->reset(['selectedRows','selectedPageRows']);
        }
    }
    public function confirmAccesRemoval($accesId)
    {
        $this->accesIdBeingRemoved = $accesId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteAcces()
    {
        if (Gate::allows('access','Acces-Supprimer')) {
            $acces = Acces::findOrFail($this->accesIdBeingRemoved);
            $acces->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Accès suprimé avec succès !"]); 
        }  
        
    }
    public function render()
    {
        $access = Acces::query()
                ->where('name','like', '%'.$this->searchTerm.'%') 
                ->latest()->paginate(12);
        $modeles = Modele::orderBy('name','asc')->get();
         
        $users = User::where('role','admin')->orderBy('name','asc')->get(); 
        return view('livewire.admin.acces.list-acces', compact('users','access', 'modeles'));
    }
}
