<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EtapesForage extends Model
{
    use HasFactory;
    protected $guarded = []; 

    public function devis_item()
    {
        return $this->hasMany(DevisItem::class,'etape_forage_id');
    }
    public function facture_item()
    {
        return $this->hasMany(FactureItem::class,'etape_forage_id');
    }
}
