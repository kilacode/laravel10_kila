<div>
    <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Utilisateurs</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                            <li class="breadcrumb-item active">Utilisateurs</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>

         <!-- Main content -->
         <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex justify-content-between mb-2">
                            <button class="btn btn-primary " wire:click.prevent="addNew">
                                <i class="fa fa-plus-circle mr-1"></i> Ajouter utilisateur
                            </button>
                            <x-search-input wire:model='searchTerm' />
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <td>#</td>
                                                <th>Nom</th>
                                                <th>Email</th>
                                                <th>Date d'enregistrement</th>
                                                <th>Role</th>
                                                <th>Options</th>
                                            </tr>
                                        </thead>
                                        <tbody wire:loading.class='text-muted'>
                                            @forelse ($users as $user)
                                                <tr>
                                                    <th scope="row">{{ $loop->iteration }}</td>
                                                    <td>
                                                        <img src="{{ $user->avatar_url }}" style="width: 50px;"
                                                            alt="avatar" class="img img-rounded mr-1">
                                                        {{ Str::upper($user->name) }}
                                                    </td>
                                                    <td>{{ $user->email }}</td>
                                                    <td>{{ $user->created_at->toFormattedDate() }}</td>
                                                    <td>
                                                        <select class="form-control" wire:change="changeRole({{ $user }},$event.target.value)">
                                                            <option value="admin" {{ ($user->role == "admin")? 'selected':'' }}>ADMIN</option>
                                                            <option value="user" {{ ($user->role == "user")? 'selected':'' }}>USER</option>
    
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <a href="" wire:click.prevent="edit({{ $user }})">
                                                            <i class="fa fa-edit mr-2"></i>
                                                        </a>
                                                        <a href=""
                                                            wire:click.prevent="confirmUserRemoval({{ $user->id }})">
                                                            <i class="fa fa-trash text-danger"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr class="text-center">
                                                    <td colspan="7">
                                                        <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                            alt="Aucun résultat trouvé">
                                                        <p>Aucun résultat trouvé</p>
                                                    </td>
                                                </tr>
                                            @endforelse
    
                                        </tbody>
                                    </table>
                                </div>
    
                            </div>
                            <div class="card-footer d-flex justify-content-end">
                                {{ $users->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>

         <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                    @if ($showEditModal == true)
                        <span>Modifier l'utilisateur</span>
                    @else
                        <span>Ajout d'un nouvel utiisateur</span>
                    @endif
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form wire:submit.prevent="{{ $showEditModal ? 'updateUser' : 'createUser' }}">
                    <div class="form-group">
                        <label for="name">Nom</label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror"
                            wire:model.defer="state.name" id="name" aria-describedby="nom" placeholder="Nom">
                        @error('name')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>
                    <div class="form-group">
                        <label for="email">Adresse Email</label>
                        <input type="text" class="form-control @error('email') is-invalid @enderror"
                            wire:model.defer="state.email" id="email" aria-describedby="emailHelp"
                            placeholder="Saisisse l'Email">
                        @error('email')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <input type="password" class="form-control @error('password') is-invalid @enderror"
                            wire:model.defer="state.password" id="password" placeholder="Mot de passe">
                        @error('password')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="passwordconfirmation">Confirmer Mot de passe</label>
                        <input type="password"
                            class="form-control @error('passwordconfirmation') is-invalid @enderror"
                            wire:model.defer="state.password_confirmation" id="passwordconfirmation"
                            placeholder="Confirmer Mot de passe">
                        @error('password_confirmation')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="customfile">Photo de Profile</label>
                        
                        <div class="custom-file">
                            <div x-data="{ isUploading: true, progress: 5 }"
                                 x-on:livewire-upload-start="isUploading = true"
                                 x-on:livewire-upload-finish="isUploading = false; progress = 5"
                                 x-on:livewire-upload-error="isUploading = false"
                                 x-on:livewire-upload-progress="progress = $event.detail.progress"
                            >
                                <input wire:model="photo" type="file" class="custom-file-input"
                                    id="customfile">

                                <div x-show.transition="isUploading" class="progress progress-sm mt-2 rounded">
                                    <div class="progress-bar bg-primary progress-bar-striped" role="progressbar"
                                        aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"
                                        x-bind:style="`width:${progress}%`">
                                        <span class="sr-only">40% Complete (success)</span>
                                    </div>
                                </div>
                            </div>

                            <label class="custom-file-label" for="customfile">
                                @if ($photo)
                                    {{ $photo->getClientOriginalName() }}
                                @else
                                    Choisissez un fichier
                                @endif
                            </label>
                        </div>
                        @if ($photo)
                            <img src="{{ $photo->temporaryUrl() }}" alt=".." class="img img-rounded mb-2 mt-2 w-50"
                                style="width: 50px">
                        @elseif($state['avatar_url'] ?? '')
                            <img src="{{ $state['avatar_url'] ?? '' }}" alt=".."
                                class="img img-rounded mb-2 w-50" style="width: 50px">
                        @endif
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                        class="fa fa-times mr-1"></i> Annuler</button>
                @if ($showEditModal)
                    <button type="submit" class="btn btn-info"><i class="fa fa-save mr-1"></i> Enregistrer les
                        modifications</button>
                @else
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-1"></i>
                        Enregistrer</button>
                @endif
            </div>
            </form>
        </div>
    </div>
</div>


<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Supprimer l'utilisateur</h5>
            </div>
            <div class="modal-body">
                <h4>Etes-vous sûr de vouloir supprimer cet utilisateur?</h4>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                        class="fa fa-times mr-1"></i> Annuler</button>

                <button type="button" wire:click.prevent='deleteUser' class="btn btn-danger"><i
                        class="fa fa-trash mr-1"></i>
                    Supprimer</button>

            </div>
        </div>
    </div>
</div>
         
</div>
