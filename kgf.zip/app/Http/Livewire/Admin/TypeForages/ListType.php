<?php

namespace App\Http\Livewire\Admin\TypeForages;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\TypeForage;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class ListType extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $typeIdBeingRemoved = null;
    public $type;
    public $searchTerm = null;
    public $selectedIds = [];
    public $numero;


    public function addNew()
    {
        if (Gate::allows('access', 'Type-forage-Ajouter')) {
            $this->showEditModal = false;
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    } 
    public function createType()
    { 

        $validateData = Validator::make($this->state, [ 
            'nom_type' => 'required', 
        ], [
            'nom_type.required' => "Le nom est obligatoire", 
        ])->validate(); 
        if (Gate::allows('access', 'Type-forage-Ajouter')) {
            TypeForage::create($validateData);
            $this->dispatchBrowserEvent('hide-form', ['message' => "Type ajouté avec succès !"]);
        }

        $this->state = [];


    }
    public function edit(TypeForage $type)
    {
        if (Gate::allows('access', 'Type-forage-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->type = $type;

            $this->state = $type->toArray();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateType()
    {
        $validateData = Validator::make($this->state, [ 
            'nom_type' => 'required', 
        ], [
            'nom_type.required' => "Le nom est obligatoire", 
        ])->validate();

        if (Gate::allows('access', 'Type-forage-Modifier')) {

            $this->Type->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Type modifié avec succès !"]);
        }

        $this->state = [];
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access', 'Type-forage-Supprimer-Groupe')) {
            TypeForage::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Type ont étés supprimés?']);

            $this->reset(['selectedRows', 'selectedPageRows']);
        }
    }
    public function confirmTypeRemoval($typeId)
    {
        $this->typeIdBeingRemoved = $typeId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteType()
    {
        if (Gate::allows('access', 'Type-forage-Supprimer')) {
            $type = TypeForage::findOrFail($this->TypeIdBeingRemoved);
            $type->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Type suprimé avec succès !"]);
        }
    }
    public function render()
    {
        $searchTerm = '%' . $this->searchTerm . '%';

        $types = TypeForage::query()
        ->where('nom_type','like', '%'.$this->searchTerm.'%') 
        ->latest()->paginate(12); 

        return view('livewire.admin.type-forages.list-type', compact('types'));
    }
}
