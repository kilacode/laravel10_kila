<?php

namespace App\Http\Livewire\Admin\Facture;

use Livewire\Component;

class FactureCreate extends Component
{
    public function render()
    {
        return view('livewire.admin.facture.facture-create');
    }
}
