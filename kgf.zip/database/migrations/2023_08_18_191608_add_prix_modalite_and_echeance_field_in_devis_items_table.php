<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('devis_forages', function (Blueprint $table) {
            $table->string('modalite')->nullable();
            $table->string('echeance')->nullable();
            $table->string('coordonee_banc')->nullable();
            $table->integer('delai_livraison')->nullable();
            $table->text('conditions_general')->nullable();
            $table->string('garantie_rembourse')->nullable();
            $table->string('contact')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('devis_forages', function (Blueprint $table) {
            //
        });
    }
};
