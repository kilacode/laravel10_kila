<?php

namespace App\Http\Livewire\Admin\Projects;

use App\Models\Client;
use App\Models\ConditionsGeologique;
use App\Models\ProjetForage;
use App\Models\TypeForage;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class AddProject extends Component
{
    public $state = ['etat_projet'=>'En attente',
                    'cout_total'=>0];
    public $searchTerm = null;
    public $selectedClient = null;

    public function getClientsProperty()
    {
        return Client::where(function ($query) {
            $query->where('nom', 'like', '%' . $this->searchTerm . '%')
                ->orWhere('prenom', 'like', '%' . $this->searchTerm . '%')
                ->orWhere('email', 'like', '%' . $this->searchTerm . '%')
                ->orWhereRaw("CONCAT(nom, ' ', prenom) LIKE ?", ['%' . $this->searchTerm . '%'])
                ->orWhereRaw("CONCAT(prenom, ' ', nom) LIKE ?", ['%' . $this->searchTerm . '%']);
        })->get();
        
    } 
    public function updatedSelectedClient()
    {
        $this->emitUp('clientSelected', $this->selectedClient); 
    } 
    public function createProjetForage()
    {
       
        Validator::make($this->state, [
            'nom_projet' => 'required',
            'lieu' => 'required',
            'profondeur_souhaitee' => 'required|integer',
            'diametre_souhaite' => 'required|integer',
            'type_forage_id' => 'required|exists:type_forages,id',
            'condition_geologique_id' => 'required|exists:conditions_geologiques,id',
            'etat_projet' => 'required|in:En attente,En cours de forage,Terminé,En attente de conditions géologiques,
            En attente d\'approbations,Abandonné,En attente de financement,En cours de construction d\'infrastructure,En cours de test,Opérationnel',
            'cout_total' => 'nullable', 
        ], [
            'nom_projet.required' => "Le nom du projet ne doit pas être vide",
            'lieu.required' => "Le lieu ne doit pas être vide",
            'profondeur_souhaitee.required' => "La profondeur souhaitée ne peut pas être vide",
            'profondeur_souhaitee.integer' => "La profondeur souhaitée doit être un nombre entier",
            'diametre_souhaite.required' => "Le diamètre souhaité ne peut pas être vide",
            'diametre_souhaite.integer' => "Le diamètre souhaité doit être un nombre entier",
            'type_forage_id.required' => "Veuillez choisir un type de forage",
            'type_forage_id.exists' => "Le type de forage sélectionné n'est pas valide",
            'condition_geologique_id.required' => "Veuillez choisir une condition géologique",
            'condition_geologique_id.exists' => "La condition géologique sélectionnée n'est pas valide",
            'etat_projet.required' => "Veuillez choisir un état de projet",
            'etat_projet.in' => "L'état de projet sélectionné n'est pas valide", 
        ])->validate();
        
        $this->state['client_id'] = $this->selectedClient; 
        $this->state['user_id'] = auth()->user()->id; 

        //dd($this->state);
        if (isset($this->state['client_id']) && !empty($this->state['client_id'])) {
            if (Gate::allows('access','Projet-Forage-Ajouter')) {
                ProjetForage::create($this->state);
                $this->dispatchBrowserEvent('alert', ['message' => "Projet Forage creé avec succès !"]);
                $this->reset('state');
                return redirect()->route('admin.projects');
            }
        } else {
            dd('Veuillez rechercher un client');
        }
    }
    public function render()
    {
        $clients = $this->clients;
        $typesForage = TypeForage::orderBy('nom_type','asc')->get();
        $conditionsGeologiques = ConditionsGeologique::orderBy('nom_condition','asc')->get();
        return view('livewire.admin.projects.add-project', compact('clients','typesForage','conditionsGeologiques'));
    }
}
