<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Modifier Projet</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.projects') }}">Projet</a></li>
                        <li class="breadcrumb-item active">Modifier Projet</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form wire:submit.prevent='updateProjet' autocomplete="off">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Modifier Projet</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="nom_projet">Nom du projet :</label>
                                            <input type="text"
                                                class="form-control @error('nom_projet') is-invalid @enderror"
                                                id="nom_projet" wire:model.defer="state.nom_projet"
                                                placeholder="Nom du projet">
                                            @error('nom_projet')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="client_id">Client :</label>
                                        <div class="form-group">
                                            <input type="text" wire:model.debounce.500ms="searchTerm"
                                                class="form-control" placeholder="Rechercher un client...">

                                            <select wire:model="selectedClient"
                                                class="form-control select2 @error('client_id') is-invalid @enderror">
                                                <option value="">-- Sélectionner un client --</option>
                                                @if ($searchTerm)
                                                    @foreach ($clients as $client)
                                                        <option value="{{ $client->id }}">{{ $client->prenom }}
                                                            {{ $client->nom }}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                            @error('client_id')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="type_forage_id">Type de forage :</label>
                                            <select class="form-control @error('type_forage_id') is-invalid @enderror"
                                                id="type_forage_id" wire:model.lazy='state.type_forage_id'>
                                                <option value="">-- Sélectionner un Type de forage --</option>
                                                @foreach ($typesForage as $typeForage)
                                                    <option value="{{ $typeForage->id }}">{{ $typeForage->nom_type }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('type_forage_id')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="lieu">Lieu :</label>
                                            <input type="text"
                                                class="form-control @error('lieu') is-invalid @enderror" id="lieu"
                                                wire:model.lazy='state.lieu'>
                                            @error('lieu')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="profondeur_souhaitee">Profondeur souhaitée e (m):</label>
                                            <input type="number" step="0.01" min="0"
                                                class="form-control @error('profondeur_souhaitee') is-invalid @enderror"
                                                id="profondeur_souhaitee" wire:model.lazy='state.profondeur_souhaitee'>
                                            @error('profondeur_souhaitee')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="diametre_souhaite">Diamètre souhaité en (m):</label>
                                            <input type="number" step="0.01"
                                                class="form-control @error('diametre_souhaite') is-invalid @enderror"
                                                id="diametre_souhaite" wire:model.lazy='state.diametre_souhaite'>
                                            @error('diametre_souhaite')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="cout_total">Coût total :</label>
                                            <input type="number" step="0.01"
                                                class="form-control @error('cout_total') is-invalid @enderror"
                                                id="cout_total" wire:model.lazy='state.cout_total'>
                                            @error('cout_total')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="etat_projet">État :</label>
                                            <select class="form-control @error('etat_projet') is-invalid @enderror"
                                                id="etat_projet" wire:model.lazy='state.etat_projet'>
                                                <option value="">-- Sélectionner un État --</option>
                                                <option value="En attente">En attente</option>
                                                <option value="En cours de forage">En cours de forage</option>
                                                <option value="Terminé">Terminé</option>
                                                <option value="En attente de conditions géologiques">En attente de
                                                    conditions géologiques</option>
                                                <option value="En attente d'approbations">En attente d'approbations
                                                </option>
                                                <option value="Abandonné">Abandonné</option>
                                                <option value="En attente de financement">En attente de financement
                                                </option>
                                                <option value="En cours de construction d'infrastructure">En cours de
                                                    construction d'infrastructure</option>
                                                <option value="En cours de test">En cours de test</option>
                                                <option value="Opérationnel">Opérationnel</option>
                                            </select>
                                            @error('etat_projet')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="condition_geologique_id">Conditions géologiques :</label>
                                            <select
                                                class="form-control @error('condition_geologique_id') is-invalid @enderror"
                                                id="condition_geologique_id"
                                                wire:model.lazy="state.condition_geologique_id">
                                                <option value="">-- Sélectionner une condition géologique --
                                                </option>
                                                @foreach ($conditionsGeologiques as $conditionGeologique)
                                                    <option value="{{ $conditionGeologique->id }}">
                                                        {{ $conditionGeologique->nom_condition }}</option>
                                                @endforeach
                                            </select>
                                            @error('condition_geologique_id')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <!-- Autres champs de la migration -->

                                <button type="button" class="btn btn-secondary"> <i class="fa fa-times mr-1"></i>
                                    Annuler</button>

                                <button id="submit" type="submit" class="btn btn-primary"><i
                                        class="fa fa-trash mr-1"></i> Enregistrer</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section> 

</div>
