<div>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Factures</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Factures</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            {{-- <a href="{{ route('admin.facture.create') }}">
                                <button class="btn btn-primary ">
                                    <i class="fa fa-plus-circle mr-1"></i> Ajouter
                                </button>
                            </a> --}}
                            @if ($selectedRows)
                                <div class="btn-group ml-2">
                                    <button type="button" class="btn btn-default">Action</button>
                                    <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                        data-toggle="dropdown" aria-expanded="false">
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>

                                    <div class="dropdown-menu" role="menu" style="">
                                        <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                            href="#">Supprimer factures sélectionnés</a>
                                            <a wire:click.prevent="markAsCreee" class="dropdown-item" href="#">Marquer comme Créée</a>
                                            <a wire:click.prevent="markAsEnvoyee" class="dropdown-item" href="#">Marquer comme Envoyée</a>
                                            <a wire:click.prevent="markAsEnAttentePaiement" class="dropdown-item" href="#">Marquer comme En attente de paiement</a>
                                            <a wire:click.prevent="markAsPartiellementPayee" class="dropdown-item" href="#">Marquer comme Partiellement payée</a>
                                            <a wire:click.prevent="markAsPayee" class="dropdown-item" href="#">Marquer comme Payée</a>
                                            <a wire:click.prevent="markAsEnRetard" class="dropdown-item" href="#">Marquer comme En retard</a>
                                            <a wire:click.prevent="markAsAnnulee" class="dropdown-item" href="#">Marquer comme Annulée</a>
                                            <a wire:click.prevent="markAsReglee" class="dropdown-item" href="#">Marquer comme Réglée</a>
                                            <a wire:click.prevent="markAsEnLitige" class="dropdown-item" href="#">Marquer comme En litige</a>
                                            <a wire:click.prevent="markAsArchivee" class="dropdown-item" href="#">Marquer comme Archivée</a>  
                                        <a wire:click.prevent="export" class="dropdown-item" href="#">Exporter</a>
                                    </div>
                                </div>

                                <span class="ml-2">{{ count($selectedRows) }}
                                    {{ Str::plural(' Facture', count($selectedRows)) }} <i
                                        class="fa fa-check"></i></span>
                            @endif
                        </div>

                        <div class="btn-group">
                            <button wire:click="filterfacturesByStatus" type="button"
                                class="btn {{ is_null($status) ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Tout</span>
                                <span class="badge badge-pull badge-info">{{ $factureCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Créée')" type="button"
                                class="btn {{ $status == 'Créée' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Créée</span>
                                <span class="badge badge-pull badge-primary">{{ $factureCreeeCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Envoyée')" type="button"
                                class="btn {{ $status == 'Envoyée' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Envoyée</span>
                                <span class="badge badge-pull badge-primary">{{ $factureEnvoyeeCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('En attente de paiement')" type="button"
                                class="btn {{ $status == 'En attente de paiement' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En attente de paiement</span>
                                <span
                                    class="badge badge-pull badge-warning">{{ $factureEnAttentePaiementCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Partiellement payée')" type="button"
                                class="btn {{ $status == 'Partiellement payée' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Partiellement payée</span>
                                <span
                                    class="badge badge-pull badge-success">{{ $facturePartiellementPayeeCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Payée')" type="button"
                                class="btn {{ $status == 'Payée' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Payée</span>
                                <span class="badge badge-pull badge-success">{{ $facturePayeeCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('En retard')" type="button"
                                class="btn {{ $status == 'En retard' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En retard</span>
                                <span class="badge badge-pull badge-danger">{{ $factureEnRetardCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Annulée')" type="button"
                                class="btn {{ $status == 'Annulée' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Annulée</span>
                                <span class="badge badge-pull badge-secondary">{{ $factureAnnuleeCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Réglée')" type="button"
                                class="btn {{ $status == 'Réglée' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Réglée</span>
                                <span class="badge badge-pull badge-info">{{ $factureRegleeCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('En litige')" type="button"
                                class="btn {{ $status == 'En litige' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">En litige</span>
                                <span class="badge badge-pull badge-danger">{{ $factureEnLitigeCount }}</span>
                            </button>

                            <button wire:click="filterfacturesByStatus('Archivée')" type="button"
                                class="btn {{ $status == 'Archivée' ? 'btn-secondary' : 'btn-default' }}">
                                <span class="mr-1">Archivée</span>
                                <span class="badge badge-pull badge-secondary">{{ $factureArchiveeCount }}</span>
                            </button>


                        </div>


                        <x-search-input wire:model='searchTerm' />
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="custom-control custom-checkbox">
                                                    <input wire:model="selectedPageRows" class="custom-control-input"
                                                        type="checkbox" id="customCheckbox1" value="">
                                                    <label for="customCheckbox1" class="custom-control-label"></label>
                                                </div>
                                            </th>
                                            <th>#</th>
                                            <th>Titre</th>
                                            <th>Numéro</th>
                                            <th>Projet</th>
                                            <th>Devis</th>
                                            <th>État du factures</th>
                                            <th>Diamètre Souhaité</th>
                                            <th>Profondeur Souhaité</th>
                                            <th>TVA</th>
                                            <th>Coût Total</th>
                                            <th>Client</th>
                                            <th>Utilisateur</th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody wire:loading.class='text-muted'>
                                        @forelse ($factures as $facture)
                                            <tr>
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="{{ $facture->id }}"
                                                            value="{{ $facture->id }}">
                                                        <label for="{{ $facture->id }}"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>

                                                <th scope="row">{{ $loop->iteration }}</td>
                                                <td><a href="{{ route('admin.facture.show', $facture) }}"><i
                                                            class="fa fa-eye mr-2"></i>{{ Str::upper($facture->titre) }}</a>
                                                </td>
                                                <td>{{ $facture->numero }} </td>
                                                <td><a href="{{ route('admin.project.show', $facture->projet->id) }}"> {{ $facture->projet->nom_projet }}</a></td>
                                                <td><a href="{{ route('admin.devis.show',$facture->devis->id) }}">{{ $facture->devis->numero }}</a> </td>
                                                <td> {!! $facture->getEtatIconAttribute() !!} </td>
                                                <td>{{ $facture->projet->diametre_souhaite }} m</td>
                                                <td>{{ $facture->projet->profondeur_souhaitee }} m</td>
                                                <td>{{ number_format($facture->prix_tva, 2, ',', ' ') }} $</td>
                                                <td>{{ number_format($facture->total_ttc, 2, ',', ' ') }} $</td>
                                                <td>{{ Str::upper($facture->projet->client->nom) }}</td>
                                                <td>{{ Str::upper($facture->user->name) }}</td>
                                                <td> 

                                                    @can('access', 'Facture-Supprimer')
                                                        <a href=""
                                                            wire:click.prevent="confirmFactureRemoval({{ $facture->id }})"><i
                                                                class="fa fa-trash text-danger"></i></a>
                                                    @endcan
                                                    @can('access', 'Facture-Modifier')
                                                        <a href=""
                                                            wire:click.prevent="toggleFactureValidity({{ $facture }})">
                                                            @if ($facture->is_valid == 1)
                                                                <i class="fa fa-unlock text-success ml-2"></i>
                                                                <!-- Afficher le cadenas ouvert -->
                                                            @else
                                                                <i class="fa fa-lock text-danger ml-2"></i>
                                                                <!-- Afficher le cadenas fermé -->
                                                            @endif
                                                        </a>
                                                    @endcan
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="14">
                                                    <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            {!! $factures->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <x-confirmation-alert />
</div>

@push('styles')
    <style>
        .draggable-mirror {
            background-color: white;
            width: 950px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
@endpush
