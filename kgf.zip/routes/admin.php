<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Livewire\Admin\Acces\ListAcces;
use App\Http\Livewire\Admin\Agents\ListAgents;
use App\Http\Livewire\Admin\Approvisionnement\Approvisionnement;
use App\Http\Livewire\Admin\Clients\ListClient;
use App\Http\Livewire\Admin\ConditionsGeologiques\ListConditions;
use App\Http\Livewire\Admin\Devis\DevisCreate;
use App\Http\Livewire\Admin\Devis\DevisList;
use App\Http\Livewire\Admin\Devis\DevisShow;
use App\Http\Livewire\Admin\Devis\DevisUpdate;
use App\Http\Livewire\Admin\Equipements\ListEquipements;
use App\Http\Livewire\Admin\Etapes\ListEtapes;
use App\Http\Livewire\Admin\Facture\FactureCreate;
use App\Http\Livewire\Admin\Facture\FactureShow;
use App\Http\Livewire\Admin\Facture\FactureUpdate;
use App\Http\Livewire\Admin\Facture\ListFacture;
use App\Http\Livewire\Admin\Fonctions\ListFonctions;
use App\Http\Livewire\Admin\Maindoeuvre\ListMainDoeuvre;
use App\Http\Livewire\Admin\Modeles\ListModele;
use App\Http\Livewire\Admin\Permis\Listpermis;
use App\Http\Livewire\Admin\Projects\AddProject;
use App\Http\Livewire\Admin\Projects\ListProject;
use App\Http\Livewire\Admin\Projects\ProjectEdit;
use App\Http\Livewire\Admin\Projects\ProjectShow;
use App\Http\Livewire\Admin\Services\ListServices;
use App\Http\Livewire\Admin\Settings\UpdateSettings;
use App\Http\Livewire\Admin\Sites\ListSites;
use App\Http\Livewire\Admin\Titres\ListTitre;
use App\Http\Livewire\Admin\TypeForages\ListType;
use App\Http\Livewire\Admin\Users\ListUsers;
use Illuminate\Support\Facades\Route;

Route::get('dashboard', DashboardController::class)->name('dashboard');
Route::get('users', ListUsers::class)->name('users');

Route::get('acces', ListAcces::class)->name('acces');
Route::get('modeles', ListModele::class)->name('modeles');

Route::get('sites', ListSites::class)->name('sites');
Route::get('services', ListServices::class)->name('services');
Route::get('titres', ListTitre::class)->name('titres');
Route::get('fonctions', ListFonctions::class)->name('fonctions');
Route::get('settings', UpdateSettings::class)->name('settings');

Route::get('agents', ListAgents::class)->name('agents');
Route::get('clients', ListClient::class)->name('clients');

Route::get('types_de_forages', ListType::class)->name('types_forage');
Route::get('conditions_geologiques', ListConditions ::class)->name('conditions_geologiques');
Route::get('equipements', ListEquipements ::class)->name('equipements');
Route::get('main_d_oeuvre', ListMainDoeuvre ::class)->name('main_d_oeuvre');
Route::get('approvisionnement_en_eau', Approvisionnement ::class)->name('approvisionnement_en_eau');
Route::get('permis_et_reglementations', Listpermis ::class)->name('permis');

Route::get('ajouter_projet', AddProject ::class)->name('add.project'); 
Route::get('projets', ListProject ::class)->name('projects');
Route::get('projet/{projet}/show', ProjectShow::class)->name('project.show');
Route::get('projet/{projet}/edite', ProjectEdit::class)->name('project.edit');

Route::get('devis', DevisList ::class)->name('devis');  
Route::get('devis_create', DevisCreate ::class)->name('devis.create');  
Route::get('devis_show/{devis}/show', DevisShow::class)->name('devis.show');
Route::get('devis_edit/{devis}/edit', DevisUpdate::class)->name('devis.edit');

Route::get('etapes_forage', ListEtapes::class)->name('etapes_forage');

Route::get('factures', ListFacture ::class)->name('factures');  
Route::get('facture_create', FactureCreate ::class)->name('facture.create');  
Route::get('facture_show/{facture}', FactureShow ::class)->name('facture.show');  
Route::get('facture_update/{facture}', FactureUpdate ::class)->name('facture.edit');  


