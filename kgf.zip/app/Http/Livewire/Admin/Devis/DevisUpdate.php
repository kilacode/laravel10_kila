<?php

namespace App\Http\Livewire\Admin\Devis;

use App\Models\DevisForage;
use App\Models\ProjetForage;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class DevisUpdate extends Component
{
    
    public $state = [];
    public $devis;
    public $searchTerm = null;
    public $selectedClient = null;
    public $conditions_general;
    public $garantie_rembourse;

    public function getProjetsProperty()
    {
        return ProjetForage::orderBy('created_at','desc')->get();
    }
    public function mount(DevisForage $devis)
    {
        $this->state = $devis->toArray();
        $this->devis = $devis;
        $this->conditions_general = $this->devis->conditions_general;
        $this->garantie_rembourse = $this->devis->garantie_rembourse;
    }

    public function updateDevis( $conditions_general,$garantie_rembourse)
    {
        $this->conditions_general = $conditions_general;
        $this->garantie_rembourse = $garantie_rembourse;

        $validatedData = Validator::make($this->state, [
            'titre' => 'required',
            'note' => 'nullable',
            'etat' => 'nullable',
            'date'=>'required',
            'modalite' => 'nullable',
            'echeance' => 'nullable',
            'coordonee_banc' => 'nullable',
            'delai_livraison' => 'nullable',
            'conditions_general' => 'nullable',
            'garantie_rembourse' => 'nullable',
            'contact' => 'nullable',
            'tva'=>'nullable',
            'validite'=>'required',
            'marge_ben' => 'required', 
            'projet_forage_id' => 'required'
        ],[
            'titre.required' => "Le champ Titre est obligatoire.",
            'date.required' => "Le champ date est obligatoire.",
            'validite.required' => "Le champ validité est obligatoire.",
            'marge_ben.required' => "Le champ Marge bénéficiaire est obligatoire.",
            'projet_forage_id.required' => "Le champ projet de forage est obligatoire.",
        ])->validate();
          
      
        $validatedData['user_id'] = auth()->user()->id; 

        $validatedData['conditions_general'] = $this->conditions_general ;
        $validatedData['garantie_rembourse'] = $this->garantie_rembourse;
         
        if (Gate::allows('access', 'Devis-Forage-ajouter')) {
            $this->devis->update($validatedData);
            $this->dispatchBrowserEvent('alert', ['message' => "Devis modifié avec succès !"]);
            return redirect()->route('admin.devis');
        }

    }
    public function render()
    {
        $projets = $this->projets;
        return view('livewire.admin.devis.devis-update', compact('projets'));
    }
}
