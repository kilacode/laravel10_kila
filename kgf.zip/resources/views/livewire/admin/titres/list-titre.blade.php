<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Titres</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Tableau de bord</a></li>
                        <li class="breadcrumb-item active">Titres</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between mb-2">

                        <button class="btn btn-primary " wire:click.prevent="addNew">
                            <i class="fa fa-plus-circle mr-1"></i> Ajouter Titre
                        </button>

                        @if ($selectedRows)
                            <div class="btn-group ml-2">
                                <button type="button" class="btn btn-default">Options</button>
                                <button type="button" class="btn btn-default dropdown-toggle dropdown-icon"
                                    data-toggle="dropdown" aria-expanded="false">
                                    <span class="sr-only"></span>
                                </button>
                                <div class="dropdown-menu" role="menu" style="">
                                    <a wire:click.prevent="deleteSelectedRows" class="dropdown-item"
                                        href="#">Supprimer les Titres sélectionnés</a>
                                </div>
                            </div>
                            <span class="ml-2">{{ count($selectedRows) }}
                                {{ Str::plural(' Titre', count($selectedRows)) }} {{ Str::plural(' sélectionné', count($selectedRows)) }} </span>
                        @endif

                        <x-search-input wire:model='searchTerm' />
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th></th>
                                            <th>Nom</th>
                                            <th>Options</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($titres as $titre)
                                            <tr>
                                                <th scope="row">{{ $loop->iteration }}</th>
                                                <th style="width: 10px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input wire:model="selectedRows" class="custom-control-input"
                                                            type="checkbox" id="{{ $titre->id }}"
                                                            value="{{ $titre->id }}">
                                                        <label for="{{ $titre->id }}"
                                                            class="custom-control-label"></label>
                                                    </div>
                                                </th>
                                                <td>{{ $titre->name }}</td>
                                                <td>
                                                    @can('access', 'Titre-Modifier')
                                                        <a href="" wire:click.prevent="edit({{ $titre }})">
                                                            <i class="fa fa-edit mr-2"></i>
                                                        </a>
                                                    @endcan 
                                                    @can('access', 'Titre-Supprimer')
                                                        <a href=""
                                                            wire:click.prevent="confirmTitreRemoval({{ $titre->id }})">
                                                            <i class="fa fa-trash text-danger"></i>
                                                        </a>
                                                    @endcan
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="10">
                                                    <img src="{{ asset('img/page-not-found.png') }}" height="100"
                                                        alt="Aucun résultat trouvé">
                                                    <p>Aucun résultat trouvé</p>
                                                </td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        <div class="card-footer d-flex justify-content-end">
                            {{ $titres->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        @if ($showEditModal == true)
                            <span>Modifier le Titre</span>
                        @else
                            <span>Ajout d'un nouveau Titre</span>
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="{{ $showEditModal ? 'updateTitre' : 'createTitre' }}">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="name">Nom</label>
                                    <input type="text" class="form-control @error('name') is-invalid @enderror"
                                        wire:model.defer="state.name" id="name" placeholder="Nom de la Titre">

                                    @error('name')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>
                    @if ($showEditModal)
                        <button type="submit" class="btn btn-info"><i class="fa fa-save mr-1"></i> Enregistrer les
                            modifications</button>
                    @else
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-1"></i>
                            Enregistrer</button>
                    @endif
                </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Supprimer le Titre</h5>
                </div>
                <div class="modal-body">
                    <h4>Etes-vous sûr de vouloir supprimer ce Titre?</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                            class="fa fa-times mr-1"></i> Annuler</button>

                    <button type="button" wire:click.prevent='deleteTitre' class="btn btn-danger"><i
                            class="fa fa-trash mr-1"></i>
                        Supprimer</button>

                </div>
            </div>
        </div>
    </div>
</div>
