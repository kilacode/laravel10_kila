<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('agents', function (Blueprint $table) {
            $table->id();
            $table->string('nom');
            $table->string('postnom');
            $table->string('prenom');
            $table->string('nationalite');
            $table->string('date_naissance');
            $table->string('lieu_naissance');
            $table->string('sexe');
            $table->string('profession');
            $table->string('email');
            $table->string('telephone');
            $table->string('adresse');
            $table->string('province_origine');
            $table->string('numero_carte_identite')->unique();
            $table->string('date_expiration_carte_identite')->nullable();
            $table->timestamps();
            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('agents');
    }
};
