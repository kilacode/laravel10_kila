<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('factures', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('projet_forage_id');
            $table->unsignedBigInteger('devis_projet_id');
            $table->string('titre');
            $table->string('numero');
            $table->text('note')->nullable();
            $table->double('tva')->default(0);
            $table->double('total_ht')->default(0);
            $table->double('total_ttc')->default(0);
            $table->timestamps();
            $table->string('etat');
            $table->unsignedBigInteger('user_id')->nullable();
            $table->double('marge_ben')->default(0);
            $table->date('date')->nullable();
            $table->integer('validite')->nullable();
            $table->boolean('is_valid')->default(false);
            $table->string('modalite')->nullable();
            $table->string('echeance')->nullable();
            $table->string('coordonee_banc')->nullable();
            $table->integer('delai_livraison')->nullable();
            $table->text('conditions_general')->nullable();
            $table->text('garantie_rembourse')->nullable();
            $table->string('contact')->nullable();
            $table->boolean('modifiable')->default(false);

            $table->foreign('projet_forage_id')
                ->references('id')
                ->on('projet_forages')
                ->onDelete('cascade');

            $table->foreign('devis_projet_id')
                ->references('id')
                ->on('devis_forages')
                ->onDelete('cascade');   

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onDelete('set null'); 
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('factures');
    }
};
