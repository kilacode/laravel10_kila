<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('devis_forages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('projet_forage_id');
            $table->foreign('projet_forage_id')->references('id')->on('projet_forages')->onDelete('cascade');
            $table->string('titre');
            $table->string('numero');
            $table->double('tva')->default(0);
            $table->double('total_ht')->default(0);
            $table->double('total_ttc')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('devis_forages');
    }
};
