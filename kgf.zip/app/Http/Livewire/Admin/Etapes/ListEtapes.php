<?php

namespace App\Http\Livewire\Admin\Etapes;

use App\Http\Livewire\Admin\AdminComponent;
use App\Models\EtapesForage;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class ListEtapes extends AdminComponent
{
    public $state = [];
    public $selectedRows = [];
    public $selectedPageRows = false;
    public $showEditModal = false;
    public $etapeIdBeingRemoved = null;
    public $etape;
    public $searchTerm = null;
    public $selectedIds = [];
  
    public function addNew()
    { 
        if (Gate::allows('access','Etape-Forage-Ajouter')) {
            $this->showEditModal = false; 
            $this->reset();
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function createEtape()
    { 
        $validateData = Validator::make($this->state, [ 
            'nom_etape' => 'required', 
            'description' => 'nullable', 
        ], [ 
            'name.required' => "Le nom est obligatoire", 
        ])->validate();
            
            if (Gate::allows('access','Etape-Forage-Ajouter')) {
                EtapesForage::create($validateData); 
                //$this->dispatchBrowserEvent('hide-form', ['message' => "Etape ajouté avec succès !"]); 
            }

            $this->state = [];
         
 
    }
    public function edit(EtapesForage $etape)
    {
        if (Gate::allows('access','Etape-Forage-Modifier')) {
            $this->reset();

            $this->showEditModal = true;

            $this->etape = $etape;

            $this->state = $etape->toArray();   
            $this->dispatchBrowserEvent('show-form');
        }
    }

    public function updateEtape()
    {
        $validateData = Validator::make($this->state, [ 
            'nom_etape' => 'required',
            'description' => 'nullable',
        ], [ 
            'nom_etape.required' => "Le nom est obligatoire", 
        ])->validate();
        
        if (Gate::allows('access','Etape-Forage-Modifier')) {

            $this->etape->update($validateData);

            $this->dispatchBrowserEvent('hide-form', ['message' => "Etape modifié avec succès !"]);
        }

        $this->state = [];  
    }
    public function deleteSelectedRows()
    {
        if (Gate::allows('access','Etape-Forage-Supprimer-Groupe')) {
            EtapesForage::whereIn('id', $this->selectedRows)->delete();

            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => 'Vos Etapes ont étés supprimés?']);

            $this->reset(['selectedRows','selectedPageRows']);
        }
    }
    public function confirmEtapeRemoval($etapeId)
    {
        $this->etapeIdBeingRemoved = $etapeId;

        $this->dispatchBrowserEvent('show-delete-modal');
    }

    public function deleteEtape()
    {
        if (Gate::allows('access','Etape-Forage-Supprimer')) {
            $etape = EtapesForage::findOrFail($this->etapeIdBeingRemoved);
            $etape->delete();
            $this->dispatchBrowserEvent('hide-delete-modal', ['message' => "Etape suprimé avec succès !"]); 
        }  
    }
    public function render()
    {
        $etapes = EtapesForage::query()
                ->where('nom_etape','like', '%'.$this->searchTerm.'%') 
                ->latest()->paginate(12); 
        return view('livewire.admin.etapes.list-etapes', compact('etapes'));
    }
}
