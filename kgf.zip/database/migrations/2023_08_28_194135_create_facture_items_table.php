<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('facture_items', function (Blueprint $table) {
            $table->id();
            $table->string('titre');
            $table->string('description')->nullable();
            $table->integer('qte')->default(0);
            $table->string('unite')->nullable();
            $table->decimal('prix_u', 8, 2)->default(0.00);
            $table->decimal('prix_t', 8, 2)->default(0.00);
            $table->decimal('prix_ht', 8, 2)->default(0.00);
            $table->decimal('prix_tva', 8, 2)->default(0.00);
            $table->decimal('prix_rabais', 8, 2)->default(0.00);
            $table->decimal('tva', 8, 2)->default(0.00);
            $table->decimal('rabais', 8, 2)->default(0.00);
            $table->unsignedBigInteger('facture_id');
            $table->unsignedBigInteger('etape_forage_id');

            $table->foreign('facture_id')
                ->references('id')
                ->on('factures')
                ->onDelete('cascade');

            $table->foreign('etape_forage_id')
                ->references('id')
                ->on('etapes_forages')
                ->onDelete('cascade');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('facture_items');
    }
};
