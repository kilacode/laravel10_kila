<div>
    <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Utilisateurs</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Tableau de bord</a></li>
                            <li class="breadcrumb-item active">Utilisateurs</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>

         <!-- Main content -->
         <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex justify-content-between mb-2">
                            <button class="btn btn-primary " wire:click.prevent="addNew">
                                <i class="fa fa-plus-circle mr-1"></i> Ajouter utilisateur
                            </button>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-input','data' => ['wire:model' => 'searchTerm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'searchTerm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <td>#</td>
                                                <th>Nom</th>
                                                <th>Email</th>
                                                <th>Date d'enregistrement</th>
                                                <th>Role</th>
                                                <th>Options</th>
                                            </tr>
                                        </thead>
                                        <tbody wire:loading.class='text-muted'>
                                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($loop->iteration); ?></td>
                                                    <td>
                                                        <img src="<?php echo e($user->avatar_url); ?>" style="width: 50px;"
                                                            alt="avatar" class="img img-rounded mr-1">
                                                        <?php echo e(Str::upper($user->name)); ?>

                                                    </td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td><?php echo e($user->created_at->toFormattedDate()); ?></td>
                                                    <td>
                                                        <select class="form-control" wire:change="changeRole(<?php echo e($user); ?>,$event.target.value)">
                                                            <option value="admin" <?php echo e(($user->role == "admin")? 'selected':''); ?>>ADMIN</option>
                                                            <option value="user" <?php echo e(($user->role == "user")? 'selected':''); ?>>USER</option>
    
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <a href="" wire:click.prevent="edit(<?php echo e($user); ?>)">
                                                            <i class="fa fa-edit mr-2"></i>
                                                        </a>
                                                        <a href=""
                                                            wire:click.prevent="confirmUserRemoval(<?php echo e($user->id); ?>)">
                                                            <i class="fa fa-trash text-danger"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr class="text-center">
                                                    <td colspan="7">
                                                        <img src="<?php echo e(asset('img/page-not-found.png')); ?>" height="100"
                                                            alt="Aucun résultat trouvé">
                                                        <p>Aucun résultat trouvé</p>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
    
                                        </tbody>
                                    </table>
                                </div>
    
                            </div>
                            <div class="card-footer d-flex justify-content-end">
                                <?php echo e($users->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>

         <!-- Modal -->
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                    <?php if($showEditModal == true): ?>
                        <span>Modifier l'utilisateur</span>
                    <?php else: ?>
                        <span>Ajout d'un nouvel utiisateur</span>
                    <?php endif; ?>
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form wire:submit.prevent="<?php echo e($showEditModal ? 'updateUser' : 'createUser'); ?>">
                    <div class="form-group">
                        <label for="name">Nom</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.defer="state.name" id="name" aria-describedby="nom" placeholder="Nom">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <div class="form-group">
                        <label for="email">Adresse Email</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.defer="state.email" id="email" aria-describedby="emailHelp"
                            placeholder="Saisisse l'Email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.defer="state.password" id="password" placeholder="Mot de passe">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="passwordconfirmation">Confirmer Mot de passe</label>
                        <input type="password"
                            class="form-control <?php $__errorArgs = ['passwordconfirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.defer="state.password_confirmation" id="passwordconfirmation"
                            placeholder="Confirmer Mot de passe">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="customfile">Photo de Profile</label>
                        
                        <div class="custom-file">
                            <div x-data="{ isUploading: true, progress: 5 }"
                                 x-on:livewire-upload-start="isUploading = true"
                                 x-on:livewire-upload-finish="isUploading = false; progress = 5"
                                 x-on:livewire-upload-error="isUploading = false"
                                 x-on:livewire-upload-progress="progress = $event.detail.progress"
                            >
                                <input wire:model="photo" type="file" class="custom-file-input"
                                    id="customfile">

                                <div x-show.transition="isUploading" class="progress progress-sm mt-2 rounded">
                                    <div class="progress-bar bg-primary progress-bar-striped" role="progressbar"
                                        aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"
                                        x-bind:style="`width:${progress}%`">
                                        <span class="sr-only">40% Complete (success)</span>
                                    </div>
                                </div>
                            </div>

                            <label class="custom-file-label" for="customfile">
                                <?php if($photo): ?>
                                    <?php echo e($photo->getClientOriginalName()); ?>

                                <?php else: ?>
                                    Choisissez un fichier
                                <?php endif; ?>
                            </label>
                        </div>
                        <?php if($photo): ?>
                            <img src="<?php echo e($photo->temporaryUrl()); ?>" alt=".." class="img img-rounded mb-2 mt-2 w-50"
                                style="width: 50px">
                        <?php elseif($state['avatar_url'] ?? ''): ?>
                            <img src="<?php echo e($state['avatar_url'] ?? ''); ?>" alt=".."
                                class="img img-rounded mb-2 w-50" style="width: 50px">
                        <?php endif; ?>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                        class="fa fa-times mr-1"></i> Annuler</button>
                <?php if($showEditModal): ?>
                    <button type="submit" class="btn btn-info"><i class="fa fa-save mr-1"></i> Enregistrer les
                        modifications</button>
                <?php else: ?>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-1"></i>
                        Enregistrer</button>
                <?php endif; ?>
            </div>
            </form>
        </div>
    </div>
</div>


<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Supprimer l'utilisateur</h5>
            </div>
            <div class="modal-body">
                <h4>Etes-vous sûr de vouloir supprimer cet utilisateur?</h4>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"> <i
                        class="fa fa-times mr-1"></i> Annuler</button>

                <button type="button" wire:click.prevent='deleteUser' class="btn btn-danger"><i
                        class="fa fa-trash mr-1"></i>
                    Supprimer</button>

            </div>
        </div>
    </div>
</div>
         
</div>
<?php /**PATH D:\Dev\kgf\resources\views/livewire/admin/users/list-users.blade.php ENDPATH**/ ?>