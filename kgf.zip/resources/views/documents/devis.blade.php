<style>
    .cell {
        width: 30%;
        /* Vous pouvez ajuster la largeur selon vos besoins */
        padding: 5px;
        text-align: center;
    }

    .clearfix:after {
        content: "";
        display: table;
        clear: both;
    }

    body {
        position: relative;
        width: calc(21cm - 40px);
        /* 21cm - 2*20px */
        height: 29.7cm;
        margin: 0 20px;
        /* Ajout des marges gauche et droite */
        color: #001028;
        background: #FFFFFF;
        font-family: Arial, sans-serif;
        font-size: 12px;
    }

    header {
        padding: 10px 0;
        margin-bottom: 30px;
    }

    #project {
        float: left;
    }

    #project span {
        color: #5D6975;
        text-align: right;
        width: 52px;
        margin-right: 10px;
        display: inline-block;
        font-size: 0.8em;
    }

    #company {
        float: right;
        text-align: right;
    }

    #project div,
    #company div {
        white-space: nowrap;
    }

    .watermark {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0.5;
        z-index: 9999;
        text-align: center;
        vertical-align: middle;
    }

    .watermark-text {
        color: red;
        font-size: 60px;
        transform: rotate(-45deg);
        margin-top: 200px;
    }

    .styled-table {
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 0.8em;
        font-family: sans-serif;
        min-width: 100%;
        text-align: left;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table2 {
        border-collapse: collapse;
        margin: 16px 0;
        font-size: 0.7em;
        font-family: sans-serif;
        min-width: 100%;

    }

    .styled-table3 {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 1em;
        font-family: sans-serif;
        min-width: 50%;
    }

    .styled-table4 {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 1em;
        font-family: sans-serif;
        min-width: 100%;
    }

    .styled-table2 th {
        text-align: center;
    }

    .styled-table4 th {
        text-align: center;
    }

    .styled-table4 p {
        font-size: 25px;

        margin-top: -20px;
        margin-bottom: 13px
    }


    .styled-table thead tr {
        background-color: #02617e;
        color: #ffffff;
        text-align: left;
    }

    .styled-table thead th {
        text-align: left;
    }

    .styled-table tfoot th {
        text-align: left;
    }

    .styled-table tfoot tr {
        background-color: #ffc157;
        color: #000000;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 4px 3px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

    .styled-table tbody tr:last-of-type {}

    .styled-table tbody tr.active-row {
        font-weight: bold;
    }

    h4 {
        font-family: sans-serif;
    }

    footer {
        position: fixed;
        bottom: 40px;
        left: 0px;
        right: 0px;
        height: 3px;
        margin-bottom: -20px;
        /** Extra personal styles **/
        background-color: rgb(13, 52, 135);
        font-family: sans-serif;
        color: #000;
        text-align: center;
        line-height: 6px;
    }

    footer p {
        font-size: 10px;
    }

    footer .pagenum:before {
        content: counter(page);
    }

    .footer {
        margin-top: 20px;
        border-top: 1px solid #ddd;
        padding-top: 10px;
    }
</style>

<table class="styled-table3" style="width: 100%; margin-top:-15px">
    <tr>
        <th style="text-align: left; width: 50%"> <img src="{{ public_path('img/v.jpg') }}" alt="" height="100">
        </th>

        <td style="text-align: right; width: 50%"><span>{!! $code !!}</span></td>
    </tr>
    <tr>
        <th style="text-align: left; width: 50%"></th>
        <th style="text-align: right; width: 50%">{{ Str::upper($devis->numero) }}</th>
    </tr>
    <tr>
        <th style="text-align: left; width: 50%"></th>
        <th style="text-align: right; width: 50%; font-size: 12px">Le {{ date('d/m/Y', strtotime($devis->date)) }}</th>
    </tr>

</table>

<body>
    <header class="clearfix">
        <div id="company" class="clearfix">
            <div>{{ $infos->site_title }}</div>
            <div>{{ $infos->site_name }}</div>
            <div><a href="mailto:{{ $infos->site_email }}">{{ $infos->site_email }}</a></div>
        </div>
        <div id="project">
            <div><span>PROJET</span> {{ $devis->projetForage->nom_projet }}</div>
            <div><span>CLIENT</span> {{ $devis->projetForage->client->prenom }} {{ $devis->projetForage->client->nom }}
            </div>
            {{-- <div><span>ADDRESS</span> {{ Str::ucfirst($devis->projetForage->client->adresse) }}</div> --}}
            <div><span>EMAIL</span> <a
                    href="mailto:{{ $devis->projetForage->client->email }}">{{ $devis->projetForage->client->email }}</a>
            </div>

            @php
                use Carbon\Carbon;
                $date = Carbon::now();
                $created_at = Carbon::parse($devis->created_at);
                $validite = $devis->validite;
                $duedate = $created_at->addDays($validite);
                $formattedDate = $date->locale('fr')->isoFormat('dddd, [le] DD/MM/YYYY');
                $formattedDueDate = $duedate->locale('fr')->isoFormat('dddd, [le] DD/MM/YYYY');
            @endphp
            <div><span>DATE</span> {{ Str::ucfirst($formattedDate) }}</div>
            <div><span>VALIDITE</span> {{ Str::ucfirst($formattedDueDate) }}</div>
        </div>
    </header>
    @if ($devis->is_valid == 0)
        <div class="watermark">
            <div class="watermark-text">Devis Invalide <br>Devis Invalide<br>Devis Invalide<br>Devis Invalide </div>
        </div>
    @else
        @foreach ($etapes as $etape)
            @if ($etape->devis_item->where('devis_forage_id', $devis->id)->count() > 0)
                <table class="styled-table">
                    <tfoot>
                        <tr>
                            <th class="cell">{{ Str::upper($etape->nom_etape) }}</th>
                            <th colspan="7"></th>
                        </tr>
                    </tfoot>
                    <thead>
                        <tr>
                            <th scope="col">Titre</th>
                            <th scope="col">Unité</th>
                            <th scope="col">Qte</th>
                            <th scope="col">P.U</th>
                            <th scope="col">TVA</th>
                            <th scope="col">Rabais</th>
                            <th scope="col">Total HT</th>
                            <th scope="col">Total</th>
                        </tr>
                    </thead>
                    <tbody style="background-color: #fff">
                        @foreach ($etape->devis_item->where('devis_forage_id', $devis->id) as $item)
                            <tr>
                                <td>{{ $item->titre }}</td>
                                <td>{{ $item->unite }}</td>
                                <td>{{ $item->qte }}</td>
                                <td>{{ $item->prix_u }} $</td>
                                <td>{{ $item->prix_tva }} $</td>
                                <td>{{ $item->prix_rabais }} $</td>
                                <td>{{ $item->prix_ht }} $</td>
                                <td>{{ $item->prix_t }} $</td>
                            </tr>
                        @endforeach
                        <tr style="background-color: #fff; padding:20px;">
                            <td colspan="8"></td>
                        </tr> 
                        <tr>
                            <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"> </td>
                            <td style="padding: 5px;border: 1px solid #777;">Total HT : </td>
                            <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                                <strong>{{ number_format($etape->devis_item->sum('prix_ht'), 2, '.', ' ') }}
                                    $</strong>
                            </td>
                        </tr> 
                        @if ($etape->devis_item->sum('prix_tva') > 0)
                            <tr>
                                <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"> </td>
                                <td style="padding: 5px;border: 1px solid #777;">TVA : </td>
                                <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                                    <strong>{{ number_format($etape->devis_item->sum('prix_tva'), 2, '.', ' ') }}
                                        $</strong>
                                </td>
                            </tr>
                        @endif

                        @if ($etape->devis_item->sum('rabais') > 0)
                            <tr>
                                <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"> </td>
                                <td style="padding: 5px;border: 1px solid #777;">Rabais :</td>
                                <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                                    <strong>{{ number_format($etape->devis_item->sum('prix_rabais'), 2, '.', ' ') }}
                                        $</strong>
                                </td>
                            </tr>
                        @endif

                        <tr>
                            <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"></td>
                            <td style="padding: 5px;border: 1px solid #777;">Sous total : </td>
                            <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                                <strong>{{ number_format($etape->devis_item->sum('prix_t'), 2, '.', ' ') }} $</strong>
                            </td>
                        </tr>
                    </tbody>


                </table>
            @endif
        @endforeach
        <table class="styled-table">
            <tfoot>
                <tr>
                    <th class="cell" style="background-color: #fff"></th>
                    <th colspan="7" style="background-color: #fff"></th>
                </tr>
            </tfoot>
            <tbody>
                <tr>
                    <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"></td>
                    <td style="padding: 5px;border: 1px solid #777;">Total HT : </td>
                    <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                        <strong>{{ number_format($devis->devis_item->sum('prix_ht'), 2, '.', ' ') }} $</strong>
                    </td>
                </tr>
                @if ($devis->devis_item->sum('tva') > 0)
                    <tr>
                        <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"> </td>
                        <td style="padding: 5px;border: 1px solid #777;">TVA : </td>
                        <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                            <strong>{{ number_format($devis->devis_item->sum('prix_tva'), 2, '.', ' ') }} $</strong>
                        </td>
                    </tr>
                @endif

                @if ($devis->devis_item->sum('rabais') > 0)
                    <tr>
                        <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"> </td>
                        <td style="padding: 5px;border: 1px solid #777;">Rabais :</td>
                        <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                            <strong>{{ number_format($devis->devis_item->sum('prix_rabais'), 2, '.', ' ') }}
                                $</strong>
                        </td>
                    </tr>
                @endif
                
                <tr>
                    <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"></td>
                    <td style="padding: 5px;border: 1px solid #777;">Total : </td>
                    <td style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                        <strong>{{ number_format($devis->devis_item->sum('prix_t'), 2, '.', ' ') }} $</strong>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="background-color: #fff;border: 1px solid #fff;"></td>
                    <td colspan="2" style="background-color: #fff;padding: 5px;border: 1px solid #777;">
                        <i>{{ Str::ucfirst($devis->int2str(round($devis->devis_item->sum('prix_t'), 2))) }}</i>
                    </td>
                </tr>
            </tbody>
        </table>
    @endif
    <div class="footer">
        @if (isset($devis->modalite))
            <p><strong>Modalités de paiement:</strong> {{ $devis->modalite }}</p>
        @endif

        @if (isset($devis->echeance))
            <p><strong>Echéance de Paiement:</strong> {{ $devis->echeance }}</p>
        @endif

        @if (isset($devis->coordonee_banc))
            <p><strong>Coordonnées Bancaires:</strong> {{ $devis->coordonee_banc }}</p>
        @endif

        @if (isset($devis->delai_livraison))
            <p><strong>Délai de livraison (Jours):</strong> {{ $devis->delai_livraison }} Jours</p>
        @endif

        @if (isset($devis->contact))
            <p><strong>Contact:</strong> {{ $devis->contact }}</p>
        @endif
        @if (isset($devis->conditions_general)) 
            {!! $devis->conditions_general !!}
        @endif

        @if(isset($devis->garantie_rembourse))
           {!! $devis->garantie_rembourse !!} 
        @endif

    </div>

</body>

<footer>
    <p>1542, avenue province Quartier Golf /
        <a href="mailto:{{ $infos->site_email }}">{{ $infos->site_email }}</a>
    </p>
    <p>
        <a href="telto:+243 817 636 277">+243 817 636 277</a>
        /<a href="telto:+243 973 765 970">+243 973 765 970</a>
    </p>
    <div class="pagenum-container">
        <p>KGF Solution / <a href="www.kgfsolution.cd">www.kgfsolution.cd </a> Page<span class="pagenum"></span></p>
    </div>
</footer>
